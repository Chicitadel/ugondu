<?php
namespace AirRoofers\Operations\PlatformServices\Telemetry;

class CorrelationTracker {
    private array $active_traces = [];

    public function beginTrace(string $correlation_id, string $platform_id, string $action): void {
        if (!isset($this->active_traces[$correlation_id])) {
            $this->active_traces[$correlation_id] = [];
        }

        $this->active_traces[$correlation_id][] = [
            'timestamp' => date('Y-m-d\TH:i:s\Z'),
            'platform_id' => $platform_id,
            'action' => $action,
            'status' => 'started'
        ];
    }

    public function recordEvent(string $correlation_id, string $platform_id, string $event_type): void {
        if (isset($this->active_traces[$correlation_id])) {
            $this->active_traces[$correlation_id][] = [
                'timestamp' => date('Y-m-d\TH:i:s\Z'),
                'platform_id' => $platform_id,
                'event_type' => $event_type,
                'status' => 'recorded'
            ];
        }
    }

    public function getTrace(string $correlation_id): ?array {
        return $this->active_traces[$correlation_id] ?? null;
    }
}
