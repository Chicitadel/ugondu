<?php
namespace AirRoofers\Operations\PlatformServices\Configuration;

class ConfigurationStore {
    private array $global_config = [];
    private array $platform_overrides = [];

    public function setGlobal(string $key, mixed $value): void {
        $this->global_config[$key] = $value;
    }

    public function setPlatformOverride(string $platform_id, string $key, mixed $value): void {
        if (!isset($this->platform_overrides[$platform_id])) {
            $this->platform_overrides[$platform_id] = [];
        }
        $this->platform_overrides[$platform_id][$key] = $value;
    }

    public function get(string $platform_id, string $key, mixed $default = null): mixed {
        if (isset($this->platform_overrides[$platform_id][$key])) {
            return $this->platform_overrides[$platform_id][$key];
        }

        return $this->global_config[$key] ?? $default;
    }
}
