<?php
namespace AirRoofers\Operations\PlatformServices\FeatureFlags;

class FeatureFlag {
    public string $key;
    public string $type; // Platform, Product, Customer, Experimental, Emergency
    public bool $is_enabled;
    public array $conditions;

    public function __construct(string $key, string $type, bool $is_enabled, array $conditions = []) {
        $this->key = $key;
        $this->type = $type;
        $this->is_enabled = $is_enabled;
        $this->conditions = $conditions;
    }
}
