<?php
namespace AirRoofers\Operations\PlatformServices\FeatureFlags;

class FeatureFlagManager {
    /** @var FeatureFlag[] */
    private array $flags = [];

    public function registerFlag(FeatureFlag $flag): void {
        $this->flags[$flag->key] = $flag;
    }

    public function isEnabled(string $key, array $context = []): bool {
        if (!isset($this->flags[$key])) {
            return false;
        }

        $flag = $this->flags[$key];

        // Emergency kill switches override everything
        if ($flag->type === 'Emergency') {
            return $flag->is_enabled;
        }

        // Basic check
        if (!$flag->is_enabled) {
            return false;
        }

        // Evaluate conditions if any
        if (!empty($flag->conditions)) {
            // Simplified condition evaluation for scoping
            foreach ($flag->conditions as $k => $v) {
                if (!isset($context[$k]) || $context[$k] !== $v) {
                    return false;
                }
            }
        }

        return true;
    }
}
