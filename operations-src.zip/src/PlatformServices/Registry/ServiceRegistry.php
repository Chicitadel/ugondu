<?php
namespace AirRoofers\Operations\PlatformServices\Registry;

class ServiceRegistry {
    /** @var PlatformRegistration[] */
    private array $platforms = [];

    public function register(PlatformRegistration $registration): void {
        $this->platforms[$registration->platform_id] = $registration;
    }

    public function discover(string $platform_id): ?PlatformRegistration {
        return $this->platforms[$platform_id] ?? null;
    }

    /**
     * @return PlatformRegistration[]
     */
    public function listAll(): array {
        return array_values($this->platforms);
    }
}
