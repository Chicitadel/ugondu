<?php
namespace AirRoofers\Operations\PlatformServices\Registry;

class PlatformRegistration {
    public string $platform_id;
    public string $version;
    public string $base_url;
    public string $health_endpoint;
    /** @var string[] */
    public array $event_types;
    /** @var string[] */
    public array $capabilities;
    public string $auth_method;
    
    // Expanded Metadata
    public array $supported_api_versions = [];
    public array $event_versions = [];
    public string $contract_version = '1.0';
    public string $certification_level = 'Uncertified';
    public int $maturity_level = 0;
    public string $deployment_environment = 'development';
    public string $release_version = '0.0.0';

    public function __construct(string $platform_id, string $version, string $base_url, string $health_endpoint, array $event_types, array $capabilities, string $auth_method) {
        $this->platform_id = $platform_id;
        $this->version = $version;
        $this->base_url = $base_url;
        $this->health_endpoint = $health_endpoint;
        $this->event_types = $event_types;
        $this->capabilities = $capabilities;
        $this->auth_method = $auth_method;
    }
}
