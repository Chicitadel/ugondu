<?php
namespace AirRoofers\Operations\PlatformServices\Events\DLQ;

class DeadLetterQueue {
    private array $dlq_records = [];

    public function moveToDLQ(string $event_id, string $reason, string $last_exception, int $retry_count): void {
        $this->dlq_records[$event_id] = [
            'event_id' => $event_id,
            'reason' => $reason,
            'last_exception' => $last_exception,
            'retry_count' => $retry_count,
            'failed_at' => date('Y-m-d\TH:i:s\Z')
        ];
    }

    public function getPoisonedMessages(): array {
        return array_values($this->dlq_records);
    }
}
