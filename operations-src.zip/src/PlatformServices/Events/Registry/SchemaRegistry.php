<?php
namespace AirRoofers\Operations\PlatformServices\Events\Registry;

class SchemaRegistry {
    private array $schemas = [];

    public function registerSchema(string $event_type, string $version, array $json_schema): void {
        $this->schemas[$event_type][$version] = $json_schema;
    }

    public function validatePayload(string $event_type, string $version, array $payload): bool {
        if (!isset($this->schemas[$event_type][$version])) {
            // Strictly speaking, if schema is not registered, event is invalid.
            return false;
        }

        // In a real implementation, this would use a JSON Schema validator library
        // against $this->schemas[$event_type][$version]
        
        return true; 
    }
}
