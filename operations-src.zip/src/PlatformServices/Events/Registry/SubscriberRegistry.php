<?php
namespace AirRoofers\Operations\PlatformServices\Events\Registry;

class SubscriberRegistry {
    private array $subscribers = [];

    public function registerSubscriber(string $event_type, string $subscriber_platform, string $webhook_endpoint): void {
        if (!isset($this->subscribers[$event_type])) {
            $this->subscribers[$event_type] = [];
        }

        $this->subscribers[$event_type][] = [
            'platform' => $subscriber_platform,
            'endpoint' => $webhook_endpoint,
            'registered_at' => date('Y-m-d\TH:i:s\Z')
        ];
    }

    public function getSubscribers(string $event_type): array {
        return $this->subscribers[$event_type] ?? [];
    }
}
