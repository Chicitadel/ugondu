<?php
namespace AirRoofers\Operations\PlatformServices\Events\Registry;

class EventRegistry {
    private array $registered_events = [];

    public function registerEvent(string $event_type, string $owner_platform, string $version, bool $is_deprecated = false): void {
        $this->registered_events[$event_type] = [
            'owner' => $owner_platform,
            'version' => $version,
            'deprecated' => $is_deprecated,
            'registered_at' => date('Y-m-d\TH:i:s\Z')
        ];
    }

    public function getEventInfo(string $event_type): ?array {
        return $this->registered_events[$event_type] ?? null;
    }
}
