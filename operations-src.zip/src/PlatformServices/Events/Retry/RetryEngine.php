<?php
namespace AirRoofers\Operations\PlatformServices\Events\Retry;

class RetryEngine {
    private array $backoff_schedule = [
        1 => 30,    // 30 seconds
        2 => 120,   // 2 minutes
        3 => 600    // 10 minutes
    ];

    public function calculateNextRetryTime(int $current_attempt): ?string {
        $next_attempt = $current_attempt + 1;
        
        if (!isset($this->backoff_schedule[$next_attempt])) {
            return null; // Exhausted retries, goes to DLQ
        }

        $delay_seconds = $this->backoff_schedule[$next_attempt];
        return date('Y-m-d\TH:i:s\Z', time() + $delay_seconds);
    }
}
