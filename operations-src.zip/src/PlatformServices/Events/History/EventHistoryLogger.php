<?php
namespace AirRoofers\Operations\PlatformServices\Events\History;

class EventHistoryLogger {
    private array $transitions = [];

    public function logTransition(string $event_id, string $from_status, string $to_status, string $context = ''): void {
        if (!isset($this->transitions[$event_id])) {
            $this->transitions[$event_id] = [];
        }

        // Immutable append only
        $this->transitions[$event_id][] = [
            'timestamp' => date('Y-m-d\TH:i:s\Z'),
            'from_status' => $from_status,
            'to_status' => $to_status,
            'context' => $context
        ];
    }

    public function getEventHistory(string $event_id): array {
        return $this->transitions[$event_id] ?? [];
    }
}
