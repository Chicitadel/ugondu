<?php
namespace AirRoofers\Operations\PlatformServices\Events\Dispatcher;

use AirRoofers\Operations\PlatformServices\Events\Outbox\OutboxRecord;
use AirRoofers\Operations\PlatformServices\Events\Registry\SchemaRegistry;
use AirRoofers\Operations\PlatformServices\Events\Registry\SubscriberRegistry;

class EventDispatcher {
    private SchemaRegistry $schemaRegistry;
    private SubscriberRegistry $subscriberRegistry;

    public function __construct(SchemaRegistry $schemaRegistry, SubscriberRegistry $subscriberRegistry) {
        $this->schemaRegistry = $schemaRegistry;
        $this->subscriberRegistry = $subscriberRegistry;
    }

    public function dispatch(OutboxRecord $record): void {
        // 1. Validate payload against schema
        $payloadArray = json_decode($record->payload, true);
        if (!$this->schemaRegistry->validatePayload($record->event_type, '1.0', $payloadArray)) {
            $record->status = 'FAILED';
            // Route to DLQ (handled by higher level orchestration)
            return;
        }

        // 2. Resolve subscribers
        $subscribers = $this->subscriberRegistry->getSubscribers($record->event_type);

        // 3. Dispatch (minimalist, no transformations)
        $allSuccessful = true;
        foreach ($subscribers as $subscriber) {
            $success = $this->sendWebhook($subscriber['endpoint'], $payloadArray);
            if (!$success) {
                $allSuccessful = false;
            }
        }

        // 4. Update status
        $record->status = $allSuccessful ? 'DISPATCHED' : 'FAILED';
    }

    private function sendWebhook(string $endpoint, array $payload): bool {
        // HTTP client logic here. Returns true on 200 OK.
        return true; 
    }
}
