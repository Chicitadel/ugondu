<?php
namespace AirRoofers\Operations\PlatformServices\Events\Outbox;

class OutboxRecord {
    public string $event_id;
    public string $aggregate_type;
    public string $aggregate_id;
    public string $event_type;
    public string $payload; // JSON
    public string $status; // PENDING, DISPATCHED, FAILED
    public string $created_at;

    public function __construct(string $event_id, string $aggregate_type, string $aggregate_id, string $event_type, string $payload) {
        $this->event_id = $event_id;
        $this->aggregate_type = $aggregate_type;
        $this->aggregate_id = $aggregate_id;
        $this->event_type = $event_type;
        $this->payload = $payload;
        $this->status = 'PENDING';
        $this->created_at = date('Y-m-d\TH:i:s\Z');
    }
}
