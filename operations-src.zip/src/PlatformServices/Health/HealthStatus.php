<?php
namespace AirRoofers\Operations\PlatformServices\Health;

class HealthStatus {
    public string $platform_id;
    public bool $liveness;
    public bool $readiness;
    public bool $database_connected;
    public array $certificate_expiry;
    public string $timestamp;

    public function __construct(string $platform_id, bool $liveness, bool $readiness, bool $database_connected, array $certificate_expiry, string $timestamp) {
        $this->platform_id = $platform_id;
        $this->liveness = $liveness;
        $this->readiness = $readiness;
        $this->database_connected = $database_connected;
        $this->certificate_expiry = $certificate_expiry;
        $this->timestamp = $timestamp;
    }
}
