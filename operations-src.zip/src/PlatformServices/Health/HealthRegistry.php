<?php
namespace AirRoofers\Operations\PlatformServices\Health;

class HealthRegistry {
    /** @var HealthStatus[] */
    private array $status_log = [];

    public function report(HealthStatus $status): void {
        $this->status_log[$status->platform_id] = $status;
    }

    public function getStatus(string $platform_id): ?HealthStatus {
        return $this->status_log[$platform_id] ?? null;
    }

    /**
     * @return HealthStatus[]
     */
    public function getSystemHealth(): array {
        return $this->status_log;
    }
}
