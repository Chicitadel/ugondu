<?php
declare(strict_types=1);

/******************************************************************************
 * Project        : Air Roofers Platform Core
 * Module         : Operations & Telemetry Metrics Service
 * File           : MetricsAggregator.php
 * Version        : 3.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Air Roofers Enterprise Operations
 * Created Date   : 2026-07-27
 * Last Modified  : 2026-07-27
 * Classification : ENTERPRISE | INTERNAL
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST SP 800-207
 *
 * Copyright (c) 2026 Air Roofers Enterprise Operations
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Metrics;

require_once __DIR__ . '/../../../src/Storage/StorageInterface.php';
require_once __DIR__ . '/../../../src/Storage/JsonStorageAdapter.php';

use AirRoofers\PlatformCore\Storage\JsonStorageAdapter;

class MetricsAggregator {
    private JsonStorageAdapter $storage;

    public function __construct(?string $storagePath = null) {
        $path = $storagePath ?? __DIR__ . '/../../metrics.json';
        $this->storage = new JsonStorageAdapter($path);
        
        $data = $this->storage->read() ?: [];
        if (empty($data)) {
            $data = [
                'start_time' => time(),
                'downtime_records' => [],
                'downtime_seconds' => 0,
                'services' => []
            ];
            $this->storage->write($data);
            $this->seedInitialMetrics();
        } elseif (!isset($data['services'])) {
            $data['services'] = [];
            $this->storage->write($data);
        }
    }

    public function seedInitialMetrics(): void {
        $subdomains = [
            'airroofers.eu', 'admin.airroofers.eu', 'api.airroofers.eu', 'billing.airroofers.eu',
            'bootstrap.airroofers.eu', 'certify.airroofers.eu', 'configuration.airroofers.eu',
            'console.airroofers.eu', 'developer.airroofers.eu', 'developers.airroofers.eu',
            'discovery.airroofers.eu', 'downloads.airroofers.eu', 'edge.airroofers.eu',
            'governance.airroofers.eu', 'hub.airroofers.eu', 'identity.airroofers.eu',
            'ingestion.airroofers.eu', 'license.airroofers.eu', 'marketplace.airroofers.eu',
            'notifications.airroofers.eu', 'operations.airroofers.eu', 'orchestrator.airroofers.eu',
            'portal.airroofers.eu', 'products.airroofers.eu', 'registry.airroofers.eu',
            'runtime.airroofers.eu', 'services.airroofers.eu', 'support.airroofers.eu',
            'telemetry.airroofers.eu', 'workspace.airroofers.eu', 'static.airroofers.eu',
            'upvcras.airroofers.eu', 'consunexia.airroofers.eu'
        ];

        $data = $this->storage->read() ?: [];
        if (!isset($data['services'])) {
            $data['services'] = [];
        }

        foreach ($subdomains as $domain) {
            if (!isset($data['services'][$domain])) {
                $data['services'][$domain] = [
                    'requests' => 0,
                    'errors' => 0,
                    'latency_ms' => 0,
                    'last_seen' => '',
                    'health_status' => 'unknown'
                ];
            }
        }
        $this->storage->write($data);
    }

    public function getUptime(): float {
        $data = $this->storage->read() ?: [];
        $startTime = $data['start_time'] ?? time();
        $uptimeSeconds = time() - $startTime;
        $downtime = $data['downtime_seconds'] ?? 0;
        
        if ($uptimeSeconds <= 0) {
            return 99.99;
        }
        
        return round(min(100.0, ($uptimeSeconds / max(1, $uptimeSeconds + $downtime)) * 100), 4);
    }

    public function aggregate(): array {
        $data = $this->storage->read() ?: [];
        $services = $data['services'] ?? [];
        
        $totalRequests = 0;
        $totalErrors = 0;
        $activeServices = count($services);
        $totalLatency = 0;
        $totalLatencySamples = 0;

        foreach ($services as $svc => $metrics) {
            $totalRequests += $metrics['requests'] ?? 0;
            $totalErrors += $metrics['errors'] ?? 0;
            
            if (!empty($metrics['latency_ms'])) {
                $totalLatency += $metrics['latency_ms'] * ($metrics['requests'] ?? 1);
                $totalLatencySamples += ($metrics['requests'] ?? 1);
            }
        }

        $avgLatency = $totalLatencySamples > 0 ? round($totalLatency / $totalLatencySamples, 2) : 0;
        $errorRate = $totalRequests > 0 ? round(($totalErrors / $totalRequests) * 100, 2) : 0;
        
        return [
            'active_services' => $activeServices,
            'total_requests' => $totalRequests,
            'error_rate' => $errorRate,
            'gateway_latency_ms' => $avgLatency,
            'uptime_percentage' => $this->getUptime(),
            'last_updated' => date('c'),
            'services' => $services
        ];
    }

    public function recordHealthCheck(string $service, bool $healthy, float $responseMs): void {
        $data = $this->storage->read() ?: [];
        if (!isset($data['services'][$service])) {
            $data['services'][$service] = [
                'requests' => 0,
                'errors' => 0,
                'latency_ms' => 0,
                'last_seen' => '',
                'health_status' => 'unknown'
            ];
        }
        
        $data['services'][$service]['health_status'] = $healthy ? 'healthy' : 'unhealthy';
        $data['services'][$service]['latency_ms'] = $responseMs;
        $data['services'][$service]['last_seen'] = date('c');
        
        $this->storage->write($data);
    }

    public function getServiceMetrics(string $serviceName): ?array {
        $data = $this->storage->read() ?: [];
        return $data['services'][$serviceName] ?? null;
    }

    public function recordRequest(string $service, float $latencyMs, int $statusCode): void {
        $data = $this->storage->read() ?: [];
        if (!isset($data['services'])) {
            $data['services'] = [];
        }
        
        if (!isset($data['services'][$service])) {
            $data['services'][$service] = [
                'requests' => 0,
                'errors' => 0,
                'latency_ms' => 0,
                'last_seen' => ''
            ];
        }
        
        $svcData = &$data['services'][$service];
        
        $prevRequests = $svcData['requests'];
        $prevLatency = $svcData['latency_ms'];
        
        $svcData['requests']++;
        if ($statusCode >= 400) {
            $svcData['errors']++;
        }
        
        $svcData['latency_ms'] = round((($prevLatency * $prevRequests) + $latencyMs) / $svcData['requests'], 2);
        $svcData['last_seen'] = date('c');
        
        $this->storage->write($data);
    }

    public function getHealthAggregate(): array {
        $data = $this->storage->read() ?: [];
        $services = $data['services'] ?? [];
        
        $health = [];
        $allHealthy = true;
        
        foreach ($services as $svc => $metrics) {
            $errors = $metrics['errors'] ?? 0;
            $reqs = $metrics['requests'] ?? 1;
            
            $errRate = ($errors / max(1, $reqs)) * 100;
            
            $status = 'healthy';
            if ($errRate > 5) {
                $status = 'degraded';
                $allHealthy = false;
            }
            if ($errRate > 20) {
                $status = 'unreachable';
                $allHealthy = false;
            }
            
            $health[$svc] = [
                'status' => $status,
                'http_code' => $status === 'healthy' ? 200 : 503,
                'latency_ms' => $metrics['latency_ms'] ?? 0
            ];
        }
        
        return [
            'overall_status' => $allHealthy ? 'healthy' : 'degraded',
            'services' => $health,
            'checked_at' => date('c')
        ];
    }
}
