<?php

/******************************************************************************
 * Project        : operations.airroofers.eu
 * Module         : Orchestration\Workflow\Assignment
 * File           : TaskAssigner.php
 * Version        : 1.0.0
 * Author         : Core Engineering Team
 * Organization   : AirRoofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Corporate Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 AirRoofers
 * All Rights Reserved.
 ******************************************************************************/

namespace App\Orchestration\Workflow\Assignment;

/**
 * Class TaskAssigner
 * 
 * Responsible for routing workflow tasks to specific queues or roles.
 */
class TaskAssigner
{
    /**
     * Assigns a task to a specific queue or role based on task metadata.
     *
     * @param string $taskId The unique identifier of the task.
     * @param array $metadata Contextual data for the task.
     * @return array Contains the assigned 'queue' and 'role'.
     */
    public function assign(string $taskId, array $metadata = []): array
    {
        $queue = 'default';
        $role = 'standard_operator';

        if (isset($metadata['priority']) && $metadata['priority'] === 'high') {
            $queue = 'urgent_queue';
            $role = 'supervisor';
        } elseif (isset($metadata['department'])) {
            $queue = $metadata['department'] . '_queue';
            $role = $metadata['department'] . '_specialist';
        }

        return [
            'task_id' => $taskId,
            'assigned_queue' => $queue,
            'assigned_role' => $role,
            'timestamp' => gmdate('Y-m-d\TH:i:s\Z')
        ];
    }
}
