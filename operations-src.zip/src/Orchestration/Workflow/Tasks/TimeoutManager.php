<?php

/******************************************************************************
 * Project        : Ujomor Platform
 * Module         : Orchestration
 * File           : TimeoutManager.php
 * Version        : 1.0.0
 * Author         : Ujomor Engineering
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Corporate Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/

namespace App\Orchestration\Workflow\Tasks;

/**
 * Manages task timeouts strictly by consuming the Scheduler capability.
 * Does not implement internal time logic.
 */
class TimeoutManager
{
    private $scheduler;

    /**
     * @param mixed $scheduler The scheduler capability dependency
     */
    public function __construct($scheduler)
    {
        $this->scheduler = $scheduler;
    }

    /**
     * Schedules a timeout for a given task.
     *
     * @param string|int $taskId The ID of the task to monitor
     * @param int $timeoutDuration The timeout duration (handled by the scheduler)
     * @return void
     */
    public function scheduleTaskTimeout($taskId, int $timeoutDuration): void
    {
        // Defer timeout logic directly to the scheduler capability
        $this->scheduler->schedule(
            'handleTaskTimeout',
            ['taskId' => $taskId],
            $timeoutDuration
        );
    }

    /**
     * Cancels an existing timeout for a task, typically upon task completion.
     *
     * @param string|int $taskId The ID of the task
     * @return void
     */
    public function clearTaskTimeout($taskId): void
    {
        // Defer cancellation logic directly to the scheduler capability
        $this->scheduler->cancel(
            'handleTaskTimeout',
            ['taskId' => $taskId]
        );
    }
}
