<?php
namespace AirRoofers\Operations\Orchestration\Workflow\Tasks;

use AirRoofers\Operations\Orchestration\Notifications\NotificationRouterInterface;
use AirRoofers\PlatformCore\Event\CloudEvent;

class HumanApprovalTask
{
    private NotificationRouterInterface $notificationRouter;

    public function __construct(NotificationRouterInterface $notificationRouter)
    {
        $this->notificationRouter = $notificationRouter;
    }

    /**
     * Executes the human approval task by requesting manual approval via the Notifications capability.
     * 
     * @param string $approverId The ID of the human approver.
     * @param string $workflowInstanceId The ID of the workflow instance requiring approval.
     * @param array $context Additional context required for the approval.
     */
    public function requestApproval(string $approverId, string $workflowInstanceId, array $context = []): void
    {
        $event = new CloudEvent(
            id: uniqid('event-', true),
            source: '/orchestration/workflow/human-approval',
            specversion: '1.0',
            type: 'airroofers.operations.workflow.approval_requested',
            data: [
                'approver_id' => $approverId,
                'workflow_instance_id' => $workflowInstanceId,
                'context' => $context,
                'action_required' => 'MANUAL_APPROVAL'
            ]
        );

        $this->notificationRouter->dispatch($event);
    }
}
