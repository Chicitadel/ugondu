<?php

/******************************************************************************
 * Project        : ujomor-platform
 * Module         : operations.airroofers.eu
 * File           : WorkflowMetrics.php
 * Version        : 1.0.0
 * Author         : Ujomor Engineering
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : INTERNAL
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/

namespace App\Orchestration\Workflow\Telemetry;

/**
 * Responsible for tracking workflow execution durations, failure rates,
 * and state transition latencies.
 */
class WorkflowMetrics
{
    /**
     * @var array<string, float>
     */
    private array $executionDurations = [];

    /**
     * @var array<string, int>
     */
    private array $failureCounts = [];

    /**
     * @var array<string, int>
     */
    private array $successCounts = [];

    /**
     * @var array<string, float>
     */
    private array $transitionLatencies = [];

    /**
     * Record the execution duration of a workflow.
     *
     * @param string $workflowId
     * @param float $durationInSeconds
     * @return void
     */
    public function recordExecutionDuration(string $workflowId, float $durationInSeconds): void
    {
        $this->executionDurations[$workflowId] = $durationInSeconds;
    }

    /**
     * Record a workflow failure.
     *
     * @param string $workflowId
     * @return void
     */
    public function recordFailure(string $workflowId): void
    {
        if (!isset($this->failureCounts[$workflowId])) {
            $this->failureCounts[$workflowId] = 0;
        }
        $this->failureCounts[$workflowId]++;
    }

    /**
     * Record a successful workflow execution.
     *
     * @param string $workflowId
     * @return void
     */
    public function recordSuccess(string $workflowId): void
    {
        if (!isset($this->successCounts[$workflowId])) {
            $this->successCounts[$workflowId] = 0;
        }
        $this->successCounts[$workflowId]++;
    }

    /**
     * Record latency for a state transition.
     *
     * @param string $workflowId
     * @param string $fromState
     * @param string $toState
     * @param float $latencyInSeconds
     * @return void
     */
    public function recordStateTransitionLatency(string $workflowId, string $fromState, string $toState, float $latencyInSeconds): void
    {
        $key = sprintf('%s:%s->%s', $workflowId, $fromState, $toState);
        $this->transitionLatencies[$key] = $latencyInSeconds;
    }

    /**
     * Calculate the failure rate for a specific workflow.
     *
     * @param string $workflowId
     * @return float
     */
    public function getFailureRate(string $workflowId): float
    {
        $failures = $this->failureCounts[$workflowId] ?? 0;
        $successes = $this->successCounts[$workflowId] ?? 0;
        $total = $failures + $successes;

        if ($total === 0) {
            return 0.0;
        }

        return $failures / $total;
    }

    /**
     * Get the recorded execution duration for a workflow.
     *
     * @param string $workflowId
     * @return float|null
     */
    public function getExecutionDuration(string $workflowId): ?float
    {
        return $this->executionDurations[$workflowId] ?? null;
    }

    /**
     * Get the recorded state transition latency.
     *
     * @param string $workflowId
     * @param string $fromState
     * @param string $toState
     * @return float|null
     */
    public function getStateTransitionLatency(string $workflowId, string $fromState, string $toState): ?float
    {
        $key = sprintf('%s:%s->%s', $workflowId, $fromState, $toState);
        return $this->transitionLatencies[$key] ?? null;
    }
}
