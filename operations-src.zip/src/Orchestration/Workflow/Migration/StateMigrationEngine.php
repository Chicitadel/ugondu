<?php
/******************************************************************************
 * Project        : Universal Autonomous AI Governance Operating System (UAIGOS)
 * Module         : Orchestration\Workflow\Migration
 * File           : StateMigrationEngine.php
 * Version        : 1.0.0
 * Author         : Antigravity AI
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/

declare(strict_types=1);

namespace App\Orchestration\Workflow\Migration;

use RuntimeException;

/**
 * Interface MigrationStrategyInterface
 * Defines the contract for workflow state migration strategies.
 */
interface MigrationStrategyInterface
{
    /**
     * Migrate the given suspended state to the target version state.
     *
     * @param array<string, mixed> $state
     * @return array<string, mixed>
     */
    public function migrateState(array $state): array;
}

/**
 * StateMigrationEngine is responsible for migrating suspended workflow instances
 * from older definition versions to newer definition versions.
 */
class StateMigrationEngine
{
    /**
     * @var array<string, MigrationStrategyInterface>
     */
    private array $strategies = [];

    /**
     * Register a migration strategy for a specific workflow version transition.
     *
     * @param string $workflowType
     * @param string $fromVersion
     * @param string $toVersion
     * @param MigrationStrategyInterface $strategy
     */
    public function registerStrategy(
        string $workflowType,
        string $fromVersion,
        string $toVersion,
        MigrationStrategyInterface $strategy
    ): void {
        $key = $this->buildStrategyKey($workflowType, $fromVersion, $toVersion);
        $this->strategies[$key] = $strategy;
    }

    /**
     * Migrate a suspended workflow instance state to the target version.
     *
     * @param string $workflowType
     * @param string $currentVersion
     * @param string $targetVersion
     * @param array<string, mixed> $suspendedState
     * @return array<string, mixed> The migrated state
     * @throws RuntimeException If no migration strategy is found
     */
    public function migrate(
        string $workflowType,
        string $currentVersion,
        string $targetVersion,
        array $suspendedState
    ): array {
        if ($currentVersion === $targetVersion) {
            return $suspendedState;
        }

        $key = $this->buildStrategyKey($workflowType, $currentVersion, $targetVersion);

        if (!isset($this->strategies[$key])) {
            throw new RuntimeException(
                sprintf(
                    'No migration strategy registered for %s from version %s to %s',
                    $workflowType,
                    $currentVersion,
                    $targetVersion
                )
            );
        }

        return $this->strategies[$key]->migrateState($suspendedState);
    }

    /**
     * Determine if a migration path exists between two versions.
     *
     * @param string $workflowType
     * @param string $fromVersion
     * @param string $toVersion
     * @return bool
     */
    public function canMigrate(string $workflowType, string $fromVersion, string $toVersion): bool
    {
        if ($fromVersion === $toVersion) {
            return true;
        }

        $key = $this->buildStrategyKey($workflowType, $fromVersion, $toVersion);
        return isset($this->strategies[$key]);
    }

    /**
     * Build the strategy lookup key.
     *
     * @param string $workflowType
     * @param string $fromVersion
     * @param string $toVersion
     * @return string
     */
    private function buildStrategyKey(string $workflowType, string $fromVersion, string $toVersion): string
    {
        return sprintf('%s:%s->%s', $workflowType, $fromVersion, $toVersion);
    }
}
