<?php
namespace AirRoofers\Operations\Orchestration\Workflow;

use AirRoofers\PlatformCore\Event\CloudEvent;

interface WorkflowEngineInterface
{
    /**
     * Start a new workflow instance based on a trigger event.
     */
    public function startWorkflow(string $workflowName, CloudEvent $triggerEvent): string;

    /**
     * Advance a workflow state based on an incoming event.
     */
    public function handleEvent(CloudEvent $event): void;

    /**
     * Trigger a compensating action for a failed workflow saga.
     */
    public function compensate(string $workflowInstanceId): void;
}
