<?php
/******************************************************************************
 * Project        : ujomor-platform
 * Module         : Orchestration\Workflow\Engine
 * File           : RuntimeEngine.php
 * Version        : 1.0.0
 * Author         : AI Governed
 * Organization   : AirRoofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : INTERNAL
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 AirRoofers
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Orchestration\Workflow\Engine;

use AirRoofers\Operations\Orchestration\Workflow\Contracts\WorkflowInstanceContract;
use AirRoofers\Operations\Orchestration\Workflow\Contracts\WorkflowDefinitionContract;
use InvalidArgumentException;
use RuntimeException;

/**
 * Class RuntimeEngine
 * 
 * Responsible for advancing WorkflowInstanceContract states based on incoming triggers.
 */
class RuntimeEngine
{
    /**
     * Advances the workflow instance state based on the provided trigger.
     *
     * @param WorkflowInstanceContract $instance The workflow instance to advance.
     * @param WorkflowDefinitionContract $definition The workflow definition.
     * @param string $trigger The event/trigger name that causes state transition.
     * @param array $payload Optional payload for the transition.
     * @return string The resulting next state ID.
     * @throws RuntimeException If the transition is invalid or execution fails.
     */
    public function advanceState(
        WorkflowInstanceContract $instance,
        WorkflowDefinitionContract $definition,
        string $trigger,
        array $payload = []
    ): string {
        if ($instance->getDefinitionId() !== $definition->getDefinitionId()) {
            throw new InvalidArgumentException('Workflow instance definition ID does not match definition contract ID.');
        }

        if ($instance->getStatus() !== 'RUNNING' && $instance->getStatus() !== 'SUSPENDED') {
            throw new RuntimeException('Cannot advance workflow instance in status: ' . $instance->getStatus());
        }

        $currentState = $instance->getCurrentState();
        $states = $definition->getStates();

        if (!isset($states[$currentState])) {
            throw new RuntimeException('Current state not found in definition: ' . $currentState);
        }

        $stateDefinition = $states[$currentState];
        
        // Lookup transitions for the current state based on the trigger
        $transitions = $stateDefinition['transitions'] ?? [];
        if (!isset($transitions[$trigger])) {
            throw new RuntimeException("Trigger '{$trigger}' is not valid for current state: {$currentState}");
        }

        $nextState = $transitions[$trigger];

        if (!isset($states[$nextState])) {
            throw new RuntimeException('Next state not found in definition: ' . $nextState);
        }

        // Processing payload and side effects would go here.
        // E.g., validating payload, executing action handlers.

        return $nextState;
    }
}
