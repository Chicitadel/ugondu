<?php
/******************************************************************************
 * Project        : operations.airroofers.eu
 * Module         : Orchestration
 * File           : DefinitionEngine.php
 * Version        : 1.0.0
 * Author         : Governance Authority
 * Organization   : AirRoofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : INTERNAL
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 AirRoofers
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Orchestration\Workflow\Engine;

use AirRoofers\Operations\Orchestration\Workflow\Contracts\WorkflowDefinitionContract;
use InvalidArgumentException;

/**
 * Class DefinitionEngine
 * 
 * Responsible for parsing and validating Workflow DAGs.
 */
class DefinitionEngine
{
    /**
     * Parses and validates a Workflow Definition DAG against the contract.
     *
     * @param WorkflowDefinitionContract $definition
     * @throws InvalidArgumentException if the DAG is invalid
     * @return bool
     */
    public function validate(WorkflowDefinitionContract $definition): bool
    {
        $states = $definition->getStates();
        $initialState = $definition->getInitialState();

        if (empty($states)) {
            throw new InvalidArgumentException("Workflow definition must have at least one state.");
        }

        if (!array_key_exists($initialState, $states)) {
            throw new InvalidArgumentException(sprintf("Initial state '%s' is not defined in states.", $initialState));
        }

        // Validate transitions and check for missing states
        foreach ($states as $stateName => $stateConfig) {
            if (isset($stateConfig['transitions'])) {
                foreach ($stateConfig['transitions'] as $transitionEvent => $targetState) {
                    if (!array_key_exists($targetState, $states)) {
                        throw new InvalidArgumentException(sprintf(
                            "Target state '%s' for transition '%s' from state '%s' does not exist.",
                            $targetState,
                            $transitionEvent,
                            $stateName
                        ));
                    }
                }
            }
        }

        // Validate Directed Acyclic Graph (DAG) property by checking for cycles
        if ($this->hasCycles($states)) {
             throw new InvalidArgumentException("Workflow definition contains cycles, which is not allowed in a DAG.");
        }

        return true;
    }

    /**
     * Check if the states form a cycle.
     *
     * @param array $states
     * @return bool
     */
    private function hasCycles(array $states): bool
    {
        $visited = [];
        $recursionStack = [];

        foreach (array_keys($states) as $node) {
            $visited[$node] = false;
            $recursionStack[$node] = false;
        }

        foreach (array_keys($states) as $node) {
            if (!$visited[$node]) {
                if ($this->dfs($node, $states, $visited, $recursionStack)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Depth-first search for cycle detection.
     *
     * @param string $node
     * @param array $states
     * @param array $visited
     * @param array $recursionStack
     * @return bool
     */
    private function dfs(string $node, array $states, array &$visited, array &$recursionStack): bool
    {
        $visited[$node] = true;
        $recursionStack[$node] = true;

        if (isset($states[$node]['transitions'])) {
            foreach ($states[$node]['transitions'] as $targetState) {
                if (!$visited[$targetState] && $this->dfs($targetState, $states, $visited, $recursionStack)) {
                    return true;
                } elseif ($recursionStack[$targetState]) {
                    return true;
                }
            }
        }

        $recursionStack[$node] = false;
        return false;
    }
}
