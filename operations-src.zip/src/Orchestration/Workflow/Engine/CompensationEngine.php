<?php

/******************************************************************************
 * Project        : Ujomor Platform
 * Module         : Orchestration
 * File           : CompensationEngine.php
 * Version        : 1.0.0
 * Author         : Human Author
 * Organization   : Airroofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : INTERNAL
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Airroofers
 * All Rights Reserved.
 ******************************************************************************/

namespace Orchestration\Workflow\Engine;

/**
 * CompensationEngine handles the unwinding of workflow states
 * upon failure, implementing the Saga pattern.
 */
class CompensationEngine
{
    private array $compensationLog = [];

    /**
     * Records a compensation step to be executed if a failure occurs.
     *
     * @param string $workflowId The ID of the workflow.
     * @param callable $compensationAction The action to execute to compensate.
     */
    public function recordCompensationStep(string $workflowId, callable $compensationAction): void
    {
        if (!isset($this->compensationLog[$workflowId])) {
            $this->compensationLog[$workflowId] = [];
        }

        // Prepend to execute in reverse order (LIFO)
        array_unshift($this->compensationLog[$workflowId], $compensationAction);
    }

    /**
     * Executes the compensation steps for a given workflow in reverse order.
     *
     * @param string $workflowId The ID of the workflow.
     * @return bool True if all compensation steps succeeded, false otherwise.
     */
    public function compensate(string $workflowId): bool
    {
        if (!isset($this->compensationLog[$workflowId])) {
            return true; // Nothing to compensate
        }

        $success = true;
        foreach ($this->compensationLog[$workflowId] as $step) {
            try {
                $step();
            } catch (\Exception $e) {
                // Log the failure but continue attempting other compensation steps
                error_log("Compensation step failed for workflow {$workflowId}: " . $e->getMessage());
                $success = false;
            }
        }

        // Clear the log after execution
        unset($this->compensationLog[$workflowId]);

        return $success;
    }
}
