<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Orchestration
 * File           : WorkflowDefinitionContract.php
 * Version        : 1.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Ujomor Engineering
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 *
 * Copyright (c) 2026 Ujomor Engineering
 * All Rights Reserved.
 ******************************************************************************/
namespace AirRoofers\Operations\Orchestration\Workflow\Contracts;

/**
 * Interface WorkflowDefinitionContract
 * @version 1.0.0
 */
interface WorkflowDefinitionContract
{
    public function getDefinitionId(): string;
    public function getVersion(): string;
    public function getStates(): array; // Directed Acyclic Graph (DAG) of the workflow steps
    public function getInitialState(): string;
    public function getMetadata(): array;
}
