<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Orchestration
 * File           : WorkflowInstanceContract.php
 * Version        : 1.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Ujomor Engineering
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 *
 * Copyright (c) 2026 Ujomor Engineering
 * All Rights Reserved.
 ******************************************************************************/
namespace AirRoofers\Operations\Orchestration\Workflow\Contracts;

/**
 * Interface WorkflowInstanceContract
 * @version 1.0.0
 */
interface WorkflowInstanceContract
{
    public function getInstanceId(): string;
    public function getDefinitionId(): string;
    public function getDefinitionVersion(): string;
    public function getCurrentState(): string;
    public function getContextData(): array; // Persisted workflow context state
    public function getStatus(): string; // 'RUNNING', 'SUSPENDED', 'COMPLETED', 'FAILED'
    public function getStartedAt(): \DateTimeImmutable;
}
