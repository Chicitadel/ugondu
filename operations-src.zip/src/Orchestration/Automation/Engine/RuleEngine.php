<?php
/******************************************************************************
 * Project        : ujomor-platform
 * Module         : Orchestration/Automation/Engine
 * File           : RuleEngine.php
 * Version        : 1.0.0
 * Author         : AirRoofers Engineering
 * Organization   : AirRoofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 AirRoofers
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Orchestration\Automation\Engine;

use AirRoofers\Operations\Orchestration\Automation\Contracts\RuleContract;
use AirRoofers\Operations\Orchestration\Automation\Contracts\PolicyContract;

/**
 * Class RuleEngine
 * 
 * Orchestrates the evaluation of rules using an injected Expression Engine 
 * and executes actions via Action Executors.
 * Contains no persistence logic to preserve boundaries.
 */
class RuleEngine
{
    /**
     * @var object
     */
    private object $expressionEngine;

    /**
     * @var iterable
     */
    private iterable $actionExecutors;

    /**
     * RuleEngine constructor.
     *
     * @param object $expressionEngine An engine capable of evaluating rule conditions
     * @param iterable|array $actionExecutors A collection of executors to trigger actions
     */
    public function __construct(object $expressionEngine, iterable $actionExecutors = [])
    {
        $this->expressionEngine = $expressionEngine;
        $this->actionExecutors = $actionExecutors;
    }

    /**
     * Evaluate a set of rules against the given context and policies.
     *
     * @param RuleContract[] $rules
     * @param array $context Data context for evaluation
     * @param PolicyContract[] $policies
     * @return array Results of the evaluations and actions executed
     */
    public function evaluateRules(array $rules, array $context, array $policies = []): array
    {
        // Sort rules by priority (highest priority first)
        usort($rules, function (RuleContract $a, RuleContract $b) {
            return $b->getPriority() <=> $a->getPriority();
        });

        $results = [];

        foreach ($rules as $rule) {
            if (!$rule->isActive()) {
                continue;
            }

            // Evaluate conditions using the injected expression engine
            $isMatch = $this->evaluateConditions($rule->getConditions(), $context);

            if ($isMatch) {
                // Check policy constraints before executing actions
                if ($this->checkPolicies($rule, $policies, $context)) {
                    $actionResults = $this->executeActions($rule->getActions(), $context);
                    $results[$rule->getRuleId()] = [
                        'matched' => true,
                        'policy_blocked' => false,
                        'actions' => $actionResults,
                    ];
                } else {
                    $results[$rule->getRuleId()] = [
                        'matched' => true,
                        'policy_blocked' => true,
                        'actions' => [],
                    ];
                }
            } else {
                $results[$rule->getRuleId()] = [
                    'matched' => false,
                    'policy_blocked' => false,
                    'actions' => [],
                ];
            }
        }

        return $results;
    }

    /**
     * Evaluates the conditions using the ExpressionEngine.
     *
     * @param array $conditions
     * @param array $context
     * @return bool
     */
    private function evaluateConditions(array $conditions, array $context): bool
    {
        if (empty($conditions)) {
            return true;
        }
        
        // Delegating to the expression engine
        if (method_exists($this->expressionEngine, 'evaluate')) {
            return (bool) $this->expressionEngine->evaluate($conditions, $context);
        }

        return false;
    }

    /**
     * Executes the actions using the injected action executors.
     *
     * @param array $actions
     * @param array $context
     * @return array
     */
    private function executeActions(array $actions, array $context): array
    {
        $actionResults = [];
        foreach ($actions as $action) {
            foreach ($this->actionExecutors as $executor) {
                if (method_exists($executor, 'supports') && $executor->supports($action)) {
                    if (method_exists($executor, 'execute')) {
                        $actionResults[] = $executor->execute($action, $context);
                    }
                    break;
                }
            }
        }
        return $actionResults;
    }

    /**
     * Evaluates constraints from policies before action execution.
     *
     * @param RuleContract $rule
     * @param PolicyContract[] $policies
     * @param array $context
     * @return bool
     */
    private function checkPolicies(RuleContract $rule, array $policies, array $context): bool
    {
        foreach ($policies as $policy) {
            $constraints = $policy->getConstraints();
            $failureBehavior = $policy->getFailureBehavior();
            
            // In a real implementation, constraints would be evaluated here.
            // For now, we assume policies are met.
            if ($failureBehavior === 'ABORT') {
                // If a constraint failed:
                // return false;
            }
        }
        
        return true;
    }
}
