<?php
/******************************************************************************
 * Project        : Ujomor Platform
 * Module         : Orchestration\Automation\Expressions
 * File           : ExpressionEngine.php
 * Version        : 1.0.0
 * Author         : Antigravity
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : INTERNAL
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/

namespace Orchestration\Automation\Expressions;

use DateTime;
use Exception;

class ExpressionEngine
{
    private array $variables = [];

    public function __construct(array $variables = [])
    {
        $this->variables = $variables;
    }

    public function setVariable(string $name, mixed $value): void
    {
        $this->variables[$name] = $value;
    }

    public function getVariable(string $name): mixed
    {
        return $this->variables[$name] ?? null;
    }

    public function evaluate(array $expression): bool
    {
        if (!isset($expression['operator'])) {
            throw new Exception("Expression must have an operator.");
        }

        $operator = $expression['operator'];

        if (in_array($operator, ['AND', 'OR', 'NOT'])) {
            return $this->evaluateBooleanOperator($expression);
        }

        return $this->evaluateComparison($expression);
    }

    private function evaluateBooleanOperator(array $expression): bool
    {
        $operator = $expression['operator'];

        if ($operator === 'NOT') {
            if (!isset($expression['operand'])) {
                throw new Exception("NOT operator requires an operand.");
            }
            return !$this->evaluate($expression['operand']);
        }

        if (!isset($expression['operands']) || !is_array($expression['operands'])) {
            throw new Exception("$operator operator requires an array of operands.");
        }

        foreach ($expression['operands'] as $operand) {
            $result = $this->evaluate($operand);
            if ($operator === 'AND' && !$result) {
                return false;
            }
            if ($operator === 'OR' && $result) {
                return true;
            }
        }

        return $operator === 'AND';
    }

    private function evaluateComparison(array $expression): bool
    {
        $operator = $expression['operator'];
        $left = $this->resolveValue($expression['left'] ?? null);
        $right = $this->resolveValue($expression['right'] ?? null);

        switch ($operator) {
            case 'EQUALS':
                return $left === $right;
            case 'NOT_EQUALS':
                return $left !== $right;
            case 'GREATER_THAN':
                return $left > $right;
            case 'LESS_THAN':
                return $left < $right;
            case 'GREATER_THAN_OR_EQUALS':
                return $left >= $right;
            case 'LESS_THAN_OR_EQUALS':
                return $left <= $right;
            case 'IN':
                return is_array($right) && in_array($left, $right, true);
            case 'NOT_IN':
                return is_array($right) && !in_array($left, $right, true);
            case 'CONTAINS':
                return is_string($left) && is_string($right) && strpos($left, $right) !== false;
            case 'NOT_CONTAINS':
                return is_string($left) && is_string($right) && strpos($left, $right) === false;
            case 'DATE_AFTER':
                return $this->compareDates($left, $right) > 0;
            case 'DATE_BEFORE':
                return $this->compareDates($left, $right) < 0;
            default:
                throw new Exception("Unknown operator: $operator");
        }
    }

    private function resolveValue(mixed $value): mixed
    {
        if (is_string($value) && strpos($value, '$') === 0) {
            return $this->getVariable(substr($value, 1));
        }
        return $value;
    }

    private function compareDates(mixed $left, mixed $right): int
    {
        $date1 = new DateTime($this->resolveDateValue($left));
        $date2 = new DateTime($this->resolveDateValue($right));

        return $date1 <=> $date2;
    }

    private function resolveDateValue(mixed $value): string
    {
        if ($value === 'NOW') {
            return 'now';
        }
        return (string) $value;
    }

    public function evaluateCollection(array $collection, array $expression): array
    {
        $filtered = [];
        foreach ($collection as $item) {
            $itemEngine = new self(array_merge($this->variables, is_array($item) ? $item : ['item' => $item]));
            if ($itemEngine->evaluate($expression)) {
                $filtered[] = $item;
            }
        }
        return $filtered;
    }
}
