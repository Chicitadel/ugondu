<?php
namespace AirRoofers\Operations\Orchestration\Automation;

use AirRoofers\PlatformCore\Event\CloudEvent;

interface AutomationRuleEngineInterface
{
    /**
     * Evaluate rules against an incoming event.
     */
    public function evaluate(CloudEvent $event): void;

    /**
     * Register a new automation rule mapping a trigger to an action sequence.
     */
    public function registerRule(string $triggerEventType, array $actionsToEmit): void;
}
