<?php

/******************************************************************************
 * Project        : operations.airroofers.eu
 * Module         : Orchestration\Automation\Executors
 * File           : ActionExecutorInterface.php
 * Version        : 1.0.0
 * Author         : Architecture Authority
 * Organization   : AirRoofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : INTERNAL
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 AirRoofers
 * All Rights Reserved.
 ******************************************************************************/

namespace Operations\AirRoofers\Orchestration\Automation\Executors;

/**
 * Interface ActionExecutorInterface
 *
 * Defines the contract for all action executors.
 */
interface ActionExecutorInterface
{
    /**
     * Executes the given action with the provided context/payload.
     *
     * @param array $context The execution context or payload.
     * @return bool True if execution succeeded, false otherwise.
     */
    public function execute(array $context): bool;
}
