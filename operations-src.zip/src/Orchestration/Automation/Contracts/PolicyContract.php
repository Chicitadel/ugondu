<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Orchestration
 * File           : PolicyContract.php
 * Version        : 1.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Ujomor Engineering
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 *
 * Copyright (c) 2026 Ujomor Engineering
 * All Rights Reserved.
 ******************************************************************************/
namespace AirRoofers\Operations\Orchestration\Automation\Contracts;

/**
 * Interface PolicyContract
 * @version 1.0.0
 */
interface PolicyContract
{
    public function getPolicyId(): string;
    public function getVersion(): string;
    public function getScope(): string; // e.g., 'GLOBAL', 'TENANT_SPECIFIC'
    public function getConstraints(): array; // E.g., max executions per minute
    public function getFailureBehavior(): string; // e.g., 'ABORT', 'CONTINUE', 'ESCALATE'
}
