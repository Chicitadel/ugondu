<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Orchestration
 * File           : RuleContract.php
 * Version        : 1.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Ujomor Engineering
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 *
 * Copyright (c) 2026 Ujomor Engineering
 * All Rights Reserved.
 ******************************************************************************/
namespace AirRoofers\Operations\Orchestration\Automation\Contracts;

/**
 * Interface RuleContract
 * @version 1.0.0
 */
interface RuleContract
{
    public function getRuleId(): string;
    public function getVersion(): string;
    public function getConditions(): array; // The expression logic to evaluate
    public function getActions(): array; // The actions to trigger on match
    public function getPriority(): int;
    public function getTenantId(): string;
    public function isActive(): bool;
}
