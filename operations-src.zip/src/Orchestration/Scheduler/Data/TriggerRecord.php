<?php
namespace AirRoofers\Operations\Orchestration\Scheduler\Data;

class TriggerRecord
{
    public string $id;
    public string $type; // 'ONCE', 'RELATIVE', 'RECURRING', 'DAILY', 'BUSINESS_DAYS'
    public string $scheduleDefinition; // e.g., timestamp, interval, cron string
    public string $timeZone; // e.g. 'UTC', 'Europe/Paris'
    public string $status; // 'ACTIVE', 'PAUSED', 'COMPLETED', 'CANCELLED'
    
    // Policies
    public string $misfirePolicy = Policies::MISFIRE_RESCHEDULE;
    public string $concurrencyPolicy = Policies::CONCURRENCY_ALLOW_PARALLEL;
    public string $priority = Policies::PRIORITY_NORMAL;
    
    // Event Payload & Metadata
    public string $payloadEventType;
    public string $payloadEventData; 
    public string $originPlatform;
    public string $originService;
    public string $tenant;
    public string $correlationId;
}
