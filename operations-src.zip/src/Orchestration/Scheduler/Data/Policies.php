<?php
namespace AirRoofers\Operations\Orchestration\Scheduler\Data;

class Policies
{
    // Misfire Policies
    public const MISFIRE_EXECUTE_IMMEDIATELY = 'ExecuteImmediately';
    public const MISFIRE_SKIP = 'Skip';
    public const MISFIRE_RESCHEDULE = 'Reschedule';
    public const MISFIRE_FAIL = 'Fail';

    // Concurrency Policies
    public const CONCURRENCY_ALLOW_PARALLEL = 'AllowParallel';
    public const CONCURRENCY_SKIP_IF_RUNNING = 'SkipIfRunning';
    public const CONCURRENCY_QUEUE_NEXT = 'QueueNext';
    public const CONCURRENCY_REPLACE_RUNNING = 'ReplaceRunning';

    // Job Priorities
    public const PRIORITY_CRITICAL = 'Critical';
    public const PRIORITY_HIGH = 'High';
    public const PRIORITY_NORMAL = 'Normal';
    public const PRIORITY_LOW = 'Low';
}
