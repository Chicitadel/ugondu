<?php
namespace AirRoofers\Operations\Orchestration\Scheduler\Data;

class ExecutionRecord
{
    public string $id; // Unique Execution ID (used for Idempotency in CloudEvents)
    public string $triggerId; // Link to the originating Trigger
    public \DateTimeImmutable $scheduledAt; // When it was SUPPOSED to run (UTC internally)
    public ?\DateTimeImmutable $executedAt = null; // When it ACTUALLY ran
    public string $status; // 'PENDING', 'STARTED', 'COMPLETED', 'FAILED', 'CANCELLED'
    public int $retryCount = 0;
}
