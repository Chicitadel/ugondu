<?php
namespace AirRoofers\Operations\Orchestration\Scheduler;

use AirRoofers\PlatformCore\Event\CloudEvent;

interface JobSchedulerInterface
{
    /**
     * Schedule a job to emit an event at a specific absolute time.
     */
    public function scheduleAt(\DateTimeImmutable $executeAt, string $timeZone, CloudEvent $eventToEmit, array $policies = []): string;

    /**
     * Schedule a job to emit an event after a relative time interval.
     */
    public function scheduleRelative(\DateInterval $delay, string $timeZone, CloudEvent $eventToEmit, array $policies = []): string;

    /**
     * Schedule a recurring job using a cron expression.
     */
    public function scheduleRecurring(string $cronExpression, string $timeZone, CloudEvent $eventToEmit, array $policies = []): string;

    /**
     * High-level schedule: Daily at a specific time.
     */
    public function scheduleDaily(string $timeOfDay, string $timeZone, CloudEvent $eventToEmit, array $policies = []): string;

    /**
     * High-level schedule: Only on business days at a specific time.
     */
    public function scheduleBusinessDays(string $timeOfDay, string $timeZone, CloudEvent $eventToEmit, array $policies = []): string;

    /**
     * Cancel a scheduled trigger completely.
     */
    public function cancel(string $triggerId): void;

    /**
     * Get the status of a specific trigger and its executions.
     */
    public function getStatus(string $triggerId): array;

    /**
     * Pause a scheduled trigger from generating further executions.
     */
    public function pause(string $triggerId): void;

    /**
     * Resume a paused trigger.
     */
    public function resume(string $triggerId): void;

    /**
     * Reschedule a trigger with a new schedule definition.
     */
    public function reschedule(string $triggerId, string $newScheduleDefinition): void;

    /**
     * List all pending executions based on filters.
     */
    public function listPending(array $filters): array;

    /**
     * List all currently running executions based on filters.
     */
    public function listRunning(array $filters): array;
}
