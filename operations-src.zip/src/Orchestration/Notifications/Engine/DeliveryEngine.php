<?php
/******************************************************************************
 * Project        : AirRoofers Operations
 * Module         : Orchestration/Notifications
 * File           : DeliveryEngine.php
 * Version        : 1.0.0
 * Author         : AI Agent
 * Organization   : AirRoofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : INTERNAL
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 AirRoofers
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Orchestration\Notifications\Engine;

use AirRoofers\Operations\Orchestration\Notifications\Contracts\DeliveryPlan;
use AirRoofers\Operations\Orchestration\Notifications\Contracts\NotificationEnvelope;
use AirRoofers\Operations\Orchestration\Notifications\Contracts\ProviderInterface;
use AirRoofers\Operations\Orchestration\Notifications\Contracts\RecipientResolverInterface;
use AirRoofers\Operations\Orchestration\Notifications\Contracts\TemplateEngineInterface;
use AirRoofers\Operations\Orchestration\Notifications\Events\NotificationQueued;
use AirRoofers\Operations\Orchestration\Notifications\Events\NotificationSent;
use AirRoofers\Operations\Orchestration\Notifications\Events\NotificationDelivered;
use AirRoofers\Operations\Orchestration\Notifications\Events\NotificationFailed;
use Psr\EventDispatcher\EventDispatcherInterface;

class DeliveryEngine
{
    /**
     * @var iterable<ProviderInterface>
     */
    private iterable $providers;

    public function __construct(
        private RecipientResolverInterface $resolver,
        private TemplateEngineInterface $templateEngine,
        private EventDispatcherInterface $eventDispatcher,
        iterable $providers
    ) {
        $this->providers = $providers;
    }

    public function deliver(NotificationEnvelope $envelope): void
    {
        try {
            // 1. Resolve Recipient to a concrete Delivery Plan
            $plan = $this->resolver->resolve($envelope);

            // 2. Render templates for the resolved channels
            $plan = $this->templateEngine->render($plan);

            // Emit NotificationQueued (as per EVENT-ORCHESTRATION-NOTIFICATIONS.md)
            $this->eventDispatcher->dispatch(new NotificationQueued($plan, $envelope));

            $channels = $plan->getResolvedChannels();
            
            // 3. Dispatch via Providers
            foreach ($channels as $channel) {
                $provider = $this->getProviderForChannel($channel);
                if (!$provider) {
                    $this->eventDispatcher->dispatch(new NotificationFailed(
                        $plan, 
                        "No provider supported for channel: {$channel}"
                    ));
                    continue;
                }

                try {
                    $receipt = $provider->send($plan, $channel);
                    
                    if ($receipt->getStatus() === 'DELIVERED') {
                        $this->eventDispatcher->dispatch(new NotificationDelivered($plan, $receipt));
                    } elseif ($receipt->getStatus() === 'SENT') {
                        $this->eventDispatcher->dispatch(new NotificationSent($plan, $receipt));
                    } else {
                        $this->eventDispatcher->dispatch(new NotificationFailed(
                            $plan, 
                            $receipt->getErrorMessage() ?? "Delivery failed via {$channel}"
                        ));
                    }
                } catch (\Throwable $e) {
                    $this->eventDispatcher->dispatch(new NotificationFailed(
                        $plan, 
                        $e->getMessage()
                    ));
                }
            }
        } catch (\Throwable $e) {
             // In case it fails before we even get a DeliveryPlan, we still fail.
             $this->eventDispatcher->dispatch(new NotificationFailed(
                 null, // Plan may be null here
                 $e->getMessage()
             ));
        }
    }

    private function getProviderForChannel(string $channel): ?ProviderInterface
    {
        foreach ($this->providers as $provider) {
            if ($provider->supportsChannel($channel)) {
                return $provider;
            }
        }
        return null;
    }
}
