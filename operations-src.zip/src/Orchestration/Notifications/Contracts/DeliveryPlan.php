<?php
namespace AirRoofers\Operations\Orchestration\Notifications\Contracts;

interface DeliveryPlan
{
    public function getPlanId(): string;
    public function getNotificationEnvelope(): NotificationEnvelope;
    public function getResolvedChannels(): array; // e.g. ['EMAIL', 'PUSH']
    public function getResolvedContent(): array; // e.g. ['subject' => '...', 'body' => '...']
    public function getStatus(): string; // 'QUEUED', 'IN_PROGRESS', 'COMPLETED', 'FAILED'
}
