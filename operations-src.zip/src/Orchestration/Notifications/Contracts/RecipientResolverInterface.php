<?php
namespace AirRoofers\Operations\Orchestration\Notifications\Contracts;

interface RecipientResolverInterface
{
    /**
     * Resolves an abstract recipient ID (e.g. User ID, Org ID) into a concrete Delivery Plan
     * by applying user preferences, tenant defaults, and opt-in/opt-out rules.
     */
    public function resolve(NotificationEnvelope $envelope): DeliveryPlan;
}
