<?php
namespace AirRoofers\Operations\Orchestration\Notifications\Contracts;

interface NotificationEnvelope
{
    public function getNotificationId(): string;
    public function getTargetRecipientId(): string;
    public function getTemplateId(): string;
    public function getTemplateData(): array;
    public function getPriority(): string;
    public function getCorrelationId(): string;
}
