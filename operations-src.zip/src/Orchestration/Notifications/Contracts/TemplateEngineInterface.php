<?php
namespace AirRoofers\Operations\Orchestration\Notifications\Contracts;

interface TemplateEngineInterface
{
    /**
     * Resolves and renders the template content for the given channels in the Delivery Plan.
     */
    public function render(DeliveryPlan $plan): DeliveryPlan;
}
