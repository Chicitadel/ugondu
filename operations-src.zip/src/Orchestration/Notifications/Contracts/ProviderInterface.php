<?php
namespace AirRoofers\Operations\Orchestration\Notifications\Contracts;

interface ProviderInterface
{
    /**
     * Dispatches the rendered content via a specific channel (e.g., SendGrid for Email, Twilio for SMS).
     */
    public function send(DeliveryPlan $plan, string $channel): DeliveryReceipt;

    /**
     * Returns true if this provider supports the requested channel.
     */
    public function supportsChannel(string $channel): bool;
}
