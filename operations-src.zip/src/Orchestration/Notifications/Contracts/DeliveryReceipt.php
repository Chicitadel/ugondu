<?php
namespace AirRoofers\Operations\Orchestration\Notifications\Contracts;

interface DeliveryReceipt
{
    public function getReceiptId(): string;
    public function getDeliveryPlanId(): string;
    public function getProviderId(): string;
    public function getChannel(): string;
    public function getStatus(): string; // 'SENT', 'DELIVERED', 'FAILED'
    public function getDeliveredAt(): ?\DateTimeImmutable;
    public function getErrorMessage(): ?string;
}
