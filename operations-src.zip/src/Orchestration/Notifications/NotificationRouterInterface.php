<?php
namespace AirRoofers\Operations\Orchestration\Notifications;

use AirRoofers\PlatformCore\Event\CloudEvent;

interface NotificationRouterInterface
{
    /**
     * Route an incoming event to the appropriate notification channels.
     */
    public function dispatch(CloudEvent $event): void;

    /**
     * Register a routing preference for a specific entity (e.g. User wants SMS for Alerts).
     */
    public function setPreference(string $entityId, string $eventType, array $channels): void;
}
