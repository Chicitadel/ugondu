<?php

/******************************************************************************
 * Project        : AirRoofers
 * Module         : Orchestration
 * File           : TemplateEngine.php
 * Version        : 1.0.0
 * Author         : System
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Orchestration\Notifications\Templates;

use AirRoofers\Operations\Orchestration\Notifications\Contracts\TemplateEngineInterface;
use AirRoofers\Operations\Orchestration\Notifications\Contracts\DeliveryPlan;
use AirRoofers\Operations\Orchestration\Notifications\Contracts\NotificationEnvelope;

class TemplateEngine implements TemplateEngineInterface
{
    /**
     * @var array<string, array<string, mixed>>
     */
    private array $templates;

    public function __construct(array $templates = [])
    {
        $this->templates = $templates;
    }

    /**
     * Resolves and renders the template content for the given channels in the Delivery Plan.
     */
    public function render(DeliveryPlan $plan): DeliveryPlan
    {
        $envelope = $plan->getNotificationEnvelope();
        $templateId = $envelope->getTemplateId();
        $tokens = $envelope->getTemplateData();
        $channels = $plan->getResolvedChannels();

        if (!isset($this->templates[$templateId])) {
            throw new \RuntimeException(sprintf('Template "%s" not found', $templateId));
        }

        $template = $this->templates[$templateId];
        $renderedContent = [];

        foreach ($channels as $channel) {
            if (isset($template[$channel])) {
                $renderedContent[$channel] = $this->replaceTokens($template[$channel], $tokens);
            } else {
                $renderedContent[$channel] = null;
            }
        }

        return new class($plan, $renderedContent) implements DeliveryPlan {
            private DeliveryPlan $plan;
            private array $renderedContent;

            public function __construct(DeliveryPlan $plan, array $renderedContent)
            {
                $this->plan = $plan;
                $this->renderedContent = $renderedContent;
            }

            public function getPlanId(): string
            {
                return $this->plan->getPlanId();
            }

            public function getNotificationEnvelope(): NotificationEnvelope
            {
                return $this->plan->getNotificationEnvelope();
            }

            public function getResolvedChannels(): array
            {
                return $this->plan->getResolvedChannels();
            }

            public function getResolvedContent(): array
            {
                // Merge existing content with newly rendered content.
                return array_merge($this->plan->getResolvedContent() ?? [], $this->renderedContent);
            }

            public function getStatus(): string
            {
                return $this->plan->getStatus();
            }
        };
    }

    /**
     * Replaces {{ token }} occurrences in the content.
     * Content can be a string or an array of strings (e.g., subject and body).
     *
     * @param mixed $content
     * @param array $tokens
     * @return mixed
     */
    private function replaceTokens($content, array $tokens)
    {
        if (is_array($content)) {
            $result = [];
            foreach ($content as $key => $value) {
                $result[$key] = $this->replaceTokens($value, $tokens);
            }
            return $result;
        }

        if (!is_string($content)) {
            return $content;
        }

        foreach ($tokens as $key => $value) {
            if (is_scalar($value) || $value === null) {
                $search = '{{' . $key . '}}';
                $content = str_replace($search, (string)$value, $content);
                
                // Support tokens with spaces
                $searchWithSpaces = '{{ ' . $key . ' }}';
                $content = str_replace($searchWithSpaces, (string)$value, $content);
            }
        }

        return $content;
    }
}
