<?php
namespace AirRoofers\Operations\PlatformRegistry\Api;

class RegistryController {
    public function getManifest() {
        $capabilities = [];
        $domains = [];
        
        $baseDir = __DIR__ . '/../../../../../';
        if (is_dir($baseDir)) {
            $dirs = scandir($baseDir);
            foreach ($dirs as $dir) {
                if ($dir !== '.' && $dir !== '..' && is_dir($baseDir . $dir) && str_ends_with($dir, '.airroofers.eu')) {
                    $capId = str_replace('.airroofers.eu', '', $dir);
                    $capabilities[$capId] = [
                        "owner" => "Platform Team",
                        "repo" => $dir
                    ];
                    $domains[] = ["id" => $capId, "status" => "Healthy"];
                }
            }
        }

        return [
            "schemaVersion" => "1.0",
            "generatedAt" => date('c'),
            "capabilities" => empty($capabilities) ? ["identity" => ["owner" => "Auth Team", "repo" => "identity.airroofers.eu"]] : $capabilities,
            "regions" => ["eu-west-1", "eu-central-1", "us-east-1"],
            "domains" => empty($domains) ? [["id" => "identity", "status" => "Healthy"]] : $domains
        ];
    }
}
