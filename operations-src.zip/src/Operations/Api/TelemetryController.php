<?php
namespace AirRoofers\Operations\Operations\Api;

class TelemetryController {
    public function getHealth() {
        return [
            "healthScore" => 98,
            "availability" => 99.99,
            "activeServices" => 132,
            "incidents" => 0,
            "openTickets" => 12,
            "licenseCompliance" => 100
        ];
    }
}
