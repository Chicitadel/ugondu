<?php

/******************************************************************************
 * Project        : Operations Platform Execution Pack
 * Module         : Health Service
 * File           : HealthController.php
 * Version        : 1.0.0
 * Author         : Antigravity
 * Organization   : Air Roofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Air Roofers
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Operations\Health;

class HealthController
{
    private HealthService $healthService;

    public function __construct(HealthService $healthService)
    {
        $this->healthService = $healthService;
    }

    /**
     * Endpoint: GET /api/v1/health
     */
    public function getHealth(): array
    {
        return $this->healthService->getSystemHealth();
    }
}
