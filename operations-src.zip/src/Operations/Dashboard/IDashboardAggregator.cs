/******************************************************************************
 * Project        : operations.airroofers.eu
 * Module         : Operations.Dashboard
 * File           : IDashboardAggregator.cs
 * Version        : 1.0.0
 * Author         : Corporate Governance
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/

using System.Threading.Tasks;

namespace Operations.Dashboard
{
    public interface IDashboardAggregator
    {
        Task<DashboardViewDto> GetOperationsDashboardAsync(string tenantId);
    }
}
