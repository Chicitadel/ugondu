<?php

/******************************************************************************
 * Project        : Operations Platform Execution Pack
 * Module         : Evidence Service
 * File           : EvidenceController.php
 * Version        : 1.0.0
 * Author         : Antigravity
 * Organization   : Air Roofers
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Air Roofers
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Operations\Evidence;

class EvidenceController
{
    private EvidenceService $evidenceService;

    public function __construct(EvidenceService $evidenceService)
    {
        $this->evidenceService = $evidenceService;
    }

    /**
     * Endpoint: GET /api/v1/evidence
     */
    public function getEvidence(): array
    {
        return $this->evidenceService->getAllEvidence();
    }
    
    /**
     * Endpoint: GET /api/v1/evidence/{id}
     */
    public function getEvidenceById(string $id): ?array
    {
        return $this->evidenceService->getEvidenceById($id);
    }
}
