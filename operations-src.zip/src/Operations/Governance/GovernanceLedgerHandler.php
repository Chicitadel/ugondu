<?php
/******************************************************************************
 * Project        : Operations Platform Execution Pack
 * Module         : Governance Service
 * File           : GovernanceLedgerHandler.php
 * Version        : 1.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\Operations\Operations\Governance;

class GovernanceLedgerHandler
{
    private string $ledgerDirectory;

    public function __construct(string $ledgerDirectory = '/var/lib/governance/ledgers')
    {
        $this->ledgerDirectory = $ledgerDirectory;
    }

    /**
     * Handle GET /api/v1/governance/ledgers
     */
    public function listLedgers(): array
    {
        if (!is_dir($this->ledgerDirectory)) {
            return [
                'status' => 'error',
                'data' => []
            ];
        }

        $files = glob($this->ledgerDirectory . '/*.md');
        $ledgers = [];
        
        if ($files) {
            foreach ($files as $file) {
                $ledgers[] = [
                    'id' => basename($file, '.md'),
                    'name' => basename($file),
                    'path' => $file
                ];
            }
        }

        return [
            'status' => 'success',
            'data' => $ledgers
        ];
    }

    /**
     * Handle GET /api/v1/governance/ledgers/{id}
     */
    public function getLedger(string $id): array
    {
        $filePath = $this->ledgerDirectory . '/' . $id . '.md';

        if (!file_exists($filePath)) {
            return [
                'status' => 'error',
                'message' => 'Ledger not found',
                'code' => 404
            ];
        }

        $content = file_get_contents($filePath);
        $parsedContent = $this->parseMarkdown($content);

        return [
            'status' => 'success',
            'data' => [
                'id' => $id,
                'content' => $parsedContent
            ]
        ];
    }

    /**
     * Parse markdown ledger content into structured data
     */
    private function parseMarkdown(string $markdown): array
    {
        $lines = explode("\n", $markdown);
        $parsed = [
            'sections' => []
        ];

        $currentSection = 'default';

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            if (str_starts_with($line, '# ')) {
                $currentSection = substr($line, 2);
                $parsed['sections'][$currentSection] = [];
            } elseif (str_starts_with($line, '## ')) {
                $subSection = substr($line, 3);
                $parsed['sections'][$currentSection][$subSection] = [];
            } else {
                if (!isset($parsed['sections'][$currentSection])) {
                    $parsed['sections'][$currentSection] = [];
                }
                
                if (is_array($parsed['sections'][$currentSection])) {
                    $parsed['sections'][$currentSection][] = $line;
                }
            }
        }

        return $parsed;
    }
}
