/******************************************************************************
 * Project        : Operations Platform
 * Module         : Alerting Service
 * File           : AlertThresholdService.cs
 * Version        : 1.0.0
 * Author         : Human Author
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Operations.Alerting
{
    public class AlertThresholdService
    {
        private readonly IAlertThresholdRepository _repository;

        public AlertThresholdService(IAlertThresholdRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        public async Task<IEnumerable<AlertThreshold>> GetAllThresholdsAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<AlertThreshold> GetThresholdAsync(Guid id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task CreateThresholdAsync(AlertThreshold threshold)
        {
            if (threshold == null) throw new ArgumentNullException(nameof(threshold));
            
            threshold.Id = Guid.NewGuid();
            threshold.CreatedAt = DateTime.UtcNow;
            threshold.UpdatedAt = DateTime.UtcNow;
            
            await _repository.AddAsync(threshold);
        }

        public async Task UpdateThresholdAsync(AlertThreshold threshold)
        {
            if (threshold == null) throw new ArgumentNullException(nameof(threshold));

            threshold.UpdatedAt = DateTime.UtcNow;
            await _repository.UpdateAsync(threshold);
        }

        public async Task DeleteThresholdAsync(Guid id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}
