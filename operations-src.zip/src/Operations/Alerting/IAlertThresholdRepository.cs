/******************************************************************************
 * Project        : Operations Platform
 * Module         : Alerting Service
 * File           : IAlertThresholdRepository.cs
 * Version        : 1.0.0
 * Author         : Human Author
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Operations.Alerting
{
    public interface IAlertThresholdRepository
    {
        Task<AlertThreshold> GetByIdAsync(Guid id);
        Task<IEnumerable<AlertThreshold>> GetAllAsync();
        Task AddAsync(AlertThreshold threshold);
        Task UpdateAsync(AlertThreshold threshold);
        Task DeleteAsync(Guid id);
    }
}
