/******************************************************************************
 * Project        : Operations Platform
 * Module         : Alerting Service
 * File           : AlertThreshold.cs
 * Version        : 1.0.0
 * Author         : Human Author
 * Organization   : Ujomor
 * Created Date   : 2026-07-17
 * Last Modified  : 2026-07-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Ujomor
 * All Rights Reserved.
 ******************************************************************************/
using System;

namespace Operations.Alerting
{
    public class AlertThreshold
    {
        public Guid Id { get; set; }
        public string MetricName { get; set; }
        public double WarningThreshold { get; set; }
        public double CriticalThreshold { get; set; }
        public bool IsPredictive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
