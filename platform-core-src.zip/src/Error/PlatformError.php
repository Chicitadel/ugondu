<?php
namespace AirRoofers\PlatformCore\Error;

class PlatformError extends \Exception {
    
    
    public string $type;
    public ?array $details;

    public function __construct(string $code, string $message, string $type, ?array $details = null) {
        $this->code = $code;
        parent::__construct($message); $this->message = $message;
        $this->type = $type;
        $this->details = $details;
    }
}
