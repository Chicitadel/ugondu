<?php
namespace AirRoofers\PlatformCore\Audit;

class AuditLogger {
    protected string $logPath;

    public function __construct(string $logPath = '/tmp/platform_audit.log') {
        $this->logPath = $logPath;
    }

    public function log(string $action, array $context): void {
        $correlationId = $context['correlationId'] ?? null;
        if (!$correlationId && function_exists('getallheaders')) {
            $headers = getallheaders();
            $correlationId = $headers['X-Correlation-ID'] ?? $headers['x-correlation-id'] ?? uniqid('tx_internal_', true);
        }

        $entry = [
            'timestamp' => date('Y-m-d\TH:i:s\Z'),
            'correlationId' => $correlationId,
            'action' => $action,
            'context' => $context
        ];

        file_put_contents($this->logPath, json_encode($entry) . "\n", FILE_APPEND);
    }
}
