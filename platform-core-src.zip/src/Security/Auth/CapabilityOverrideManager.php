<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag Capability Override Manager
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Infrastructure\Database;
use Mandatag\Security\Audit\AdminAuditLogger;

final class CapabilityOverrideManager
{
    public static function add(int $adminId, string $capability, string $mode, int $actor): void
    {
        $db = Database::instance();

        $db->execute(
            'INSERT INTO admin_capability_overrides
             (admin_id, capability, mode, created_at)
             VALUES (?, ?, ?, NOW())',
            [$adminId, $capability, $mode]
        );

        AdminAuditLogger::log($actor, 'security.capability.override.add', [
            'target' => $adminId,
            'capability' => $capability,
            'mode' => $mode
        ]);
    }
}
