<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: Csrf.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose: Deterministic + Zero-Trust Aware CSRF Protection Engine
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 11 – Zero Trust Hardened Token Lifecycle
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Security\Audit\AdminAuditLogger;
use Mandatag\Bootstrap\session;

final class Csrf
{
    /**
     * Default TTL for CSRF token (seconds)
     * Short enough for security, long enough for UX.
     */
    private const TOKEN_TTL = 1800; // 30 minutes

    /**
     * Session keys
     */
    private const SESSION_TOKEN = '_csrf';
    private const SESSION_META  = '_csrf_meta';

    /* =========================================================
       TOKEN GENERATION
    ========================================================= */

    /**
     * Generates or returns an existing CSRF token.
     *
     * Backward compatible with:
     * - admin.layout.php hidden logout field
     * - legacy forms using $_SESSION['_csrf']
     */
    public static function generate(): string
    {
        self::ensureSession();

        if (!isset($_SESSION[self::SESSION_TOKEN])) {
            self::issueNewToken();
        } else {
            self::refreshIfExpired();
        }

        return (string) $_SESSION[self::SESSION_TOKEN];
    }

    /* =========================================================
       VALIDATION
    ========================================================= */

    /**
     * Validates provided token.
     *
     * - Constant time comparison
     * - TTL enforced
     * - One-time rotation option
     * - Audit logging on failure
     */
    public static function validate(?string $token): bool
    {
        if ($token === null) {
            self::logFailure('missing_token');
            return false;
        }

        if (session_status() !== PHP_SESSION_ACTIVE) {
            self::logFailure('no_session');
            return false;
        }

        $sessionToken = $_SESSION[self::SESSION_TOKEN] ?? null;

        if (!is_string($sessionToken)) {
            self::logFailure('token_not_initialized');
            return false;
        }

        if (!hash_equals($sessionToken, $token)) {
            self::logFailure('token_mismatch');
            return false;
        }

        if (self::isExpired()) {
            self::logFailure('token_expired');
            self::issueNewToken(); // rotate on expiry
            return false;
        }

        // Optional adaptive rotation (Zero Trust hardened)
        self::rotateAfterValidation();

        return true;
    }

    /* =========================================================
       ROTATION CONTROL
    ========================================================= */

    /**
     * Forces manual rotation.
     * Safe to call after privilege escalation (e.g., MFA success).
     */
    public static function rotate(): void
    {
        self::ensureSession();
        self::issueNewToken();
    }

    /**
     * Auto-rotation policy.
     * Keeps compatibility with single-page forms.
     */
    private static function rotateAfterValidation(): void
    {
        // Zero Trust policy: rotate after state-changing POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            self::issueNewToken();
        }
    }

    /* =========================================================
       INTERNAL ENGINE
    ========================================================= */

    private static function issueNewToken(): void
    {
        $_SESSION[self::SESSION_TOKEN] = bin2hex(random_bytes(32));

        $_SESSION[self::SESSION_META] = [
            'issued_at' => time(),
            'ip_hash'   => self::clientHash(),
        ];
    }

    private static function refreshIfExpired(): void
    {
        if (self::isExpired()) {
            self::issueNewToken();
        }
    }

    private static function isExpired(): bool
    {
        $meta = $_SESSION[self::SESSION_META] ?? null;

        if (!is_array($meta) || !isset($meta['issued_at'])) {
            return true;
        }

        return (time() - (int)$meta['issued_at']) > self::TOKEN_TTL;
    }

    /**
     * Client fingerprint hash.
     * Does NOT hard-bind like ZeroTrustMiddleware.
     * Soft signal only.
     */
    private static function clientHash(): string
    {
        return hash(
            'sha256',
            ($_SERVER['REMOTE_ADDR'] ?? '') .
            ($_SERVER['HTTP_USER_AGENT'] ?? '')
        );
    }

    private static function ensureSession(): void
    {
        session::boot();
    }

    /* =========================================================
       FAILURE AUDIT (Non-blocking)
    ========================================================= */

    private static function logFailure(string $reason): void
    {
        if (!isset($_SESSION['admin']['id'])) {
            return;
        }

        try {
            AdminAuditLogger::log(
                (int)$_SESSION['admin']['id'],
                'csrf.validation_failed',
                [
                    'reason' => $reason,
                    'uri'    => $_SERVER['REQUEST_URI'] ?? '',
                ]
            );
        } catch (\Throwable $e) {
            // Silent fail – CSRF must not crash app
        }
    }
}
