<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: BreakGlass.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose: Emergency Admin Session Escalation (Dual-Control Enforced)
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Security\Audit\AdminAuditLogger;

final class BreakGlass
{
    private const TTL_SECONDS = 900;

    public static function activate(int $adminId, string $reason): void
    {
        if (empty($_SESSION['dual_control_approved'])) {
            http_response_code(403);
            exit('Dual control approval required.');
        }

        $_SESSION['break_glass'] = true;
        $_SESSION['break_glass_expires'] = time() + self::TTL_SECONDS;

        AdminAuditLogger::log(
            $adminId,
            'security.break_glass.activated',
            [
                'reason' => $reason,
                'expires_at' => $_SESSION['break_glass_expires']
            ]
        );
    }

    public static function isActive(): bool
    {
        return isset($_SESSION['break_glass'], $_SESSION['break_glass_expires'])
            && time() < $_SESSION['break_glass_expires'];
    }

    public static function revoke(): void
    {
        unset($_SESSION['break_glass'], $_SESSION['break_glass_expires'], $_SESSION['dual_control_approved']);
    }
}
