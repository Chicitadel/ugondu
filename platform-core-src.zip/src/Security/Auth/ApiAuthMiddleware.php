<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: ApiAuthMiddleware.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose: Enforces route scope authorization
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

final class ApiAuthMiddleware
{
    public function handle(): void
    {
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

        if (!preg_match('/Bearer\s+(.+)/', $auth, $m)) {
            http_response_code(401);
            echo json_encode([
                'system' => 'Mandatag',
                'error'  => 'missing_token'
            ]);
            exit;
        }

        try {
            $claims = JwtIssuer::verify($m[1]);
        } catch (\Throwable) {
            http_response_code(401);
            echo json_encode([
                'system' => 'Mandatag',
                'error'  => 'invalid_token'
            ]);
            exit;
        }

        $requiredScope = $_SERVER['MANDATAG_ROUTE_SCOPE'] ?? null;

        if ($requiredScope && !in_array($requiredScope, $claims['scope'] ?? [], true)) {
            http_response_code(403);
            echo json_encode([
                'system' => 'Mandatag',
                'error'  => 'insufficient_scope'
            ]);
            exit;
        }
    }
}
