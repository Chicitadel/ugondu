<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use AirRoofers\PlatformCore\Audit\AuditLogger;

final class JwtScopeMiddleware
{
    private ApiAuthenticator $auth;
    private AuditLogger $audit;

    public function __construct(
        ApiAuthenticator $auth,
        AuditLogger $audit
    ) {
        $this->auth  = $auth;
        $this->audit = $audit;
    }

    public function requireScope(string $requiredScope): void
    {
        $payload = $this->auth->authenticateBearer();

        $scopes = $payload['scopes'] ?? [];

        if (
            !in_array($requiredScope, $scopes, true) &&
            !in_array('*', $scopes, true)
        ) {
            http_response_code(403);
            echo json_encode(['error' => 'insufficient_scope']);
            exit;
        }

        $this->audit->log('jwt.scope.used', [
            'scope' => $requiredScope,
            'uri'   => $_SERVER['REQUEST_URI'] ?? '',
        ]);
    }
}
