<?php
/**
 * MANDATAG — Internal Licensing, Entitlement & Administrative Control System
 * 
 * © Air Roofers SAS
 * 
 * Author:    Ignatus Chika Ujomor
 * Role:      Software Architect & Systems Engineer
 * Web:       https://www.ujomor.com
 * Signature: "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 * Location:  /Mandatag/Security/Auth/CustomerSurfaceMiddleware.php
 * Purpose:   Subdomain Surface Sovereignty Gate for Customer Portal
 * Version:   1.0 (Enterprise Refactor)
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Exceptions\HttpException;

/**
 * CustomerSurfaceMiddleware
 *
 * Enforces that customer-facing entitlement routes are strictly bound to 
 * the portal.airroofers.eu subdomain, preventing trust boundary collapse.
 */
final class CustomerSurfaceMiddleware
{
    /**
     * Handle the middleware enforcement
     *
     * @throws HttpException
     */
    public function handle(): void
    {
        $host = explode(':', $_SERVER['HTTP_HOST'] ?? '')[0];
        $isProduction = defined('MANDATAG_ENV') && MANDATAG_ENV === 'production';

        // 🛡️ 1. HOST ACCESS BOUNDARY GUARD
        if ($host !== 'portal.airroofers.eu') {
            if ($isProduction) {
                throw new HttpException("Not Found", 404);
            }
            throw new HttpException("Forbidden — Access Context Violation", 403);
        }

        // 🛡️ 2. ADMINISTRATIVE INTEGRITY CROSSING GUARD
        if (isset($_SESSION['admin'])) {
            if ($isProduction) {
                throw new HttpException("Not Found", 404);
            }
            throw new HttpException("Access Context Violation — Administrative Identity Prohibited on Customer Surface", 403);
        }

        // 🛡️ 3. SURFACE SOVEREIGNTY BINDING GUARD
        if (isset($_SESSION['portal_trust_context'])) {
            $surface = $_SESSION['mt_surface'] ?? null;
            if ($surface !== 'portal') {
                if ($isProduction) {
                    throw new HttpException("Not Found", 404);
                }
                throw new HttpException("Access Context Violation — Session Intent Context Mismatch", 403);
            }
        }
    }
}
