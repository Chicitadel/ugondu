<?php
/******************************************************************************
 * Project        : Mandatag
 * Module         : Security\Auth
 * File           : MandatagKeyAuthMiddleware.php
 * Version        : 1.0.0
 * Author         : Ignatus Chika Ujomor
 * Organization   : Air Roofers SAS
 * Created Date   : 2026-05-17
 * Last Modified  : 2026-05-17
 * Classification : ENTERPRISE
 *
 * Governance:
 * - AI Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Air Roofers SAS
 * All Rights Reserved.
 ******************************************************************************/

declare(strict_types=1);

namespace AirRoofers\PlatformCore\Security\Auth;

final class MandatagKeyAuthMiddleware
{
    /**
     * Handle API Key verification via X-Mandatag-Key header.
     */
    public function handle(): void
    {
        $apiKey = $_SERVER['HTTP_X_MANDATAG_KEY'] ?? '';
        $expectedKey = getenv('MANDATAG_API_KEY');

        if (empty($apiKey) || $apiKey !== $expectedKey) {
            http_response_code(401);
            echo json_encode([
                'system' => 'Mandatag',
                'error'  => 'unauthorized_access'
            ]);
            exit;
        }
    }
}
