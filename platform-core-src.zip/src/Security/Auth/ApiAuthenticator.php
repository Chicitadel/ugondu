<?php

declare(strict_types=1);

/**
 * MANDATAG — Internal Licensing, Entitlement & Administrative Control System
 * 
 * © Air Roofers SAS
 * 
 * Author:    Ignatus Chika Ujomor
 * Role:      Software Architect & Systems Engineer
 * Web:       https://www.ujomor.com
 * Signature: "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 * Location:  /Mandatag/Security/Auth/ApiAuthenticator.php
 * Purpose:   JWT Authentication Middleware Service (DI Compliant)
 * Version:   1.1 (Hardened)
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Security\RateLimit\ApiRateLimiter;

final class ApiAuthenticator
{
    private JwtIssuer $issuer;
    private ApiRateLimiter $rateLimiter;
    private array $config;

    public function __construct(
        JwtIssuer $issuer,
        ApiRateLimiter $rateLimiter,
        array $config
    ) {
        $this->issuer      = $issuer;
        $this->rateLimiter = $rateLimiter;
        $this->config      = $config;
    }

    /**
     * Authenticate Bearer token
     *
     * @return object Decoded JWT payload
     */
    public function authenticateBearer(): object
    {
        $this->rateLimiter->checkInstance('api_access');

        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

        if (!preg_match('/Bearer\s+(.+)/', $header, $m)) {
            http_response_code(401);
            echo json_encode(['error' => 'Missing bearer token']);
            exit;
        }

        try {
            return $this->issuer->verify($m[1]);
        } catch (\Throwable $e) {
            http_response_code(401);
            echo json_encode(['error' => 'Invalid token']);
            exit;
        }
    }
}
