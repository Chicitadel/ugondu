<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * BreakGlassResetService
 *
 * Purpose:
 *  - MFA reset via dual control
 *  - Recovery code purge
 *  - Audit logging
 *  - No password reset
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Infrastructure\Database;
use Mandatag\Security\Audit\AdminAuditLogger;

final class BreakGlassResetService
{
    public static function resetMfa(int $targetAdminId, int $actorAdminId): void
    {
        if (!BreakGlass::isActive()) {
            http_response_code(403);
            exit('Break-glass not active.');
        }

        $db = Database::instance();

        $db->execute('DELETE FROM admin_mfa WHERE admin_id = ?', [$targetAdminId]);
        $db->execute('DELETE FROM admin_mfa_recovery_codes WHERE admin_id = ?', [$targetAdminId]);

        $db->execute(
            'UPDATE admin_users SET mfa_enabled = 0 WHERE id = ?',
            [$targetAdminId]
        );

        AdminAuditLogger::log(
            $actorAdminId,
            'security.mfa.reset',
            ['target_admin' => $targetAdminId]
        );
    }
}
