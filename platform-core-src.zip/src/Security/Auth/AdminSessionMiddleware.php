<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: AdminSessionMiddleware.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose: Enterprise-Grade Admin Session Enforcement
 *          + Progressive Trust Recovery Integration
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 18 – Progressive Trust Recovery (Safe Merge)
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Fixation safe
 * - Cookie hardened
 * - Production safe
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Security\ZeroTrust\TrustRecoveryEngine;
use Mandatag\Security\ZeroTrust\TrustPolicyEngine;
use Mandatag\Bootstrap\session;

final class AdminSessionMiddleware
{
    /**
     * Public routes that bypass authentication
     *
     * Classification — Zone Assignment:
     *   /admin/*          → Administrative Zone      (AdminSessionMiddleware gates)
     *   /portal/*         → Entitlement Zone         (AuthorityTrustMiddleware gates — NOT admin)
     *   /public/*         → Public Verification Zone (open, no authentication required)
     *   /v1/* /api/*      → API Zone                 (API auth layer gates)
     *   /transparency/*   → Audit Zone               (read-only, public)
     *
     * Portal entitlement routes MUST be in this whitelist so that the Admin
     * authentication gate does not intercept them. They are governed exclusively
     * by AuthorityTrustMiddleware (OTP trust context), which is applied at the
     * Router layer via the /portal group middleware, not here.
     */
    private const PUBLIC_ROUTES = [
        '/admin/login',
        '/admin/logout',
        '/admin/forgot-password',
        '/admin/reset-password',

        // 🔥 MFA PUBLIC ENTRY
        '/admin/mfa/recovery-login',

        // 🔥 API
        '/v1/',
        '/.well-known/',
        '/admin/api/',
        '/api/v1/runtime/discover',

        // 🔥 PUBLIC / GUEST VERIFICATION & TRANSPARENCY
        '/public/verify',
        '/public/challenge',

        // 🔥 ENTITLEMENT ZONE (OTP-gated by AuthorityTrustMiddleware, NOT admin session)
        // These routes are reached post-OTP-verification. AdminSessionMiddleware must
        // not intercept them or it will redirect customers to /admin/login.
        '/portal/access',
        '/portal/products',
        '/authority/dashboard',
        '/portal/evidence',
        '/portal/audit',

        '/transparency',
        '/transparency/ledger',
    ];

    /**
     * Soft trust reauthentication interval (15 minutes)
     */
    private const SOFT_REAUTH_INTERVAL = 900;

    public function __invoke(callable $next): void
    {
        // 🛡️ SUBDOMAIN SURFACE SOVEREIGNTY GATE
        $host = explode(':', $_SERVER['HTTP_HOST'] ?? '')[0];
        if ($host !== 'admin.airroofers.eu' && $host !== 'license.airroofers.eu') {
            // Under Corporate Routing Policy Phase 31, non-admin surfaces bypass administrative controls
            $next();
            return;
        }

        // 🔥 MT-PATCH-MW-EXECUTION-LOCK-001
        if (!empty($GLOBALS['__MT_ADMIN_MW_EXECUTED'])) {
            $next();
            return;
        }

        $GLOBALS['__MT_ADMIN_MW_EXECUTED'] = true;

        $uri = $this->normalizeUri($_SERVER['REQUEST_URI'] ?? '/');

        /*
        |--------------------------------------------------------------------------
        | API BYPASS (CRITICAL FIX – EXPANDED)
        |--------------------------------------------------------------------------
        |
        | Admin session middleware MUST NOT apply to:
        | - Public APIs (/v1)
        | - Admin APIs (/admin/api)
        | - Frontend schema/API endpoints (/api)
        |
        | These are handled by API auth layers or public delivery logic
        |--------------------------------------------------------------------------
        */

        if (
            str_starts_with($uri, '/v1') ||
            str_starts_with($uri, '/admin/api/') ||
            str_starts_with($uri, '/api/')
        ) {
            $next();
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | PUBLIC ROUTE BYPASS (ABSOLUTE – NON-NEGOTIABLE)
        |--------------------------------------------------------------------------
        |
        | Public routes MUST bypass ALL authentication logic
        | including MFA and trust enforcement.
        |
        */

        if ($this->isPublicRoute($uri)) {
            $next();
            return; // 🔥 HARD STOP — NOTHING BELOW MUST RUN
        }

        /*
        |--------------------------------------------------------------------------
        | ADMINISTRATIVE SESSION INITIALIZATION
        |--------------------------------------------------------------------------
        |
        | Loaded strictly for administrative contexts only.
        |--------------------------------------------------------------------------
        */

        $this->ensureSessionStarted();
        session::bindFingerprint();
        session::touch(); // middleware writes to session throughout

        /*
        |--------------------------------------------------------------------------
        | Authentication Gate (MFA Aware)
        |--------------------------------------------------------------------------
        |
        | Allow:
        | - Fully authenticated sessions (admin)
        | - Pre-MFA sessions ONLY for MFA routes
        |
        */

        if (!$this->isAuthenticated()) {

            /*
            |--------------------------------------------------------------------------
            | Allow Pre-MFA Authenticated Users
            |--------------------------------------------------------------------------
            |
            | If password verification succeeded but full promotion has not yet
            | occurred, allow access ONLY to MFA routes.
            |
            | Prevent redirect loops by treating pre_mfa_user as authenticated
            | for MFA verification endpoints.
            |--------------------------------------------------------------------------
            */

            if (
                isset($_SESSION['pre_mfa_user']) &&
                $this->isMfaRoute($uri)
            ) {
                // Continue to MFA verification
            } else {
                $this->redirectToLogin();
            }
        }

        // 🛡️ SET ADMINISTRATIVE SURFACE CONTEXT MARKERS
        if ($this->isAuthenticated()) {
            $_SESSION['mt_surface'] = 'admin';
            $_SESSION['mt_role']    = 'governance';
            $_SESSION['mt_context'] = 'authority';
        }

        $this->protectAgainstFixation();

        /*
        |--------------------------------------------------------------------------
        | Session Token Integrity Enforcement (CRITICAL SECURITY LAYER)
        |--------------------------------------------------------------------------
        |
        | Ensures:
        | - Single active session per admin
        | - Forced logout of other sessions after rotation
        | - Prevents session replay attacks
        |--------------------------------------------------------------------------
        */

        if (isset($_SESSION['admin']['id'])) {
            try {
                $db = \Mandatag\Infrastructure\Database::instance();
                $dbToken = $_SESSION['__verified_session_token'] ?? null;

                if ($dbToken === null) {
                    $dbToken = $db->fetchValue(
                        "SELECT session_token FROM admin_users WHERE id = ?",
                        [$_SESSION['admin']['id']]
                    );
                    $_SESSION['__verified_session_token'] = $dbToken;
                }

                $sessionToken = $_SESSION['session_token'] ?? null;

                if (!$dbToken || !$sessionToken || !hash_equals($dbToken, hash('sha256', $sessionToken))) {
                    session::destroy();
                    header('Location: /admin/login?session_expired=1', true, 302);
                    exit;
                }
            } catch (\Throwable $e) {
                // 🔥 MT-PATCH-MW-STABILITY-001: Graceful Degradation
                error_log("[MT][SECURITY] DB Session Token Integrity Check Failed: " . $e->getMessage());
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Forced Password Rotation Enforcement (Global – Deterministic)
        |--------------------------------------------------------------------------
        |
        | Enforced AFTER:
        | - Authentication confirmed
        | - Session fixation protection
        |
        | Enforced BEFORE:
        | - Super Admin hardware enforcement
        | - Trust recovery engine
        |
        | Guarantees:
        | - Cannot be bypassed
        | - No redirect recursion
        | - Does not interfere with MFA pre-promotion
        |--------------------------------------------------------------------------
        */

        if (
            isset($_SESSION['admin']) &&
            !isset($_SESSION['pre_mfa_user'])
        ) {
            $allowedPaths = [
                '/admin/password-reset-required',
                '/admin/logout'
            ];

            if (!in_array($uri, $allowedPaths, true)) {
                try {
                    $db = \Mandatag\Infrastructure\Database::instance();
                    $mustChange = (int)$db->fetchValue(
                        'SELECT password_must_change FROM admin_users WHERE id = ?',
                        [$_SESSION['admin']['id']]
                    );

                    if ($mustChange === 1) {
                        header('Location: /admin/password-reset-required', true, 302);
                        exit;
                    }
                } catch (\Throwable $e) {
                    // 🔥 MT-PATCH-MW-STABILITY-002: Graceful Degradation
                    error_log("[MT][SECURITY] DB Password Rotation Check Failed: " . $e->getMessage());
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Baseline Zero Trust Enforcement (Role-Based)
        |--------------------------------------------------------------------------
        |
        | Super Admin requires:
        | - TOTP verified
        | - WebAuthn verified
        | Minimum Trust Level: 4
        |--------------------------------------------------------------------------
        */

            $role = strtolower((string)($_SESSION['admin']['role'] ?? ''));
            $isSuper = in_array($role, ['super', 'super_admin'], true);
            if ($isSuper){

            /*
            |--------------------------------------------------------------------------
            | STRICT AUTHENTICATION ORDER GUARD
            |--------------------------------------------------------------------------
            |
            | If still in pre-MFA elevation state,
            | DO NOT allow WebAuthn enforcement to execute.
            |
            | Prevents circular redirect:
            | MFA → WebAuthn → MFA → loop
            |--------------------------------------------------------------------------
            */

            if (isset($_SESSION['pre_mfa_user'])) {
                $next();
                return;
            }

            /*
            |--------------------------------------------------------------------------
            | Prevent recursion inside MFA or WebAuthn routes
            |--------------------------------------------------------------------------
            */

            $isMfaRoute = $this->isMfaRoute($uri);

            $isWebauthVerifyRoute = ($uri === '/admin/webauth/verify');
            $isWebauthEnrollRoute = ($uri === '/admin/webauth/enroll');

            $isWebauthApiRoute = str_starts_with($uri, '/admin/api/webauthn');

            $isPasswordResetRoute = ($uri === '/admin/password-reset-required');

            /*
            |--------------------------------------------------------------------------
            | Strict Sequential MFA Gating
            |--------------------------------------------------------------------------
            |
            | Prevent Super Admins from accessing WebAuthn enrollment/verification
            | routes without first completing TOTP verification.
            |--------------------------------------------------------------------------
            */
            $isWebauthRoute = $isWebauthVerifyRoute || $isWebauthEnrollRoute;
            if ($isWebauthRoute && empty($_SESSION['mfa_verified_recent'])) {
                if (str_starts_with($uri, '/admin')) {
                    $_SESSION['intended_admin_uri'] = $uri;
                }
                header('Location: /admin/mfa/verify?elevated=1', true, 302);
                exit;
            }

            /*
            |--------------------------------------------------------------------------
            | Security Flow Routes (Strict Matching)
            |--------------------------------------------------------------------------
            |
            | Only exact authentication flow routes bypass hardware gating.
            | Prevents layout collision and partial dashboard rendering.
            |--------------------------------------------------------------------------
            */

            $isSecurityFlowRoute =
                $isMfaRoute ||
                $isWebauthVerifyRoute ||
                $isWebauthEnrollRoute ||
                $isWebauthApiRoute ||
                $isPasswordResetRoute;


            if (!$isSecurityFlowRoute) {

                /*
                |--------------------------------------------------------------------------
                | Require recent MFA verification
                |--------------------------------------------------------------------------
                */

                if (empty($_SESSION['mfa_verified_recent'])) {

                    if (str_starts_with($uri, '/admin')) {
                        $_SESSION['intended_admin_uri'] = $uri;
                    }


                    header('Location: /admin/mfa/verify?elevated=1', true, 302);
                    exit;
                }

                /*
                |--------------------------------------------------------------------------
                | Enforce WebAuthn (DB-driven, deterministic)
                |--------------------------------------------------------------------------
                */
                try {
                    $db = \Mandatag\Infrastructure\Database::instance();

                    $credentialCount = (int)$db->fetchValue(
                        'SELECT COUNT(*) FROM admin_webauthn_credentials WHERE admin_id = ?',
                        [$_SESSION['admin']['id']]
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Case 1: No hardware enrolled → Force enrollment
                    |--------------------------------------------------------------------------
                    */

                    if ($credentialCount === 0) {

                        \Mandatag\Security\Audit\AdminAuditLogger::log(
                            (int)$_SESSION['admin']['id'],
                            'super_admin.hardware_enrollment_required'
                        );

                        header('Location: /admin/webauth/enroll', true, 302);
                        exit;
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Case 2: Hardware exists → Require verification
                    | Enforce Hardware Freshness (Each Login or Session)
                    |--------------------------------------------------------------------------
                    |
                    | Require hardware verification per authenticated session.
                    | Prevents replay of old elevated session.
                    |--------------------------------------------------------------------------
                    */

                    $hardwareVerified = !empty($_SESSION['webauthn_verified_recent']);
                    $hardwareAge      = $_SESSION['last_hardware_auth'] ?? 0;

                    /*
                    |--------------------------------------------------------------------------
                    | Phase 34 – Mandatory Hardware Rebind Enforcement
                    |--------------------------------------------------------------------------
                    |
                    | If a credential has been marked for mandatory_rebind:
                    | - Force re-enrollment
                    | - Prevent dashboard access
                    | - Avoid redirect recursion
                    |--------------------------------------------------------------------------
                    */

                    $rebindRequired = (int)$db->fetchValue(
                        "SELECT COUNT(*) FROM admin_webauthn_credentials
                         WHERE admin_id = ?
                         AND mandatory_rebind = 1",
                        [$_SESSION['admin']['id']]
                    ) > 0;

                    if ($rebindRequired) {

                        $isEnrollRoute = str_starts_with($uri, '/admin/webauth/enroll');
                        $isWebauthApi  = str_starts_with($uri, '/admin/api/webauthn');

                        if (!$isEnrollRoute && !$isWebauthApi) {

                            \Mandatag\Security\Audit\AdminAuditLogger::log(
                                (int)$_SESSION['admin']['id'],
                                'super_admin.mandatory_rebind_enforced'
                            );

                            header('Location: /admin/webauth/enroll?rebind=1', true, 302);
                            exit;
                        }
                    }
                } catch (\Throwable $e) {
                    // 🔥 MT-PATCH-MW-STABILITY-003: Graceful Degradation
                    error_log("[MT][SECURITY] DB WebAuthn Check Failed: " . $e->getMessage());
                }

                /*
                |--------------------------------------------------------------------------
                | Standard Hardware Freshness Enforcement
                |--------------------------------------------------------------------------
                |
                | Allow immediate transition from successful WebAuthn
                | verification to dashboard without re-triggering
                | hardware enforcement in the same session.
                |--------------------------------------------------------------------------
                */

                $isDashboardRoute = str_starts_with($uri, '/admin/dashboard');

                if (
                    !$hardwareVerified ||
                    ((time() - $hardwareAge) > 1800)
                ) {

                    /*
                    |--------------------------------------------------------------------------
                    | If already verified and navigating to dashboard,
                    | allow access (prevents post-verification recursion).
                    |--------------------------------------------------------------------------
                    */

                    if ($hardwareVerified && $isDashboardRoute) {
                        // Allow dashboard access
                    } else {

                        if (str_starts_with($uri, '/admin')) {
                            $_SESSION['intended_admin_uri'] = $uri;
                        }


                        header('Location: /admin/webauth/verify', true, 302);
                        exit;
                    }
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Progressive Trust Recovery Enforcement
        |--------------------------------------------------------------------------
        |
        | Must execute AFTER authentication
        | Must not interfere with MFA routes
        | Must not create redirect loops
        |
        */

        $isWebauthRoute     = str_starts_with($uri, '/admin/webauth');
        $isWebauthApiRoute  = str_starts_with($uri, '/admin/api/webauthn');

        if (
            !$this->isMfaRoute($uri) &&
            !$isWebauthRoute &&
            !$isWebauthApiRoute
        ) {

            // 🔥 MT-PATCH-TRUST-STABILITY-001
            if (!empty($_SESSION['__just_authenticated'])) {
                unset($_SESSION['__just_authenticated']);
            } else {

                $engine = new TrustPolicyEngine();
                $trustMode = $engine->evaluate((int)$_SESSION['admin']['id']);

            /*
            | SOFT MODE – Periodic Reauthentication
            */
            if ($trustMode === TrustRecoveryEngine::MODE_SOFT) {

                $last = $_SESSION['last_reauth'] ?? 0;

                if (time() - $last > self::SOFT_REAUTH_INTERVAL) {

                    $_SESSION['reauth_required'] = true;

                    /*
                    |--------------------------------------------------------------------------
                    | Store Intended URI (Context-Aware Reauth)
                    |--------------------------------------------------------------------------
                    |
                    | Prevent open redirect:
                    | - Must start with /admin
                    | - Must not be MFA route
                    |
                    */

                    if (
                        str_starts_with($uri, '/admin') &&
                        !$this->isMfaRoute($uri)
                    ) {
                        $_SESSION['intended_admin_uri'] = $uri;
                    }

                    header('Location: /admin/mfa/verify?reauth=1', true, 302);
                    exit;
                }
            }

            /*
            | ELEVATED MODE – Enforce MFA Each Request
            */
            if ($trustMode === TrustRecoveryEngine::MODE_ELEVATED) {

                if (empty($_SESSION['mfa_verified_recent'])) {

                    /*
                    |--------------------------------------------------------------------------
                    | Store Intended URI (Elevated Mode)
                    |--------------------------------------------------------------------------
                    */

                    if (
                        str_starts_with($uri, '/admin') &&
                        !$this->isMfaRoute($uri)
                    ) {
                        $_SESSION['intended_admin_uri'] = $uri;
                    }

                    header('Location: /admin/mfa/verify?elevated=1', true, 302);
                    exit;
                }
            }

            /*
            | LOCKED MODE – Quarantine Engine handles enforcement
            | Avoid redirect duplication here
            */
        } // ← closes trustMode handling

    } // ← 🔥 THIS WAS MISSING (closes the "else" block)


        // 🔥 MT-PATCH-DISPATCH-GUARD-001
        $next();
    }

    private function ensureSessionStarted(): void
    {
        session::boot();
    }

    private function normalizeUri(string $uri): string
    {
        return strtok($uri, '?') ?: '/';
    }

    private function isPublicRoute(string $uri): bool
    {
        if ($uri === '/') {
            return true;
        }

        foreach (self::PUBLIC_ROUTES as $route) {
            if (str_starts_with($uri, $route)) {
                return true;
            }
        }
        return false;
    }

    private function isMfaRoute(string $uri): bool
    {
        /*
        |--------------------------------------------------------------------------
        | EXCLUDE PUBLIC MFA ROUTES (CRITICAL FIX)
        |--------------------------------------------------------------------------
        */

        if ($uri === '/admin/mfa/recovery-login') {
            return false;
        }

        return str_starts_with($uri, '/admin/mfa/');
    }

    private function isAuthenticated(): bool
    {
        /*
        |--------------------------------------------------------------------------
        | Strict Authentication State Separation (RESTORED)
        |--------------------------------------------------------------------------
        */

        if (isset($_SESSION['pre_mfa_user'])) {
            return false;
        }

        return isset($_SESSION['admin'])
            && is_array($_SESSION['admin'])
            && isset($_SESSION['admin']['id']);
    }

    private function protectAgainstFixation(): void
    {
        if (!isset($_SESSION['__session_initialized'])) {
            session::regenerate();
            $_SESSION['__session_initialized'] = true;
        }
    }

    private function redirectToLogin(): void
    {
        $uri = $this->normalizeUri($_SERVER['REQUEST_URI'] ?? '/');

        $isApiRequest =
            str_starts_with($uri, '/api/') ||
            str_starts_with($uri, '/admin/api/') ||
            str_starts_with($uri, '/v1/');

        if ($isApiRequest) {
            header('Content-Type: application/json', true, 401);
            echo json_encode([
                'success' => false,
                'error'   => 'unauthorized'
            ]);
            exit;
        }

        header('Location: /admin/login', true, 302);
        exit;
    }
}
