<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: GatewayTrustMiddleware.php
 * Location: Mandatag/Security/Auth/
 * Purpose: Enforces zero-trust API gateway signature validation
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

final class GatewayTrustMiddleware
{
    public function __invoke(callable $next): void
    {
        $signature = $_SERVER['HTTP_X_GATEWAY_SIGNATURE'] ?? null;

        if (!$signature) {
            http_response_code(401);
            echo json_encode(['error' => 'Missing gateway signature']);
            exit;
        }

        $expected = hash('sha256', $_SERVER['REQUEST_URI']);

        if (!hash_equals($expected, $signature)) {
            http_response_code(403);
            echo json_encode(['error' => 'Invalid gateway signature']);
            exit;
        }

        $next();
    }
}
