<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: JwtMiddleware.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose: Enforces Bearer JWT Authentication
 * --------------------------------------------------------------------
 *
 * FIXED:
 * - Router-compatible
 * - Single JWT verification source
 * - No duplicate verification
 * - No pipeline mismatch
 */

namespace AirRoofers\PlatformCore\Security\Auth;

final class JwtMiddleware
{
    public function handle(): void
    {
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

        if (!preg_match('/Bearer\s+(.+)/', $auth, $m)) {
            http_response_code(401);
            echo json_encode([
                'system' => 'Mandatag',
                'error'  => 'missing_token'
            ]);
            exit;
        }

        try {
            JwtIssuer::verify($m[1]);
        } catch (\Throwable) {
            http_response_code(401);
            echo json_encode([
                'system' => 'Mandatag',
                'error'  => 'invalid_token'
            ]);
            exit;
        }
    }
}
