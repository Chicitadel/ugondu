<?php

declare(strict_types=1);

/**
 * MANDATAG — Internal Licensing, Entitlement & Administrative Control System
 * 
 * © Air Roofers SAS
 * 
 * Author:    Ignatus Chika Ujomor
 * Role:      Software Architect & Systems Engineer
 * Web:       https://www.ujomor.com
 * Signature: "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 * Location:  /Mandatag/Security/Auth/TrustAuthorityManager.php
 * Purpose:   Cryptographic Heart of the Mandatag Trust Authority
 * Version:   1.0 (Refactor 2026)
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

/**
 * TrustAuthorityManager
 *
 * The cryptographic heart of the Mandatag Trust Authority.
 * Manages OTP hashing, trust token generation, and session hardening.
 */
final class TrustAuthorityManager
{
    private const TOKEN_EXPIRY = 300; // 5 minutes

    /**
     * Generate a cryptographically secure OTP
     */
    public function generateOTP(): string
    {
        return (string) random_int(100000, 999999);
    }

    /**
     * Hash an OTP for secure storage
     */
    public function hashOTP(string $otp): string
    {
        return hash_hmac('sha256', $otp, $this->getSecret());
    }

    /**
     * Verify a submitted OTP against the hashed version
     */
    public function verifyOTP(string $submitted, string $hashed): bool
    {
        return hash_equals($hashed, $this->hashOTP($submitted));
    }

    /**
     * Hash a License ID for session storage (Opaque Context)
     */
    public function hashLicenseId(string $licenseId): string
    {
        return hash_hmac('sha256', $licenseId, $this->getSecret());
    }

    /**
     * Generate a short-lived, single-use access token
     */
    public function generateAccessToken(string $licenseId): string
    {
        $nonce = bin2hex(random_bytes(16));
        $expiry = time() + self::TOKEN_EXPIRY;
        
        $payload = json_encode([
            'id' => $licenseId,
            'exp' => $expiry,
            'nonce' => $nonce
        ]);

        return base64_encode($payload . '.' . hash_hmac('sha256', $payload, $this->getSecret()));
    }

    /**
     * Validate and consume an access token
     */
    public function validateToken(string $token): ?string
    {
        $parts = explode('.', base64_decode($token));
        if (count($parts) !== 2) return null;

        [$payloadJson, $signature] = $parts;
        
        if (!hash_equals($signature, hash_hmac('sha256', $payloadJson, $this->getSecret()))) {
            return null;
        }

        $payload = json_decode($payloadJson, true);
        if (!$payload || ($payload['exp'] ?? 0) < time()) {
            return null;
        }

        return $payload['id'];
    }

    /**
     * Establish the authenticated trust context in the session
     */
    public function establishTrust(string $licenseId): void
    {
        // 🔒 MANDATORY SESSION REGENERATION (Prevent Fixation)
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

        $_SESSION['portal_trust_context'] = [
            'license_hash' => $this->hashLicenseId($licenseId),
            'license_id' => $licenseId,
            'verified_at' => time(),
            'trust_level' => 'high',
            'ip_hash' => hash_hmac('sha256', $ip, $this->getSecret()),
            'fingerprint_hash' => hash_hmac('sha256', $ua, $this->getSecret())
        ];

        // 🛡️ SUBDOMAIN SURFACE CONTEXT ISOLATION
        $host = explode(':', $_SERVER['HTTP_HOST'] ?? '')[0];
        if ($host === 'license.airroofers.eu') {
            $_SESSION['mt_surface'] = 'license';
            $_SESSION['mt_role']    = 'auditor';
            $_SESSION['mt_context'] = 'verification';
        } else {
            $_SESSION['mt_surface'] = 'portal';
            $_SESSION['mt_role']    = 'customer';
            $_SESSION['mt_context'] = 'entitlement';
        }
    }

    /**
     * Check if the current session has a valid trust context
     */
    public function hasValidTrust(string $licenseId): bool
    {
        $context = $_SESSION['portal_trust_context'] ?? null;
        if (!$context) return false;

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

        $expectedIpHash = hash_hmac('sha256', $ip, $this->getSecret());
        $expectedFpHash = hash_hmac('sha256', $ua, $this->getSecret());

        // Verify IP and Browser User-Agent Fingerprint Consistency via cryptographic hashes
        if (!hash_equals($context['ip_hash'] ?? '', $expectedIpHash)) {
            return false;
        }

        if (!hash_equals($context['fingerprint_hash'] ?? '', $expectedFpHash)) {
            return false;
        }

        return hash_equals($context['license_hash'], $this->hashLicenseId($licenseId));
    }

    private function getSecret(): string
    {
        return defined('MANDATAG_APP_KEY') ? MANDATAG_APP_KEY : 'mt-fallback-secret-2026';
    }
}
