<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: LoginRateLimiter.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose: IP + email based login rate limiting
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Infrastructure\Database;
use Mandatag\Exceptions\HttpException;

final class LoginRateLimiter
{
    private const MAX_ATTEMPTS = 5;
    private const WINDOW_MINUTES = 10;

    public function check(string $email): void
    {
        $db = Database::instance();

        $count = $db->fetchValue(
            'SELECT COUNT(*) FROM admin_audit_log
             WHERE event = "login.failed"
             AND created_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
             AND metadata->>"$.email" = ?',
            [self::WINDOW_MINUTES, $email]
        );

        if ($count >= self::MAX_ATTEMPTS) {

            throw new HttpException(
                'Too many login attempts. Please wait before retrying.',
                429
            );

        }
    }
}
