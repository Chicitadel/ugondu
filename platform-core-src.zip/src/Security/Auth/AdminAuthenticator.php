<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: AdminAuthenticator.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose:
 *   Deterministic Admin Authentication Orchestrator
 *   - Password verification
 *   - Lock protection
 *   - Risk scoring
 *   - Baseline Zero Trust enforcement
 *   - Super Admin dual-factor orchestration
 *   - Audit logging
 *   - Non-regressive execution
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 26 – Baseline Trust Orchestration Refactor
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * - No schema changes
 * - No middleware dependency changes
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Infrastructure\Database;
use Mandatag\Security\Audit\AdminAuditLogger;
use Mandatag\Security\ZeroTrust\RiskEngine;
use Mandatag\Bootstrap\session;

final class AdminAuthenticator
{
    private const LOCK_MINUTES = 15;

    public function attempt(string $email, string $password): ?array
    {
        $limiter = new \Mandatag\Security\RateLimit\RateLimiter(
            'login_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
            10,
            60
        );
        $limiter->enforce();

        session::boot();

        $db = Database::instance();

        $user = $db->fetchOne(
            'SELECT * FROM admin_users WHERE email = ?',
            [$email]
        );

        if (!$user) {
            AdminAuditLogger::log(null, 'login.failed', ['email' => $email]);
            return null;
        }

        if ((int)$user['is_active'] !== 1) {
            return null;
        }

        if ($user['locked_until'] &&
            strtotime((string)$user['locked_until']) > time()) {

            http_response_code(423);
            exit('Account locked.');
        }

        /*
        |--------------------------------------------------------------------------
        | PASSWORD VERIFICATION
        |--------------------------------------------------------------------------
        */

        if (!password_verify($password, $user['password_hash'])) {

            $db->execute(
                'UPDATE admin_users
                 SET failed_attempts = failed_attempts + 1
                 WHERE id = ?',
                [$user['id']]
            );

            $this->checkLock((int)$user['id']);

            AdminAuditLogger::log($user['id'], 'login.failed');

            return null;
        }

        /*
        |--------------------------------------------------------------------------
        | PASSWORD SUCCESS
        |--------------------------------------------------------------------------
        */

        /*
        |--------------------------------------------------------------------------
        | 🔐 PASSWORD POLICY INTELLIGENCE (NON-BLOCKING)
        |--------------------------------------------------------------------------
        |
        | Applies centralized PasswordPolicyService WITHOUT breaking login.
        | - No rejection
        | - No UX disruption
        | - Risk escalation + audit only
        |--------------------------------------------------------------------------
        */

        try {

            $policy = new \Mandatag\Services\PasswordPolicyService();

            $result = $policy->validate(
                (int)$user['id'],
                $password,
                $password
            );

            if (!$result['valid']) {

                // 🔥 Escalate risk instead of blocking login
                (new \Mandatag\Services\AdminRiskService())
                    ->escalateWeakPassword(
                        (int)$user['id'],
                        (float)$result['entropy'],
                        (int)$result['breach_count']
                    );

                AdminAuditLogger::log(
                $user['id'],
                'auth.weak_password_detected',
                [
                    'entropy' => $result['entropy'],
                    'breach_count' => $result['breach_count']
                ]
            );

            /*
            |--------------------------------------------------------------------------
            | 🔥 ADAPTIVE ENFORCEMENT SIGNAL (SESSION-LEVEL)
            |--------------------------------------------------------------------------
            |
            | This does NOT enforce anything directly.
            | It provides a deterministic signal for RiskEngine.
            |--------------------------------------------------------------------------
            */

            $_SESSION['weak_password_detected'] = true;
            $_SESSION['weak_password_entropy']  = $result['entropy'];
            $_SESSION['weak_password_breach']   = $result['breach_count'];
            }

        } catch (\Throwable $e) {
            // 🔒 NEVER break authentication flow
        }

        /*
        |--------------------------------------------------------------------------
        | FORCE PASSWORD ROTATION FLAG
        |--------------------------------------------------------------------------
        */

        if ((int)($user['password_must_change'] ?? 0) === 1) {

            $_SESSION['force_password_change'] = true;
            $_SESSION['force_password_user']   = $user['id'];

            AdminAuditLogger::log(
                $user['id'],
                'password.rotation_required'
            );
        }

        $db->execute(
            'UPDATE admin_users
             SET failed_attempts = 0,
                 locked_until = NULL,
                 last_login_at = NOW(),
                 last_login_ip = ?,
                 session_last_rotated = NOW()
             WHERE id = ?',
            [$_SERVER['REMOTE_ADDR'] ?? null, $user['id']]
        );

        /*
        |--------------------------------------------------------------------------
        | BASELINE ZERO TRUST ORCHESTRATION
        |--------------------------------------------------------------------------
        |
        | Determines setup vs return login path.
        | No redirects here.
        | Only sets deterministic session markers.
        |--------------------------------------------------------------------------
        */

        $_SESSION['pre_mfa_user'] = $user;

        /*
        |--------------------------------------------------------------------------
        | 🔥 ZERO-TRUST EXTREME SIGNAL COLLECTION
        |--------------------------------------------------------------------------
        |
        | Collect device + network intelligence WITHOUT blocking login.
        |--------------------------------------------------------------------------
        */

        $_SESSION['zt_device_hash'] = hash(
            'sha256',
            ($_SERVER['HTTP_USER_AGENT'] ?? '') .
            ($_SERVER['REMOTE_ADDR'] ?? '')
        );

        $_SESSION['zt_ip'] = $_SERVER['REMOTE_ADDR'] ?? null;

        /*
        |--------------------------------------------------------------------------
        | GEO / IP ANOMALY DETECTION (LIGHTWEIGHT)
        |--------------------------------------------------------------------------
        |
        | No external API (shared hosting safe)
        | Detect simple anomaly: IP drift vs last login
        |--------------------------------------------------------------------------
        */

        $lastIp = $user['last_login_ip'] ?? null;

        if ($lastIp && $lastIp !== $_SESSION['zt_ip']) {
            $_SESSION['zt_geo_anomaly'] = true;
        } else {
            $_SESSION['zt_geo_anomaly'] = false;
        }

        $hasTotp = (bool)$db->fetchValue(
            'SELECT COUNT(*) FROM admin_mfa WHERE admin_id = ?',
            [$user['id']]
        );

        $hasRecovery = (bool)$db->fetchValue(
            'SELECT COUNT(*) FROM admin_mfa_recovery_codes WHERE admin_id = ?',
            [$user['id']]
        );

        $hasWebAuthn = (bool)$db->fetchValue(
            'SELECT COUNT(*) FROM admin_webauthn_credentials WHERE admin_id = ?',
            [$user['id']]
        );

        /*
        |--------------------------------------------------------------------------
        | SETUP FLOW (FIRST-TIME CONFIGURATION)
        |--------------------------------------------------------------------------
        */

        if (!$hasTotp) {
            $_SESSION['auth_stage'] = 'mfa_enroll';
        }

        elseif (!$hasRecovery) {
            $_SESSION['auth_stage'] = 'mfa_recovery';
        }

        elseif ($user['role'] === 'super_admin' && !$hasWebAuthn) {
            $_SESSION['auth_stage'] = 'webauth_enroll';
        }

        else {
            $_SESSION['auth_stage'] = 'mfa_verify';
        }

        /*
        |--------------------------------------------------------------------------
        | RISK ENGINE (Post-Baseline Only)
        |--------------------------------------------------------------------------
        */

        $riskEngine = new RiskEngine();
        $riskScore  = $riskEngine->evaluate((int)$user['id']);

        /*
        |--------------------------------------------------------------------------
        | 🔥 ZERO-TRUST EXTREME ENFORCEMENT
        |--------------------------------------------------------------------------
        */

        /*
        | CRITICAL — SESSION KILL
        */
        if ($riskScore >= 90) {

            AdminAuditLogger::log(
                $user['id'],
                'auth.session_killed',
                [
                    'risk_score' => $riskScore,
                    'reason' => 'extreme_zero_trust'
                ]
            );

            session_destroy();

            http_response_code(403);
            exit('Access denied due to security policy.');
        }

        /*
        | HIGH — FORCE PASSWORD ROTATION
        */
        if ($riskScore >= 80) {

            $_SESSION['force_password_change'] = true;
            $_SESSION['force_password_user']   = $user['id'];

            AdminAuditLogger::log(
                $user['id'],
                'auth.password_rotation_forced_extreme',
                ['risk_score' => $riskScore]
            );
        }

        /*
        | MEDIUM — STEP-UP MFA
        */
        if ($riskScore >= 60) {

            $_SESSION['step_up_required'] = true;
            $_SESSION['step_up_admin']    = $user['id'];

            AdminAuditLogger::log(
                $user['id'],
                'auth.step_up_extreme',
                ['risk_score' => $riskScore]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 🔥 ADAPTIVE ENFORCEMENT DECISION
        |--------------------------------------------------------------------------
        |
        | Converts risk into deterministic action.
        |--------------------------------------------------------------------------
        */

        if ($riskScore >= 70) {

            $_SESSION['step_up_required'] = true;
            $_SESSION['step_up_admin']    = $user['id'];

            AdminAuditLogger::log(
                $user['id'],
                'auth.step_up_enforced',
                [
                    'risk_score' => $riskScore,
                    'reason' => 'adaptive_enforcement'
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CRITICAL ENFORCEMENT (VERY HIGH RISK)
        |--------------------------------------------------------------------------
        */

        if ($riskScore >= 85) {

            $_SESSION['force_password_change'] = true;
            $_SESSION['force_password_user']   = $user['id'];

            AdminAuditLogger::log(
                $user['id'],
                'auth.password_rotation_enforced',
                [
                    'risk_score' => $riskScore
                ]
            );
        }

        if ($riskScore >= 60) {

            $_SESSION['step_up_required'] = true;
            $_SESSION['step_up_admin']    = $user['id'];

            AdminAuditLogger::log(
                $user['id'],
                'login.step_up_required',
                ['risk_score' => $riskScore]
            );
        }

        AdminAuditLogger::log($user['id'], 'login.success');


        /*
        |--------------------------------------------------------------------------
        | DEVICE BASELINE LEARNING
        |--------------------------------------------------------------------------
        */

        $db->execute(
            'UPDATE admin_users
             SET last_device_hash = ?
             WHERE id = ?',
            [
                $_SESSION['zt_device_hash'] ?? null,
                $user['id']
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | IMPORTANT FIX – RETURN AUTHENTICATED USER
        |--------------------------------------------------------------------------
        |
        | Previous implementation always returned null, causing
        | login controller to treat successful authentication
        | as invalid credentials.
        |
        | We now return the verified user record while preserving:
        | - Zero Trust stage orchestration
        | - MFA routing logic
        | - Risk engine evaluation
        | - Audit logging
        |
        | Backward compatible.
        | No schema impact.
        | Deterministic behavior preserved.
        |--------------------------------------------------------------------------
        */

        return $user;
    }

    private function checkLock(int $userId): void
    {
        $db = Database::instance();

        $attempts = (int)$db->fetchValue(
            'SELECT failed_attempts FROM admin_users WHERE id = ?',
            [$userId]
        );

        if ($attempts >= 5) {

            $db->execute(
                'UPDATE admin_users
                 SET locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE)
                 WHERE id = ?',
                [self::LOCK_MINUTES, $userId]
            );

            AdminAuditLogger::log($userId, 'account.locked');
        }
    }
}
