<?php

declare(strict_types=1);

/**
 * MANDATAG — Internal Licensing, Entitlement & Administrative Control System
 * 
 * © Air Roofers SAS
 * 
 * Author:    Ignatus Chika Ujomor
 * Role:      Software Architect & Systems Engineer
 * Web:       https://www.ujomor.com
 * Signature: "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 * Location:  /Mandatag/Security/Auth/AuthorityTrustMiddleware.php
 * Purpose:   Security Gate for the Protected Entitlement Zone
 * Version:   1.0 (Refactor 2026)
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Bootstrap\ContainerRegistry;

/**
 * AuthorityTrustMiddleware
 *
 * Enforces mandatory identity verification for the Protected Entitlement Zone.
 * Redirects unauthenticated requests to the Public Lookup portal.
 */
final class AuthorityTrustMiddleware
{
    private $manager;

    public function __construct(?TrustAuthorityManager $manager = null)
    {
        $this->manager = $manager ?? ContainerRegistry::get()->get(TrustAuthorityManager::class);
    }

    /**
     * Handle the middleware enforcement
     */
    public function handle(): void
    {
        // 🛡️ SUBDOMAIN SURFACE SOVEREIGNTY SEGREGATION GUARD
        $host = explode(':', $_SERVER['HTTP_HOST'] ?? '')[0];
        if ($host === 'admin.airroofers.eu') {
            $this->flushAndDeny("Administrative access context violation on entitlement plane.");
        }

        $surface = $_SESSION['mt_surface'] ?? null;
        if ($host === 'license.airroofers.eu' && $surface !== 'license') {
            $this->flushAndDeny("Access context violation — license surface mismatch.");
        }
        if ($host === 'portal.airroofers.eu' && $surface !== 'portal') {
            $this->flushAndDeny("Access context violation — portal surface mismatch.");
        }

        $context = $_SESSION['portal_trust_context'] ?? null;

        // 🛡️ BASIC TRUST CHECK
        if (!$context || empty($context['license_hash']) || empty($context['license_id'])) {
            $this->flushAndDeny();
        }

        // 🛡️ SESSION FRESHNESS CHECK (Synchronized 15-minute server authoritative timeout)
        $verifiedAt = $context['verified_at'] ?? 0;
        if ((time() - $verifiedAt) > 900) {
            $this->flushAndDeny("Session expired. Please re-verify.");
        }

        // 🛡️ CRYPTOGRAPHIC BINDING INTEGRITY CHECK (IP & Fingerprint)
        if (!$this->manager->hasValidTrust($context['license_id'])) {
             $this->flushAndDeny("Security context binding mismatch.");
        }
    }

    private function flushAndDeny(string $message = 'Verification required.'): void
    {
        // 🔒 MANDATORY COMPLETE CONTEXT WIPE & DESTRUCTION (Replays blocked)
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION = [];
            session_destroy();
            session_start();
            session_regenerate_id(true);
        }

        // For API requests, return JSON
        if (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'trust_expired_or_invalid',
                'message' => $message
            ]);
            exit;
        }

        // For browser requests, redirect to Public Lookup
        header('Location: /public/verify?error=session_expired');
        exit;
    }
}
