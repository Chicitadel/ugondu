<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

namespace AirRoofers\PlatformCore\Security\Auth;

final class BreakGlassDualApproval
{
    public static function request(int $adminId, string $reason): void
    {
        $_SESSION['break_glass_request'] = [
            'admin_id' => $adminId,
            'reason' => $reason,
            'requested_at' => time(),
        ];
    }

    public static function approve(int $approverId): void
    {
        if (!isset($_SESSION['break_glass_request'])) {
            return;
        }
        $_SESSION['dual_control_approved'] = true;
    }
}
