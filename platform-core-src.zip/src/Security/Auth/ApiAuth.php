<?php
/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 */

declare(strict_types=1);

/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: ApiAuth.php
 * Location: /public_html/Mandatag/Security/Auth/
 * Purpose: Unified API authentication and authorization guard layer
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 4.1 — API Contract Enforcement + Auth Hardening
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * - JSON-only API compliance
 * - SSE-safe compatibility
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Mandatag\Infrastructure\Http\ApiResponse;
use Mandatag\Bootstrap\session;

final class ApiAuth
{
    /**
     * ------------------------------------------------------------
     * REQUIRE ADMIN (STRICT ENFORCEMENT)
     * ------------------------------------------------------------
     *
     * Terminates execution if admin session is missing.
     * Use for all /v1/* endpoints (NON-SSE).
     *
     * Safe:
     * - JSON response only
     * - No redirects
     * - Fully aligned with API contract
     */
    public static function requireAdmin(): void
    {
        if (!self::checkAdmin()) {
            self::deny();
        }
    }

    /**
     * ------------------------------------------------------------
     * CHECK ADMIN (NON-DESTRUCTIVE)
     * ------------------------------------------------------------
     *
     * Returns:
     * - true  → authenticated
     * - false → not authenticated
     *
     * Use for:
     * - SSE controllers
     * - Conditional flows
     * - Pre-flight checks
     */
    public static function checkAdmin(): bool
    {
        self::ensureSession();

        return isset($_SESSION['admin']['id'])
            && is_numeric($_SESSION['admin']['id']);
    }

    /**
     * ------------------------------------------------------------
     * REQUIRE PERMISSION (RBAC READY)
     * ------------------------------------------------------------
     *
     * Future-proof permission enforcement layer.
     * Does NOT break existing system if permissions are absent.
     *
     * @param string $permission
     */
    public static function requirePermission(string $permission): void
    {
        if (!self::checkAdmin()) {
            self::deny();
        }

        $permissions = $_SESSION['admin']['permissions'] ?? [];

        // Backward compatibility: allow if permissions not yet implemented
        if (!is_array($permissions) || empty($permissions)) {
            return;
        }

        if (!in_array($permission, $permissions, true)) {
            self::forbidden();
        }
    }

    /**
     * ------------------------------------------------------------
     * REQUIRE HIGH TRUST (FUTURE SECURITY LAYER)
     * ------------------------------------------------------------
     *
     * Used for sensitive operations:
     * - key rotation
     * - license revocation
     * - security overrides
     */
    public static function requireHighTrust(): void
    {
        if (!self::checkAdmin()) {
            self::deny();
        }

        $trust = $_SESSION['admin']['trust'] ?? 'normal';

        if (!in_array($trust, ['elevated', 'locked'], true)) {
            self::forbidden();
        }
    }

    /**
     * ------------------------------------------------------------
     * DENY (UNAUTHORIZED)
     * ------------------------------------------------------------
     *
     * Standard API rejection
     */
    public static function deny(): void
    {
        ApiResponse::unauthorized();
    }

    /**
     * ------------------------------------------------------------
     * FORBIDDEN (AUTHENTICATED BUT NOT ALLOWED)
     * ------------------------------------------------------------
     */
    public static function forbidden(): void
    {
        ApiResponse::forbidden();
    }

    /**
     * ------------------------------------------------------------
     * ENSURE SESSION
     * ------------------------------------------------------------
     *
     * Centralized session boot logic
     * Prevents duplication across methods
     */
    private static function ensureSession(): void
    {
        session::boot();
    }
}
