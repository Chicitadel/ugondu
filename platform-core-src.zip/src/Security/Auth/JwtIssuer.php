<?php

declare(strict_types=1);

/**
 * MANDATAG — Internal Licensing, Entitlement & Administrative Control System
 * 
 * © Air Roofers SAS
 * 
 * Author:    Ignatus Chika Ujomor
 * Role:      Software Architect & Systems Engineer
 * Web:       https://www.ujomor.com
 * Signature: "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 * Location:  /Mandatag/Security/Auth/JwtIssuer.php
 * Purpose:   JWT Issuance + Verification (RS256 + KID aware)
 * Version:   1.1 (Instance-based Verify)
 * --------------------------------------------------------------------
 */

namespace AirRoofers\PlatformCore\Security\Auth;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use RuntimeException;

final class JwtIssuer
{
    private array $config;

    public function __construct(array $config)
    {
        if (empty($config['keys']) || empty($config['kid'])) {
            throw new RuntimeException('JWT config invalid');
        }

        $this->config = $config;
    }

    /*
    |--------------------------------------------------------------------------
    | Issue Token
    |--------------------------------------------------------------------------
    */
    public function issue(array $claims, array $scopes): string
    {
        $now = time();

        $payload = array_merge($claims, [
            'iss'   => $this->config['issuer'],
            'iat'   => $now,
            'exp'   => $now + $this->config['lifetime'],
            'nbf'   => $now - $this->config['leeway'],
            'scope' => $scopes,
        ]);

        return JWT::encode(
            $payload,
            $this->config['keys'][$this->config['kid']],
            $this->config['algo'],
            $this->config['kid']
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Verify Token (Instance-based)
    |--------------------------------------------------------------------------
    */
    public function verify(string $jwt): array
    {
        $decodedHeader = JWT::jsonDecode(
            JWT::urlsafeB64Decode(explode('.', $jwt)[0])
        );

        $kid = $decodedHeader->kid ?? null;

        /*
        |--------------------------------------------------------------------------
        | HS256 (Symmetric) Support — Current Mode
        |--------------------------------------------------------------------------
        */
        if ($this->config['algo'] === 'HS256') {

            if (!$kid || empty($this->config['keys'][$kid])) {
                throw new RuntimeException('Invalid KID');
            }

            $secret = $this->config['keys'][$kid];

            $decoded = JWT::decode(
                $jwt,
                [$kid => new Key($secret, 'HS256')]
            );

            return (array) $decoded;
        }

        /*
        |--------------------------------------------------------------------------
        | RS256 (Asymmetric) Support — Future Mode
        |--------------------------------------------------------------------------
        */
        if ($this->config['algo'] === 'RS256') {

            if (!$kid || empty($this->config['public_keys'][$kid])) {
                throw new RuntimeException('Invalid KID');
            }

            $publicKey = $this->config['public_keys'][$kid];

            $decoded = JWT::decode(
                $jwt,
                new Key($publicKey, 'RS256')
            );

            return (array) $decoded;
        }

        throw new RuntimeException('Unsupported JWT algorithm');
    }
}
