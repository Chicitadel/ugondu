<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Platform Core — Telemetry Client Helper
 * File           : TelemetryClient.php
 * Version        : 1.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Air Roofers Enterprise Operations
 * Created Date   : 2026-07-27
 * Last Modified  : 2026-07-27
 * Classification : ENTERPRISE
 * Copyright (c) 2026 Air Roofers Enterprise Operations. All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\PlatformCore\Telemetry;

class TelemetryClient {
    private string $telemetryUrl;
    private string $telemetryKey;

    public function __construct(string $telemetryUrl = 'http://telemetry.airroofers.eu', string $telemetryKey = 'telemetry_sys_secret_2026') {
        $this->telemetryUrl = rtrim($telemetryUrl, '/');
        $this->telemetryKey = $telemetryKey;
    }

    public function sendAuditLog(array $logData): bool {
        $url = $this->telemetryUrl . '/v1/audit/ingest';
        $ch = curl_init($url);
        
        $payload = json_encode([
            'event_type' => $logData['event_type'] ?? 'system_event',
            'source'     => $logData['source'] ?? 'airroofers-platform',
            'payload'    => $logData['payload'] ?? [],
            'timestamp'  => date('c'),
            'correlation_id' => $logData['correlation_id'] ?? $_SERVER['HTTP_X_CORRELATION_ID'] ?? uniqid('tx_', true)
        ]);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'X-Telemetry-Key: ' . $this->telemetryKey,
                'X-Correlation-ID: ' . ($logData['correlation_id'] ?? 'tx_sys')
            ],
            CURLOPT_TIMEOUT        => 3,
            CURLOPT_CONNECTTIMEOUT => 1,
        ]);

        $res = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $code === 200 || $code === 201;
    }
}
