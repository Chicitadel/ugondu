<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Platform Core — HTTP
 * File           : BrandedErrorPage.php
 * Version        : 1.0.0
 * Author         : Platform Engineering Team
 * Organization   : Air Roofers Enterprise Operations
 * Created Date   : 2026-07-25
 * Last Modified  : 2026-07-25
 * Classification : ENTERPRISE | INTERNAL
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 *
 * Copyright (c) 2026 Air Roofers Enterprise Operations
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\PlatformCore\Http;

/**
 * BrandedErrorPage
 *
 * Implements HTTP content negotiation per RFC 7231.
 * - Browser clients (Accept: text/html) → receive a fully branded HTML error page.
 * - API clients (Accept: application/json) → receive standard JSON response (unchanged).
 *
 * Usage in any platform-core service index.php:
 *   BrandedErrorPage::handleIfBrowser(401, 'Unauthorized', 'Your session has expired.');
 *   BrandedErrorPage::handleIfBrowser(404, 'Not Found', 'The requested resource could not be located.');
 *   BrandedErrorPage::handleIfBrowser(403, 'Forbidden', 'You do not have permission to access this resource.');
 */
class BrandedErrorPage
{
    private const LOGO_URL    = 'https://static.airroofers.eu/brands/mandatag/logo.png';
    private const FAVICON_URL = 'https://static.airroofers.eu/brands/mandatag/favicon.ico';
    private const LOGIN_URL   = 'https://airroofers.eu/?page=portal';
    private const HUB_URL     = 'https://hub.airroofers.eu';

    /** @var array<int, array{label: string, icon: string, color: string}> */
    private static array $statusMeta = [
        401 => ['label' => 'Unauthorized',  'icon' => '🔐', 'color' => '#f59e0b'],
        403 => ['label' => 'Forbidden',     'icon' => '🚫', 'color' => '#ef4444'],
        404 => ['label' => 'Not Found',     'icon' => '🔍', 'color' => '#6366f1'],
        429 => ['label' => 'Rate Limited',  'icon' => '⏱️', 'color' => '#f97316'],
        500 => ['label' => 'Server Error',  'icon' => '⚠️', 'color' => '#dc2626'],
        503 => ['label' => 'Unavailable',   'icon' => '🔧', 'color' => '#64748b'],
    ];

    /**
     * Detect if the current request originated from a browser.
     * Uses the Accept header per RFC 7231 §5.3.2.
     */
    public static function isBrowserRequest(): bool
    {
        $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
        // Browser requests include text/html; pure API clients send application/json only
        return str_contains($accept, 'text/html') || str_contains($accept, '*/*');
    }

    /**
     * If the request is from a browser, serve a branded HTML error page and exit.
     * Otherwise, do nothing (allow the caller to send JSON as normal).
     */
    public static function handleIfBrowser(int $statusCode, string $title, string $detail = ''): void
    {
        if (!self::isBrowserRequest()) {
            return;
        }

        $meta    = self::$statusMeta[$statusCode] ?? ['label' => $title, 'icon' => '❌', 'color' => '#64748b'];
        $label   = $meta['label'];
        $icon    = $meta['icon'];
        $color   = $meta['color'];
        $service = self::resolveServiceName();

        http_response_code($statusCode);
        header('Content-Type: text/html; charset=UTF-8');
        header('Cache-Control: no-store, no-cache');

        echo self::renderHtml($statusCode, $label, $icon, $color, $title, $detail, $service);
        exit;
    }

    /**
     * Resolve the current service name from the HTTP_HOST header.
     */
    private static function resolveServiceName(): string
    {
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $map  = [
            'identity'      => 'Identity Service',
            'workspace'     => 'Workspace Service',
            'products'      => 'Products Service',
            'operations'    => 'Operations Service',
            'registry'      => 'Registry Service',
            'governance'    => 'Governance Service',
            'billing'       => 'Billing Service',
            'discovery'     => 'Discovery Service',
            'downloads'     => 'Downloads Service',
            'notifications' => 'Notifications Service',
            'certify'       => 'Certification Service',
            'telemetry'     => 'Telemetry Service',
            'marketplace'   => 'Marketplace Service',
            'orchestrator'  => 'Orchestrator Service',
            'ingestion'     => 'Ingestion Service',
            'runtime'       => 'Runtime Service',
            'api'           => 'Platform API',
        ];

        foreach ($map as $subdomain => $name) {
            if (str_contains($host, $subdomain)) {
                return $name;
            }
        }

        return 'Air Roofers Platform';
    }

    /**
     * Render the full branded HTML page.
     */
    private static function renderHtml(
        int    $code,
        string $label,
        string $icon,
        string $color,
        string $title,
        string $detail,
        string $service
    ): string {
        $safeTitle   = htmlspecialchars($title,   ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $safeDetail  = htmlspecialchars($detail,  ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $safeService = htmlspecialchars($service, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $safeLabel   = htmlspecialchars($label,   ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        // PHP heredoc only interpolates $variables — NOT self::CONST expressions.
        // Assign all class constants to local variables before the heredoc.
        $logoUrl    = self::LOGO_URL;
        $faviconUrl = self::FAVICON_URL;
        $loginUrl   = self::LOGIN_URL;
        $hubUrl     = self::HUB_URL;
        $reqUri     = htmlspecialchars($_SERVER['REQUEST_URI'] ?? '/', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        $showLogin = ($code === 401 || $code === 403);

        $loginBlock = $showLogin ? <<<HTML
            <a href="{$reqUri}"
               onclick="event.preventDefault(); window.location.href='{$loginUrl}';"
               class="btn-primary">
               🔑 Sign In to Air Roofers
            </a>
HTML : '';

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex, nofollow">
  <title>{$code} {$safeLabel} • Air Roofers COS</title>
  <link rel="icon" type="image/x-icon" href="{$faviconUrl}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg-deep:    #020617;
      --bg-surface: #0f172a;
      --bg-card:    #1e293b;
      --border:     rgba(148, 163, 184, 0.12);
      --text-primary:   #f8fafc;
      --text-secondary: #94a3b8;
      --accent:     {$color};
    }

    html, body {
      height: 100%;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      background: var(--bg-deep);
      color: var(--text-primary);
    }

    .page {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      background:
        radial-gradient(ellipse 80% 60% at 50% -20%, rgba(99,102,241,0.15) 0%, transparent 60%),
        var(--bg-deep);
    }

    .brand-bar {
      position: fixed;
      top: 0; left: 0; right: 0;
      height: 56px;
      background: rgba(15,23,42,0.95);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      padding: 0 1.5rem;
      gap: 0.75rem;
      z-index: 100;
    }

    .brand-logo {
      width: 28px;
      height: 28px;
      object-fit: contain;
    }

    .brand-name {
      font-size: 0.875rem;
      font-weight: 600;
      color: var(--text-primary);
    }

    .brand-sep { color: var(--border); margin: 0 0.25rem; }

    .brand-service {
      font-size: 0.8rem;
      color: var(--text-secondary);
    }

    .card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 3rem 2.5rem;
      max-width: 520px;
      width: 100%;
      text-align: center;
      box-shadow: 0 24px 48px rgba(0,0,0,0.4);
      margin-top: 2rem;
    }

    .status-icon {
      font-size: 3.5rem;
      display: block;
      margin-bottom: 1rem;
      filter: drop-shadow(0 0 16px {$color}80);
    }

    .status-code {
      font-size: 5rem;
      font-weight: 700;
      color: var(--accent);
      line-height: 1;
      letter-spacing: -3px;
    }

    .status-label {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-top: 0.5rem;
    }

    .status-detail {
      font-size: 0.9rem;
      color: var(--text-secondary);
      margin-top: 0.75rem;
      line-height: 1.6;
    }

    .divider {
      width: 48px;
      height: 2px;
      background: linear-gradient(90deg, transparent, var(--accent), transparent);
      margin: 1.5rem auto;
      border-radius: 2px;
    }

    .actions {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      margin-top: 1.5rem;
    }

    .btn-primary {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      background: var(--accent);
      color: #fff;
      text-decoration: none;
      font-size: 0.875rem;
      font-weight: 600;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      transition: opacity 0.2s;
    }

    .btn-primary:hover { opacity: 0.85; }

    .btn-secondary {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      background: rgba(148,163,184,0.1);
      color: var(--text-secondary);
      text-decoration: none;
      font-size: 0.875rem;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      border: 1px solid var(--border);
      transition: background 0.2s, color 0.2s;
    }

    .btn-secondary:hover { background: rgba(148,163,184,0.18); color: var(--text-primary); }

    .meta {
      margin-top: 2rem;
      font-size: 0.75rem;
      color: #475569;
    }

    .meta code {
      font-family: 'SF Mono', 'Fira Code', monospace;
      background: rgba(255,255,255,0.06);
      padding: 2px 6px;
      border-radius: 4px;
    }
  </style>
</head>
<body>

  <div class="brand-bar">
    <img src="{$logoUrl}" alt="Air Roofers" class="brand-logo">
    <span class="brand-name">Air Roofers COS</span>
    <span class="brand-sep">›</span>
    <span class="brand-service">{$safeService}</span>
  </div>

  <div class="page">
    <div class="card">
      <span class="status-icon">{$icon}</span>
      <div class="status-code">{$code}</div>
      <div class="status-label">{$safeLabel}</div>
      <div class="status-detail">{$safeDetail}</div>
      <div class="divider"></div>
      <div class="actions">
        {$loginBlock}
        <a href="{$hubUrl}" class="btn-secondary">
          🏠 Return to Platform Hub
        </a>
        <a href="javascript:history.back()" class="btn-secondary">
          ← Go Back
        </a>
      </div>
      <div class="meta">
        HTTP <code>{$code}</code> &bull; <code>{$reqUri}</code>
      </div>
    </div>
  </div>

</body>
</html>
HTML;
    }
}
