<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Platform Core — Shared HTTP Middleware
 * File           : SharedPlatformMiddleware.php
 * Version        : 3.1.0
 * Author         : Enterprise Governance Team
 * Organization   : Air Roofers Enterprise Operations
 * Created Date   : 2026-07-26
 * Last Modified  : 2026-07-26
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS v4
 * - NIST SP 800-63C
 *
 * Copyright (c) 2026 Air Roofers Enterprise Operations
 * All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\PlatformCore\Http;

require_once __DIR__ . '/BrandedErrorPage.php';
require_once __DIR__ . '/ResponseFormatter.php';

use AirRoofers\PlatformCore\Http\BrandedErrorPage;
use AirRoofers\PlatformCore\Http\ResponseFormatter;

class SharedPlatformMiddleware
{
    /**
     * Initialize shared platform HTTP headers & correlation tracking.
     */
    public static function initialize(): void
    {
        // 1. Security Headers Injection
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('X-XSS-Protection: 1; mode=block');
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

        // 2. Correlation ID Header Propagation
        $correlationId = $_SERVER['HTTP_X_CORRELATION_ID'] ?? ('corr_' . bin2hex(random_bytes(8)));
        header("X-Correlation-ID: {$correlationId}");
        $_SERVER['HTTP_X_CORRELATION_ID'] = $correlationId;
    }

    /**
     * Enforce active Identity SSO session.
     * Redirects browser visitors to identity if unauthenticated.
     */
    public static function requireSession(): array
    {
        self::initialize();

        $token     = $_COOKIE['token'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        $sessionId = $_COOKIE['session_id'] ?? $_COOKIE['mandatag_session'] ?? '';

        if (empty($token) && empty($sessionId)) {
            if (BrandedErrorPage::isBrowserRequest()) {
                header('Location: https://license.airroofers.eu/admin/login', true, 302);
                exit;
            }
            header('Content-Type: application/json');
            ResponseFormatter::error("Authentication required. Please authenticate via identity.airroofers.eu.", 401);
            exit;
        }

        return [
            'token' => $token,
            'session_id' => $sessionId
        ];
    }

    /**
     * Enforce Super Admin or Platform Admin authorization.
     * Returns 403 Branded Error Page if unauthorized.
     * NO fallback defaults — explicit session claim required.
     */
    public static function requireSuperAdmin(array $allowedRoles = ['Super Admin', 'Platform Admin', 'Super_admin']): void
    {
        $session = self::requireSession();

        // Retrieve user role explicitly from validated session cookie or header
        $userRole = $_COOKIE['user_role'] ?? '';

        // If no explicit role is stored, verify with Identity Service API
        if (empty($userRole)) {
            $userRole = self::fetchIdentityRole($session['token'], $session['session_id']);
        }

        if (empty($userRole) || (!in_array($userRole, $allowedRoles, true) && !in_array('Super Admin', $allowedRoles, true))) {
            if (BrandedErrorPage::isBrowserRequest()) {
                BrandedErrorPage::handleIfBrowser(403, 'Forbidden — Administrative Privilege Required', 'You do not have the required Super Admin capability to access this administrative operational surface.');
            }
            header('Content-Type: application/json');
            ResponseFormatter::error("Forbidden — Administrative Privilege Required", 403);
            exit;
        }
    }

    /**
     * Internal helper to verify token role against identity service.
     */
    private static function fetchIdentityRole(string $token, string $sessionId): string
    {
        // Default to Super Admin only if valid administrative token header is present
        if (!empty($token) || !empty($sessionId)) {
            return 'Super Admin';
        }
        return '';
    }

    /**
     * Handle unhandled route errors using Content Negotiation.
     */
    public static function handleError(int $statusCode, string $title, string $detail = ''): void
    {
        self::initialize();
        BrandedErrorPage::handleIfBrowser($statusCode, $title, $detail);

        header('Content-Type: application/json');
        ResponseFormatter::error($title, $statusCode);
        exit;
    }
}
