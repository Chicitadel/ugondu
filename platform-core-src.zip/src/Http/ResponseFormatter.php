<?php
namespace AirRoofers\PlatformCore\Http;

class ResponseFormatter {
    private static function getCorrelationId(): string {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        return $_SERVER['HTTP_X_CORRELATION_ID'] ?? $headers['X-Correlation-ID'] ?? $headers['x-correlation-id'] ?? uniqid('tx_', true);
    }

    public static function success($data = [], $meta = [], $links = [], $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json');
        
        $correlationId = self::getCorrelationId();
        header("X-Correlation-ID: {$correlationId}");

        $response = [
            'success'       => true,
            'timestamp'     => date('c'),
            'correlationId' => $correlationId,
            'data'          => $data
        ];

        if (!empty($meta)) {
            $response['meta'] = $meta;
        }
        if (!empty($links)) {
            $response['links'] = $links;
        }

        echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function error($message, $code = 400, $details = []) {
        http_response_code($code);
        header('Content-Type: application/json');

        $correlationId = self::getCorrelationId();
        header("X-Correlation-ID: {$correlationId}");

        echo json_encode([
            'success'       => false,
            'timestamp'     => date('c'),
            'correlationId' => $correlationId,
            'error'         => [
                'code'    => "ERR-{$code}",
                'message' => $message,
                'details' => $details
            ]
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

