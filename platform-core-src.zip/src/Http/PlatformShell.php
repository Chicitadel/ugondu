<?php
/******************************************************************************
 * Project        : Air Roofers Platform
 * Module         : Platform Core — Shared Infrastructure Shell & Presentation Engine
 * File           : PlatformShell.php
 * Version        : 6.0.0
 * Author         : Enterprise Governance Team
 * Organization   : Air Roofers SASU
 * Created Date   : 2026-07-26
 * Last Modified  : 2026-07-26
 * Classification : ENTERPRISE | PUBLIC
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Copyright (c) 2026 Air Roofers SASU. All Rights Reserved.
 ******************************************************************************/

namespace AirRoofers\PlatformCore\Http;

class PlatformShell
{
    /**
     * Enforce OWASP security & privacy headers platform-wide.
     */
    public static function applySecurityHeaders(): void
    {
        if (headers_sent()) return;
        header('X-Content-Type-Options: nosniff');
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        header('Content-Security-Policy: default-src \'self\' https://static.airroofers.eu https://fonts.googleapis.com https://fonts.gstatic.com; style-src \'self\' \'unsafe-inline\' https://fonts.googleapis.com; font-src \'self\' https://fonts.gstatic.com; img-src \'self\' data: https://static.airroofers.eu;');
        header_remove('X-Powered-By');
        header_remove('Server');
    }

    /**
     * Determine if incoming request is from an interactive browser vs API client.
     */
    public static function isBrowserRequest(): bool
    {
        if (isset($_GET['format'])) {
            return strtolower($_GET['format']) !== 'json';
        }

        if (($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '') === 'document') {
            return true;
        }

        $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
        $ua     = $_SERVER['HTTP_USER_AGENT'] ?? '';

        if (str_contains($accept, 'application/json') && !str_contains($accept, 'text/html') && !str_contains($ua, 'Mozilla')) {
            return false;
        }

        if (str_contains($accept, 'text/html') || str_contains($ua, 'Mozilla') || str_contains($ua, 'Chrome') || str_contains($ua, 'Safari') || str_contains($ua, 'Edge')) {
            return true;
        }

        return false;
    }

    /**
     * Generate unique Reference/Correlation Identifier for support.
     */
    public static function getReferenceId(): string
    {
        return $_SERVER['HTTP_X_CORRELATION_ID'] ?? ('ref_' . bin2hex(random_bytes(6)));
    }

    /**
     * Render standardized Minimal Public Health JSON (Machine-Readable).
     */
    public static function sendJsonSuccess(array $extra = [], int $statusCode = 200): void
    {
        self::applySecurityHeaders();
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        $payload = array_merge(['status' => 'operational'], $extra);
        echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /**
     * Render standardized Canonical Error JSON Envelope.
     */
    public static function sendJsonError(string $errorCode = 'NOT_FOUND', string $message = 'Resource unavailable.', int $statusCode = 404): void
    {
        self::applySecurityHeaders();
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => false,
            'error'   => [
                'code'    => $errorCode,
                'message' => $message
            ]
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /**
     * Handle public status routes (/ and /health) with 3 presentation modes.
     */
    public static function handleHealth(array $config): void
    {
        self::applySecurityHeaders();

        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if (!in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) {
            self::handleMethodNotAllowed($config['title'] ?? 'Platform Service');
        }

        if ($method === 'OPTIONS') {
            http_response_code(204);
            exit;
        }

        $rawUri = rtrim(strtolower(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH)), '/');
        if ($rawUri === '') {
            $rawUri = '/';
        }

        // Mode 1 & 2: Browser Interactive Cards (/ and /health with Accept: text/html)
        if (self::isBrowserRequest() && in_array($method, ['GET', 'HEAD'], true)) {
            $isHealthCheck = ($rawUri === '/health');
            self::renderServiceCard($config, $isHealthCheck);
            exit;
        }

        // Mode 3: Machine / API Client JSON (/health or /)
        self::sendJsonSuccess();
    }

    /**
     * Perform content-negotiated 404 handling.
     */
    public static function handleNotFound(string $serviceTitle = 'Platform Service'): void
    {
        self::applySecurityHeaders();

        if (self::isBrowserRequest()) {
            self::renderErrorCard($serviceTitle, 404, 'Resource Unavailable', 'The requested endpoint could not be found.');
            exit;
        }

        self::sendJsonError('NOT_FOUND', 'Resource unavailable.', 404);
    }

    /**
     * Perform content-negotiated 403 handling.
     */
    public static function handleForbidden(string $serviceTitle = 'Platform Service'): void
    {
        self::applySecurityHeaders();

        if (self::isBrowserRequest()) {
            self::renderErrorCard($serviceTitle, 403, 'Access Restricted', 'Authentication is required to access this resource.');
            exit;
        }

        self::sendJsonError('FORBIDDEN', 'Access restricted.', 403);
    }

    /**
     * Perform content-negotiated 405 Method Not Allowed handling.
     */
    public static function handleMethodNotAllowed(string $serviceTitle = 'Platform Service'): void
    {
        self::applySecurityHeaders();

        if (self::isBrowserRequest()) {
            self::renderErrorCard($serviceTitle, 405, 'Method Not Allowed', 'The requested HTTP method is not supported.');
            exit;
        }

        self::sendJsonError('METHOD_NOT_ALLOWED', 'Method not allowed.', 405);
    }

    /**
     * Perform content-negotiated 429 Rate Limit handling.
     */
    public static function handleTooManyRequests(string $serviceTitle = 'Platform Service'): void
    {
        self::applySecurityHeaders();

        if (self::isBrowserRequest()) {
            self::renderErrorCard($serviceTitle, 429, 'Too Many Requests', 'Request limit exceeded. Please try again later.');
            exit;
        }

        self::sendJsonError('TOO_MANY_REQUESTS', 'Rate limit exceeded.', 429);
    }

    /**
     * Perform content-negotiated 500 Internal Error handling.
     */
    public static function handleServerError(string $serviceTitle = 'Platform Service'): void
    {
        self::applySecurityHeaders();

        if (self::isBrowserRequest()) {
            $refId = self::getReferenceId();
            self::renderErrorCard($serviceTitle, 500, 'Temporary Service Issue', "An unexpected error occurred. Reference ID: {$refId}");
            exit;
        }

        self::sendJsonError('INTERNAL_ERROR', 'Temporary service issue.', 500);
    }

    /**
     * Render Unified Air Roofers Infrastructure Appliance Card (HTML UI).
     */
    public static function renderServiceCard(array $config, bool $isHealthCheckView = false): void
    {
        self::applySecurityHeaders();
        header('Content-Type: text/html; charset=utf-8');

        $serviceTitle = htmlspecialchars($config['title'] ?? 'Platform Service');
        $serviceGlyph = $config['glyph'] ?? '⚡';

        $logoUrl    = 'https://static.airroofers.eu/brands/mandatag/logo.png';
        $faviconUrl = 'https://static.airroofers.eu/brands/mandatag/favicon.ico';
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $serviceTitle; ?> — Air Roofers Platform</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="shortcut icon" href="<?php echo $faviconUrl; ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #090d16;
            --card-bg: rgba(18, 26, 43, 0.75);
            --border: rgba(255, 255, 255, 0.1);
            --accent: #3b82f6;
            --success: #10b981;
            --text-main: #f3f4f6;
            --text-muted: #9ca3af;
            --spacing-xs: 8px;
            --spacing-sm: 16px;
            --spacing-md: 24px;
            --spacing-lg: 32px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background-color: var(--bg);
            background-image: 
                radial-gradient(circle at 15% 20%, rgba(59, 130, 246, 0.08) 0%, transparent 45%),
                radial-gradient(circle at 85% 80%, rgba(16, 185, 129, 0.06) 0%, transparent 45%);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: var(--spacing-md) var(--spacing-sm);
        }

        .container {
            width: 100%;
            max-width: 540px;
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: var(--spacing-lg);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-bottom: var(--spacing-sm);
            border-bottom: 1px solid var(--border);
            margin-bottom: var(--spacing-md);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 0.85rem;
        }

        .brand-logo-img {
            width: 38px;
            height: 38px;
            border-radius: 8px;
            object-fit: contain;
            background: rgba(255, 255, 255, 0.05);
            padding: 4px;
            border: 1px solid var(--border);
        }

        .brand-title {
            font-size: 1.15rem;
            font-weight: 700;
            letter-spacing: -0.02em;
        }

        .brand-sub {
            font-size: 0.78rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .badge-status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(16, 185, 129, 0.12);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: var(--success);
            padding: 0.4rem 0.85rem;
            border-radius: 9999px;
            font-size: 0.82rem;
            font-weight: 600;
        }

        .pulse-dot {
            width: 8px;
            height: 8px;
            background-color: var(--success);
            border-radius: 50%;
            box-shadow: 0 0 10px var(--success);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }

        .hero-title-row {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: var(--spacing-xs);
        }

        .service-glyph {
            font-size: 1.6rem;
            line-height: 1;
        }

        .hero-title {
            font-size: 1.75rem;
            font-weight: 800;
            letter-spacing: -0.03em;
        }

        .hero-desc {
            color: var(--text-muted);
            font-size: 0.92rem;
            line-height: 1.55;
            margin-bottom: var(--spacing-md);
        }

        .status-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: var(--spacing-sm);
            margin-bottom: var(--spacing-md);
        }

        .status-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: var(--spacing-sm);
        }

        .status-label {
            font-size: 0.75rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.35rem;
        }

        .status-val {
            font-size: 0.95rem;
            font-weight: 600;
        }

        .links-bar {
            display: flex;
            gap: var(--spacing-sm);
            flex-wrap: wrap;
        }

        .btn-link {
            flex: 1;
            text-align: center;
            padding: 0.75rem var(--spacing-sm);
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text-main);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-link:hover {
            background: rgba(59, 130, 246, 0.15);
            border-color: var(--accent);
            color: white;
        }

        .footer {
            margin-top: var(--spacing-md);
            font-size: 0.8rem;
            color: var(--text-muted);
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="brand">
                <img src="<?php echo $logoUrl; ?>" alt="Air Roofers Mandatag" class="brand-logo-img">
                <div>
                    <div class="brand-title">Air Roofers</div>
                    <div class="brand-sub">Platform Infrastructure</div>
                </div>
            </div>
            <div class="badge-status">
                <div class="pulse-dot"></div>
                ● Operational
            </div>
        </div>

        <div class="hero-title-row">
            <span class="service-glyph"><?php echo $serviceGlyph; ?></span>
            <h1 class="hero-title"><?php echo $serviceTitle; ?></h1>
        </div>

        <?php if ($isHealthCheckView): ?>
            <p class="hero-desc">Automated health probe verification surface.</p>
            <div class="status-grid">
                <div class="status-card">
                    <div class="status-label">Health Check</div>
                    <div class="status-val" style="color: var(--success);">Operational</div>
                </div>
                <div class="status-card">
                    <div class="status-label">Last Updated</div>
                    <div class="status-val">Just now</div>
                </div>
            </div>
        <?php else: ?>
            <p class="hero-desc">This endpoint is intended for platform integrations and authorized services. Public browsing is not supported.</p>
        <?php endif; ?>

        <div class="links-bar">
            <a href="https://developer.airroofers.eu/" class="btn-link">Developer Portal</a>
            <a href="https://airroofers.eu/" class="btn-link">Platform Status</a>
        </div>
    </div>

    <div class="footer">
        © 2026 Air Roofers SASU. Platform Core Infrastructure.
    </div>
</body>
</html>
    <?php
    }

    /**
     * Render Standardized HTML Branded Error Appliance Card (404/403/500/405/429/503).
     */
    public static function renderErrorCard(string $serviceTitle, int $code, string $errorTitle, string $message): void
    {
        self::applySecurityHeaders();
        http_response_code($code);
        header('Content-Type: text/html; charset=utf-8');

        $logoUrl    = 'https://static.airroofers.eu/brands/mandatag/logo.png';
        $faviconUrl = 'https://static.airroofers.eu/brands/mandatag/favicon.ico';
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $code; ?> — Air Roofers Platform</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="shortcut icon" href="<?php echo $faviconUrl; ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #090d16;
            --card-bg: rgba(18, 26, 43, 0.75);
            --border: rgba(255, 255, 255, 0.1);
            --accent: #3b82f6;
            --warning: #f59e0b;
            --text-main: #f3f4f6;
            --text-muted: #9ca3af;
            --spacing-xs: 8px;
            --spacing-sm: 16px;
            --spacing-md: 24px;
            --spacing-lg: 32px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background-color: var(--bg);
            background-image: radial-gradient(circle at 50% 30%, rgba(245, 158, 11, 0.06) 0%, transparent 50%);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: var(--spacing-md) var(--spacing-sm);
        }

        .container {
            width: 100%;
            max-width: 540px;
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: var(--spacing-lg);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-bottom: var(--spacing-sm);
            border-bottom: 1px solid var(--border);
            margin-bottom: var(--spacing-md);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 0.85rem;
        }

        .brand-logo-img {
            width: 38px;
            height: 38px;
            border-radius: 8px;
            object-fit: contain;
            background: rgba(255, 255, 255, 0.05);
            padding: 4px;
            border: 1px solid var(--border);
        }

        .brand-title { font-size: 1.15rem; font-weight: 700; }
        .brand-sub { font-size: 0.78rem; color: var(--text-muted); font-weight: 500; }

        .badge-code {
            background: rgba(245, 158, 11, 0.15);
            border: 1px solid rgba(245, 158, 11, 0.3);
            color: var(--warning);
            padding: 0.35rem 0.85rem;
            border-radius: 9999px;
            font-size: 0.85rem;
            font-weight: 700;
        }

        .error-code-display {
            font-size: 3.5rem;
            font-weight: 800;
            color: var(--warning);
            line-height: 1;
            margin-bottom: var(--spacing-xs);
            letter-spacing: -0.04em;
        }

        .hero-title { font-size: 1.4rem; font-weight: 700; margin-bottom: var(--spacing-xs); }
        .hero-desc { color: var(--text-muted); font-size: 0.95rem; line-height: 1.5; margin-bottom: var(--spacing-md); }

        .links-bar { display: flex; gap: var(--spacing-sm); flex-wrap: wrap; }
        .btn-link {
            flex: 1; text-align: center; padding: 0.75rem var(--spacing-sm);
            background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border);
            border-radius: 10px; color: var(--text-main); text-decoration: none;
            font-size: 0.85rem; font-weight: 600; transition: all 0.2s ease;
        }
        .btn-link:hover { background: rgba(59, 130, 246, 0.15); border-color: var(--accent); color: white; }

        .footer { margin-top: var(--spacing-md); font-size: 0.8rem; color: var(--text-muted); text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="brand">
                <img src="<?php echo $logoUrl; ?>" alt="Air Roofers Mandatag" class="brand-logo-img">
                <div>
                    <div class="brand-title">Air Roofers</div>
                    <div class="brand-sub"><?php echo htmlspecialchars($serviceTitle); ?></div>
                </div>
            </div>
            <div class="badge-code">HTTP <?php echo $code; ?></div>
        </div>

        <div class="error-code-display"><?php echo $code; ?></div>
        <h1 class="hero-title"><?php echo htmlspecialchars($errorTitle); ?></h1>
        <p class="hero-desc"><?php echo htmlspecialchars($message); ?></p>

        <div class="links-bar">
            <a href="/" class="btn-link">Return Home</a>
            <a href="https://developer.airroofers.eu/" class="btn-link">Developer Portal</a>
        </div>
    </div>

    <div class="footer">
        © 2026 Air Roofers SASU. Platform Core Infrastructure.
    </div>
</body>
</html>
    <?php
    }
}
