<?php
namespace AirRoofers\PlatformCore\DTOs;

class ProductDTO {
    public string $product_id;
    public string $name;
    public string $slug;
    public string $category;
    public string $visibility;
    public string $lifecycle_stage;
    /** @var string[] */
    public array $editions;

    public function __construct(string $product_id, string $name, string $slug, string $category, string $visibility, string $lifecycle_stage, array $editions) {
        $this->product_id = $product_id;
        $this->name = $name;
        $this->slug = $slug;
        $this->category = $category;
        $this->visibility = $visibility;
        $this->lifecycle_stage = $lifecycle_stage;
        $this->editions = $editions;
    }
}
