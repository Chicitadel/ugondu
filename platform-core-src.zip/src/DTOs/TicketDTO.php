<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * TicketDTO
 * Data Transfer Object for Customer Support Ticket Operations
 */
final class TicketDTO
{
    public function __construct(
        public readonly ?string $ticketId,
        public readonly string $workspaceId,
        public readonly string $subject,
        public readonly string $description,
        public readonly string $category,
        public readonly string $priority,
        public readonly string $status,
        public readonly ?string $assignedAgentId = null,
        public readonly ?string $createdAt = null,
        public readonly ?string $updatedAt = null
    ) {}

    public function toArray(): array
    {
        return [
            'ticket_id'         => $this->ticketId,
            'workspace_id'      => $this->workspaceId,
            'subject'           => $this->subject,
            'description'       => $this->description,
            'category'          => $this->category,
            'priority'          => $this->priority,
            'status'            => $this->status,
            'assigned_agent_id' => $this->assignedAgentId,
            'created_at'        => $this->createdAt ?? date('c'),
            'updated_at'        => $this->updatedAt ?? date('c')
        ];
    }
}
