<?php
namespace AirRoofers\PlatformCore\DTOs;

class InvoiceDTO {
    public string $invoice_id;
    public string $organization_id;
    public string $subscription_id;
    public float $amount;
    public string $currency;
    public string $status;
    public string $issued_at;
    public ?string $paid_at;

    public function __construct(string $invoice_id, string $organization_id, string $subscription_id, float $amount, string $currency, string $status, string $issued_at, ?string $paid_at = null) {
        $this->invoice_id = $invoice_id;
        $this->organization_id = $organization_id;
        $this->subscription_id = $subscription_id;
        $this->amount = $amount;
        $this->currency = $currency;
        $this->status = $status;
        $this->issued_at = $issued_at;
        $this->paid_at = $paid_at;
    }
}
