<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * NotificationDTO
 * Data Transfer Object for Platform Notifications & Alerts
 */
final class NotificationDTO
{
    public function __construct(
        public readonly ?string $notificationId,
        public readonly string $userId,
        public readonly string $title,
        public readonly string $message,
        public readonly string $type,
        public readonly bool $isRead = false,
        public readonly ?string $createdAt = null
    ) {}

    public function toArray(): array
    {
        return [
            'notification_id' => $this->notificationId,
            'user_id'         => $this->userId,
            'title'           => $this->title,
            'message'         => $this->message,
            'type'            => $this->type,
            'is_read'         => $this->isRead,
            'created_at'      => $this->createdAt ?? date('c')
        ];
    }
}
