<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * NodeDTO
 * Data Transfer Object for Infrastructure Node Provisioning & Authority
 */
final class NodeDTO
{
    public function __construct(
        public readonly string $nodeId,
        public readonly string $hostname,
        public readonly string $region,
        public readonly string $role,
        public readonly string $status,
        public readonly ?string $ipAddress = null,
        public readonly ?string $provisionedAt = null
    ) {}

    public function toArray(): array
    {
        return [
            'node_id'        => $this->nodeId,
            'hostname'       => $this->hostname,
            'region'         => $this->region,
            'role'           => $this->role,
            'status'         => $this->status,
            'ip_address'     => $this->ipAddress,
            'provisioned_at' => $this->provisionedAt ?? date('c')
        ];
    }
}
