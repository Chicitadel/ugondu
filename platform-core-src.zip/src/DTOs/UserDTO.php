<?php
namespace AirRoofers\PlatformCore\DTOs;

class UserDTO {
    public string $user_id;
    public string $organization_id;
    public string $email;
    public string $role;
    public bool $mfa_enabled;

    public function __construct(string $user_id, string $organization_id, string $email, string $role, bool $mfa_enabled) {
        $this->user_id = $user_id;
        $this->organization_id = $organization_id;
        $this->email = $email;
        $this->role = $role;
        $this->mfa_enabled = $mfa_enabled;
    }
}
