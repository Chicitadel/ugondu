<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * EventDTO
 * Data Transfer Object for Ingestion & Telemetry Event Streams
 */
final class EventDTO
{
    public function __construct(
        public readonly string $eventId,
        public readonly string $eventType,
        public readonly string $sourceService,
        public readonly array $data,
        public readonly ?string $correlationId = null,
        public readonly ?string $timestamp = null
    ) {}

    public function toArray(): array
    {
        return [
            'event_id'       => $this->eventId,
            'event_type'     => $this->eventType,
            'source_service' => $this->sourceService,
            'data'           => $this->data,
            'correlation_id' => $this->correlationId,
            'timestamp'      => $this->timestamp ?? date('c')
        ];
    }
}
