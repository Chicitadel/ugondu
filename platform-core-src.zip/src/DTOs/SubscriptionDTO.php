<?php
namespace AirRoofers\PlatformCore\DTOs;

class SubscriptionDTO {
    public string $subscription_id;
    public string $organization_id;
    public string $plan_code;
    public string $status;
    public string $next_billing_date;
    public float $monthly_amount;
    public string $currency;

    public function __construct(string $subscription_id, string $organization_id, string $plan_code, string $status, string $next_billing_date, float $monthly_amount, string $currency) {
        $this->subscription_id = $subscription_id;
        $this->organization_id = $organization_id;
        $this->plan_code = $plan_code;
        $this->status = $status;
        $this->next_billing_date = $next_billing_date;
        $this->monthly_amount = $monthly_amount;
        $this->currency = $currency;
    }
}
