<?php
namespace AirRoofers\PlatformCore\DTOs;

class OrganizationDTO {
    public string $organization_id;
    public string $name;
    public string $status;

    public function __construct(string $organization_id, string $name, string $status) {
        $this->organization_id = $organization_id;
        $this->name = $name;
        $this->status = $status;
    }
}
