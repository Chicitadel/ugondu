<?php
namespace AirRoofers\PlatformCore\DTOs;

class LicenseDTO {
    public string $license_id;
    public string $organization_id;
    public string $product_slug;
    public string $edition;
    public string $status;
    public int $seats_allocated;
    public string $expires_at;

    public function __construct(string $license_id, string $organization_id, string $product_slug, string $edition, string $status, int $seats_allocated, string $expires_at) {
        $this->license_id = $license_id;
        $this->organization_id = $organization_id;
        $this->product_slug = $product_slug;
        $this->edition = $edition;
        $this->status = $status;
        $this->seats_allocated = $seats_allocated;
        $this->expires_at = $expires_at;
    }
}
