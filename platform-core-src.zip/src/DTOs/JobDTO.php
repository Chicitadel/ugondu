<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * JobDTO
 * Data Transfer Object for Async Workflow Orchestrator Jobs
 */
final class JobDTO
{
    public function __construct(
        public readonly ?string $jobId,
        public readonly string $jobType,
        public readonly array $payload,
        public readonly string $status,
        public readonly int $priority = 0,
        public readonly ?string $scheduledAt = null,
        public readonly ?string $completedAt = null
    ) {}

    public function toArray(): array
    {
        return [
            'job_id'       => $this->jobId,
            'job_type'     => $this->jobType,
            'payload'      => $this->payload,
            'status'       => $this->status,
            'priority'     => $this->priority,
            'scheduled_at' => $this->scheduledAt ?? date('c'),
            'completed_at' => $this->completedAt
        ];
    }
}
