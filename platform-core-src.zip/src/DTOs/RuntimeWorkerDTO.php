<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * RuntimeWorkerDTO
 * Data Transfer Object for Serverless Worker Cluster Instances
 */
final class RuntimeWorkerDTO
{
    public function __construct(
        public readonly string $workerId,
        public readonly string $clusterId,
        public readonly string $status,
        public readonly int $activeTasks,
        public readonly float $cpuUsagePercent,
        public readonly float $memoryUsageMb,
        public readonly ?string $lastHeartbeatAt = null
    ) {}

    public function toArray(): array
    {
        return [
            'worker_id'         => $this->workerId,
            'cluster_id'        => $this->clusterId,
            'status'            => $this->status,
            'active_tasks'      => $this->activeTasks,
            'cpu_usage_percent' => $this->cpuUsagePercent,
            'memory_usage_mb'   => $this->memoryUsageMb,
            'last_heartbeat_at' => $this->lastHeartbeatAt ?? date('c')
        ];
    }
}
