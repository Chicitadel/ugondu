<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * CertificationDTO
 * Data Transfer Object for EAORCS Platform Certification Records
 */
final class CertificationDTO
{
    public function __construct(
        public readonly string $auditId,
        public readonly float $overallReadinessScore,
        public readonly string $certificationDecision,
        public readonly int $totalStreamsCount,
        public readonly array $streamScores,
        public readonly ?string $certifiedAt = null
    ) {}

    public function toArray(): array
    {
        return [
            'audit_id'               => $this->auditId,
            'overall_readiness_score'=> $this->overallReadinessScore,
            'certification_decision' => $this->certificationDecision,
            'total_streams_count'    => $this->totalStreamsCount,
            'stream_scores'          => $this->streamScores,
            'certified_at'           => $this->certifiedAt ?? date('c')
        ];
    }
}
