<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\DTOs;

/**
 * AppCatalogDTO
 * Data Transfer Object for Marketplace Extension Catalog Items
 */
final class AppCatalogDTO
{
    public function __construct(
        public readonly string $appId,
        public readonly string $name,
        public readonly string $category,
        public readonly string $version,
        public readonly string $author,
        public readonly bool $isCertified,
        public readonly ?string $description = null
    ) {}

    public function toArray(): array
    {
        return [
            'app_id'       => $this->appId,
            'name'         => $this->name,
            'category'     => $this->category,
            'version'      => $this->version,
            'author'       => $this->author,
            'is_certified' => $this->isCertified,
            'description'  => $this->description
        ];
    }
}
