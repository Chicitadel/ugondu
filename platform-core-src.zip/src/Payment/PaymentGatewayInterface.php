<?php
namespace AirRoofers\PlatformCore\Payment;

interface PaymentGatewayInterface {
    public function createCharge(string $amount, string $currency, string $source, string $description): array;
    public function refundCharge(string $chargeId): array;
    public function getStatus(string $chargeId): string;
}
