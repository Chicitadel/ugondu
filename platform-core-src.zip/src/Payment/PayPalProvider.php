<?php
namespace AirRoofers\PlatformCore\Payment;

require_once __DIR__ . '/PaymentProviderInterface.php';

class PayPalProvider implements PaymentProviderInterface {
    private string $clientId;
    private string $clientSecret;

    public function __construct(string $clientId = '', string $clientSecret = '') {
        $this->clientId = $clientId ?: (getenv('PAYPAL_CLIENT_ID') ?: '');
        $this->clientSecret = $clientSecret ?: (getenv('PAYPAL_CLIENT_SECRET') ?: '');
    }

    public function getProviderName(): string {
        return 'paypal';
    }

    public function createCharge(string $amount, string $currency, string $source, string $description): array {
        $captureId = 'PAYID-' . strtoupper(bin2hex(random_bytes(8)));
        return [
            'id' => $captureId,
            'status' => 'COMPLETED',
            'amount' => $amount,
            'currency' => strtoupper($currency),
            'source' => $source,
            'description' => $description,
            'provider' => $this->getProviderName()
        ];
    }

    public function refundCharge(string $chargeId): array {
        $refundId = 'REFUND-' . strtoupper(bin2hex(random_bytes(8)));
        return [
            'id' => $refundId,
            'charge' => $chargeId,
            'status' => 'COMPLETED',
            'provider' => $this->getProviderName()
        ];
    }

    public function getStatus(string $chargeId): string {
        return 'COMPLETED';
    }
}
