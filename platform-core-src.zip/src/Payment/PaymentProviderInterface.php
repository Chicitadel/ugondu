<?php
namespace AirRoofers\PlatformCore\Payment;

interface PaymentProviderInterface {
    public function createCharge(string $amount, string $currency, string $source, string $description): array;
    public function refundCharge(string $chargeId): array;
    public function getStatus(string $chargeId): string;
    public function getProviderName(): string;
}
