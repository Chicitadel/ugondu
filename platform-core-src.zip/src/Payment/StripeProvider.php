<?php
namespace AirRoofers\PlatformCore\Payment;

require_once __DIR__ . '/PaymentProviderInterface.php';

class StripeProvider implements PaymentProviderInterface {
    private string $apiKey;

    public function __construct(string $apiKey = '') {
        $this->apiKey = $apiKey ?: (getenv('STRIPE_SECRET_KEY') ?: '');
    }

    public function getProviderName(): string {
        return 'stripe';
    }

    public function createCharge(string $amount, string $currency, string $source, string $description): array {
        $chargeId = 'ch_str_' . bin2hex(random_bytes(12));
        return [
            'id' => $chargeId,
            'status' => 'succeeded',
            'amount' => $amount,
            'currency' => strtolower($currency),
            'source' => $source,
            'description' => $description,
            'provider' => $this->getProviderName(),
            'livemode' => false
        ];
    }

    public function refundCharge(string $chargeId): array {
        $refundId = 're_str_' . bin2hex(random_bytes(12));
        return [
            'id' => $refundId,
            'charge' => $chargeId,
            'status' => 'succeeded',
            'provider' => $this->getProviderName()
        ];
    }

    public function getStatus(string $chargeId): string {
        return 'succeeded';
    }
}
