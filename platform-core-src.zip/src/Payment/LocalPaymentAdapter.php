<?php
namespace AirRoofers\PlatformCore\Payment;

require_once __DIR__ . '/PaymentGatewayInterface.php';
require_once __DIR__ . '/PaymentProviderInterface.php';
require_once __DIR__ . '/StripeProvider.php';
require_once __DIR__ . '/PayPalProvider.php';

class LocalPaymentAdapter implements PaymentGatewayInterface {
    private PaymentProviderInterface $provider;

    public function __construct(?PaymentProviderInterface $provider = null) {
        $this->provider = $provider ?? new StripeProvider();
    }

    public static function createWithProvider(string $providerName): self {
        switch (strtolower($providerName)) {
            case 'paypal':
                return new self(new PayPalProvider());
            case 'stripe':
            default:
                return new self(new StripeProvider());
        }
    }

    public function setProvider(PaymentProviderInterface $provider): void {
        $this->provider = $provider;
    }

    public function getProvider(): PaymentProviderInterface {
        return $this->provider;
    }

    public function createCharge(string $amount, string $currency, string $source, string $description): array {
        return $this->provider->createCharge($amount, $currency, $source, $description);
    }

    public function refundCharge(string $chargeId): array {
        return $this->provider->refundCharge($chargeId);
    }

    public function getStatus(string $chargeId): string {
        return $this->provider->getStatus($chargeId);
    }
}
