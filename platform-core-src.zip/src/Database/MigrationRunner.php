<?php
namespace AirRoofers\PlatformCore\Database;

class MigrationRunner {
    protected \PDO $db;

    public function __construct(string $dbPath) {
        $this->db = new \PDO("sqlite:" . $dbPath);
        $this->db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->init();
    }

    protected function init() {
        $this->db->exec("CREATE TABLE IF NOT EXISTS migrations (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, run_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
    }

    public function run(array $migrations) {
        foreach ($migrations as $name => $sql) {
            $stmt = $this->db->prepare("SELECT id FROM migrations WHERE name = ?");
            $stmt->execute([$name]);
            if (!$stmt->fetch()) {
                $this->db->exec($sql);
                $insert = $this->db->prepare("INSERT INTO migrations (name) VALUES (?)");
                $insert->execute([$name]);
                echo "Ran migration: $name\n";
            }
        }
    }
    
    public function getDb(): \PDO {
        return $this->db;
    }
}
