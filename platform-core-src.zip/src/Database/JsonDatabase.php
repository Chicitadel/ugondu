<?php
namespace AirRoofers\PlatformCore\Database;

class JsonDatabase {
    protected string $path;

    public function __construct(string $path) {
        $this->path = $path;
        if (!file_exists($this->path)) {
            file_put_contents($this->path, json_encode([]));
        }
    }

    public function read(): array {
        return json_decode(file_get_contents($this->path), true) ?: [];
    }

    public function write(array $data) {
        file_put_contents($this->path, json_encode($data, JSON_PRETTY_PRINT));
    }
}
