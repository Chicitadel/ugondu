<?php
namespace AirRoofers\PlatformCore\Repository;

use AirRoofers\PlatformCore\Storage\StorageInterface;

abstract class BaseRepository {
    protected StorageInterface $storage;
    protected string $table;

    public function __construct(StorageInterface $storage, string $table) {
        $this->storage = $storage;
        $this->table = $table;
    }

    public function findById(string $id): ?array {
        return $this->storage->find($this->table, $id);
    }

    public function findAll(array $criteria = []): array {
        return $this->storage->findAll($this->table, $criteria);
    }

    public function save(string $id, array $data): bool {
        if ($this->findById($id)) {
            return $this->storage->update($this->table, $id, $data);
        } else {
            return $this->storage->insert($this->table, $id, $data);
        }
    }

    public function delete(string $id): bool {
        return $this->storage->delete($this->table, $id);
    }
}
