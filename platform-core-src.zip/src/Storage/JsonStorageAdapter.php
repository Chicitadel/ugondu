<?php
namespace AirRoofers\PlatformCore\Storage;

class JsonStorageAdapter implements StorageInterface {
    protected string $path;

    public function __construct(string $path) {
        $this->path = $path;
        if (!file_exists($this->path)) {
            file_put_contents($this->path, json_encode([]));
        }
    }

    public function read(): array {
        return json_decode(file_get_contents($this->path), true) ?: [];
    }

    public function write(array $data) {
        file_put_contents($this->path, json_encode($data, JSON_PRETTY_PRINT));
    }

    public function find(string $table, string $id): ?array {
        $data = $this->read();
        return $data[$table][$id] ?? null;
    }

    public function findAll(string $table, array $criteria = []): array {
        $data = $this->read();
        $records = $data[$table] ?? [];
        if (empty($criteria)) return array_values($records);
        
        return array_values(array_filter($records, function($record) use ($criteria) {
            foreach ($criteria as $key => $val) {
                if (($record[$key] ?? null) !== $val) return false;
            }
            return true;
        }));
    }

    public function insert(string $table, string $id, array $record): bool {
        $data = $this->read();
        if (!isset($data[$table])) $data[$table] = [];
        if (isset($data[$table][$id])) return false; // already exists
        $data[$table][$id] = $record;
        $this->write($data);
        return true;
    }

    public function update(string $table, string $id, array $record): bool {
        $data = $this->read();
        if (!isset($data[$table][$id])) return false;
        $data[$table][$id] = array_merge($data[$table][$id], $record);
        $this->write($data);
        return true;
    }

    public function delete(string $table, string $id): bool {
        $data = $this->read();
        if (!isset($data[$table][$id])) return false;
        unset($data[$table][$id]);
        $this->write($data);
        return true;
    }
}
