<?php
namespace AirRoofers\PlatformCore\Storage;

require_once __DIR__ . '/BlobStorageInterface.php';

class LocalBlobAdapter implements BlobStorageInterface {
    protected string $basePath;
    protected string $baseUrl;

    public function __construct(string $basePath, string $baseUrl) {
        $this->basePath = rtrim($basePath, '/\\');
        $this->baseUrl = rtrim($baseUrl, '/');
        
        if (!is_dir($this->basePath)) {
            mkdir($this->basePath, 0777, true);
        }
    }

    public function get(string $path): ?string {
        $fullPath = $this->basePath . DIRECTORY_SEPARATOR . ltrim($path, '/\\');
        if (file_exists($fullPath)) {
            return file_get_contents($fullPath);
        }
        return null;
    }

    public function put(string $path, string $content): bool {
        $fullPath = $this->basePath . DIRECTORY_SEPARATOR . ltrim($path, '/\\');
        $dir = dirname($fullPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        return file_put_contents($fullPath, $content) !== false;
    }

    public function exists(string $path): bool {
        $fullPath = $this->basePath . DIRECTORY_SEPARATOR . ltrim($path, '/\\');
        return file_exists($fullPath);
    }

    public function getUrl(string $path): string {
        return $this->baseUrl . '/' . ltrim($path, '/');
    }
}
