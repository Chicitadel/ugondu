<?php
namespace AirRoofers\PlatformCore\Storage;

interface StorageInterface {
    public function find(string $table, string $id): ?array;
    public function findAll(string $table, array $criteria = []): array;
    public function insert(string $table, string $id, array $data): bool;
    public function update(string $table, string $id, array $data): bool;
    public function delete(string $table, string $id): bool;
}
