<?php
namespace AirRoofers\PlatformCore\Storage;

interface BlobStorageInterface {
    public function get(string $path): ?string;
    public function put(string $path, string $content): bool;
    public function exists(string $path): bool;
    public function getUrl(string $path): string;
}
