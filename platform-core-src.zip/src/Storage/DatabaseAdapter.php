<?php
namespace AirRoofers\PlatformCore\Storage;

use PDO;
use PDOException;

class DatabaseAdapter implements StorageInterface {
    protected ?PDO $pdo = null;
    protected string $storageDir;
    protected string $sqliteFile;

    public function __construct(?string $storageDir = null) {
        $this->storageDir = $storageDir ?? __DIR__ . '/../../storage';
        if (!is_dir($this->storageDir)) {
            @mkdir($this->storageDir, 0775, true);
        }
        $this->sqliteFile = $this->storageDir . '/platform_db.sqlite';
        $this->connect();
    }

    protected function connect() {
        $host = getenv('DB_HOST') ?: '127.0.0.1';
        $dbname = getenv('DB_NAME') ?: 'airroofers';
        $user = getenv('DB_USER') ?: 'root';
        $pass = getenv('DB_PASS') ?: '';

        try {
            if (getenv('DB_HOST')) {
                $dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";
                $this->pdo = new PDO($dsn, $user, $pass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]);
            } else {
                $dsn = "sqlite:{$this->sqliteFile}";
                $this->pdo = new PDO($dsn, null, null, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]);
            }
        } catch (PDOException $e) {
            // Resilient fallback to SQLite local file
            $dsn = "sqlite:{$this->sqliteFile}";
            $this->pdo = new PDO($dsn, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
        }
    }

    public function getPdo(): PDO {
        return $this->pdo;
    }

    public function find(string $table, string $id): ?array {
        try {
            $stmt = $this->pdo->prepare("SELECT payload FROM kv_store WHERE table_name = ? AND record_id = ? LIMIT 1");
            $stmt->execute([$table, $id]);
            $row = $stmt->fetch();
            if ($row && !empty($row['payload'])) {
                return json_decode($row['payload'], true) ?: null;
            }
        } catch (PDOException $e) {
            $this->ensureTable();
        }
        return null;
    }

    public function findAll(string $table, array $criteria = []): array {
        try {
            $stmt = $this->pdo->prepare("SELECT payload FROM kv_store WHERE table_name = ?");
            $stmt->execute([$table]);
            $rows = $stmt->fetchAll();
            $results = [];
            foreach ($rows as $row) {
                $item = json_decode($row['payload'], true);
                if ($item) {
                    $match = true;
                    foreach ($criteria as $k => $v) {
                        if (($item[$k] ?? null) !== $v) {
                            $match = false;
                            break;
                        }
                    }
                    if ($match) {
                        $results[] = $item;
                    }
                }
            }
            return $results;
        } catch (PDOException $e) {
            $this->ensureTable();
            return [];
        }
    }

    public function insert(string $table, string $id, array $data): bool {
        $this->ensureTable();
        $payload = json_encode($data, JSON_UNESCAPED_SLASHES);
        $stmt = $this->pdo->prepare("INSERT INTO kv_store (table_name, record_id, payload, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW()) ON CONFLICT(table_name, record_id) DO UPDATE SET payload = ?, updated_at = NOW()");
        return $stmt->execute([$table, $id, $payload, $payload]);
    }

    public function update(string $table, string $id, array $data): bool {
        $existing = $this->find($table, $id) ?? [];
        $merged = array_merge($existing, $data);
        return $this->insert($table, $id, $merged);
    }

    public function delete(string $table, string $id): bool {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM kv_store WHERE table_name = ? AND record_id = ?");
            return $stmt->execute([$table, $id]);
        } catch (PDOException $e) {
            return false;
        }
    }

    protected function ensureTable() {
        $sql = "CREATE TABLE IF NOT EXISTS kv_store (
            table_name VARCHAR(128) NOT NULL,
            record_id VARCHAR(128) NOT NULL,
            payload TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (table_name, record_id)
        );";
        $this->pdo->exec($sql);
    }
}
