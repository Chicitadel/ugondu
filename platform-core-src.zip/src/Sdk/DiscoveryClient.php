<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk;

/******************************************************************************
 * Project        : Platform Core
 * Module         : Discovery Service SDK
 * File           : DiscoveryClient.php
 * Version        : 1.0.0
 * Author         : Platform Core Engineering Team
 * Organization   : Air Roofers Platform Architecture Authority
 * Created Date   : 2026-07-24
 * Classification : ENTERPRISE | INTERNAL
 *
 * Governance:
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Copyright (c) 2026 Air Roofers Enterprise Operations
 * All Rights Reserved.
 ******************************************************************************/

use AirRoofers\PlatformCore\Sdk\Foundation\AbstractClient;

class DiscoveryClient extends AbstractClient
{
    public function getHealth(): array
    {
        return $this->request('GET', '/health');
    }

    public function listServices(?string $capability = null): array
    {
        $uri = '/v1/discovery/services';
        if ($capability !== null) {
            $uri .= '?capability=' . urlencode($capability);
        }
        return $this->request('GET', $uri);
    }

    public function getService(string $serviceId): array
    {
        return $this->request('GET', "/v1/discovery/services/{$serviceId}");
    }

    public function resolveCapability(string $capability): array
    {
        return $this->request('POST', '/v1/discovery/resolve', [
            'capability' => $capability,
        ]);
    }

    public function registerService(array $serviceManifest): array
    {
        return $this->request('POST', '/v1/discovery/register', $serviceManifest);
    }
}
