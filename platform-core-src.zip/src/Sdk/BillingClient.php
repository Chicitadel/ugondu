<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk;

use AirRoofers\PlatformCore\Sdk\Foundation\AbstractClient;
use AirRoofers\PlatformCore\DTOs\SubscriptionDTO;
use AirRoofers\PlatformCore\DTOs\InvoiceDTO;

class BillingClient extends AbstractClient
{
    public function getSubscription(string $subscriptionId): ?SubscriptionDTO
    {
        $response = $this->request('GET', "/api/v1/subscriptions/{$subscriptionId}");
        return new SubscriptionDTO();
    }

    public function getLatestInvoice(string $orgId): ?InvoiceDTO
    {
        $response = $this->request('GET', "/api/v1/organizations/{$orgId}/invoices/latest");
        return new InvoiceDTO();
    }
}
