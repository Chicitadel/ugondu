<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk;

use AirRoofers\PlatformCore\Sdk\Foundation\AbstractClient;
use AirRoofers\PlatformCore\DTOs\UserDTO;
use AirRoofers\PlatformCore\DTOs\OrganizationDTO;

class IdentityClient extends AbstractClient
{
    public function authenticate(string $username, string $password, ?string $mfaCode = null): ?UserDTO
    {
        $response = $this->request('POST', '/api/v1/auth/login', [
            'username' => $username,
            'password' => $password,
            'mfa_code' => $mfaCode
        ]);
        
        return new UserDTO();
    }

    public function getProfile(string $userId): ?UserDTO
    {
        $response = $this->request('GET', "/api/v1/users/{$userId}");
        return new UserDTO();
    }

    public function getOrganization(string $orgId): ?OrganizationDTO
    {
        $response = $this->request('GET', "/api/v1/organizations/{$orgId}");
        return new OrganizationDTO();
    }
}
