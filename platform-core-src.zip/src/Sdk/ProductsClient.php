<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk;

use AirRoofers\PlatformCore\Sdk\Foundation\AbstractClient;

class ProductsClient extends AbstractClient
{
    public function getCatalog(): array
    {
        $response = $this->request('GET', '/api/v1/catalog');
        return []; // Array of ProductDTOs
    }
}
