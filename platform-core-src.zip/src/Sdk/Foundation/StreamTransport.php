<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

use AirRoofers\PlatformCore\Error\PlatformError;

class StreamTransport implements TransportInterface
{
    private int $timeout;

    public function __construct(int $timeout = 10)
    {
        $this->timeout = $timeout;
    }

    public function execute(string $method, string $url, array $headers = [], ?array $payload = null): array
    {
        $headerStrings = [];
        foreach ($headers as $k => $v) {
            $headerStrings[] = "$k: $v";
        }
        
        $options = [
            'http' => [
                'method' => strtoupper($method),
                'header' => implode("\r\n", $headerStrings),
                'timeout' => $this->timeout,
                'ignore_errors' => true // Fetch content even on 4xx/5xx errors
            ]
        ];

        if ($payload !== null) {
            if (!isset($headers['Content-Type'])) {
                $options['http']['header'] .= "\r\nContent-Type: application/json";
            }
            $options['http']['content'] = json_encode($payload);
        }

        $context = stream_context_create($options);
        
        $response = @file_get_contents($url, false, $context);
        
        if ($response === false) {
            throw new PlatformError('503', "Network Error executing StreamTransport", 'NETWORK_ERROR');
        }

        // Parse status code from $http_response_header
        $statusCode = 200;
        if (isset($http_response_header[0])) {
            preg_match('#HTTP/\d+\.\d+ (\d+)#', $http_response_header[0], $matches);
            if (isset($matches[1])) {
                $statusCode = (int)$matches[1];
            }
        }

        return [
            'status' => $statusCode,
            'body' => $response
        ];
    }
}
