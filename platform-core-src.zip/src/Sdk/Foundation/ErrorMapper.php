<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

use AirRoofers\PlatformCore\Error\PlatformError;

class ErrorMapper
{
    public static function map(int $statusCode, string $body): void
    {
        if ($statusCode >= 200 && $statusCode < 300) {
            return; // Success
        }

        $message = "HTTP Error {$statusCode}: {$body}";
        
        throw match (true) {
            $statusCode === 401 => new PlatformError("Unauthorized: " . $message, 401),
            $statusCode === 403 => new PlatformError("Forbidden: " . $message, 403),
            $statusCode === 404 => new PlatformError("Not Found: " . $message, 404),
            $statusCode === 429 => new PlatformError("Rate Limit Exceeded: " . $message, 429),
            $statusCode >= 500 => new PlatformError("Server Error: " . $message, $statusCode),
            default => new PlatformError("API Request Failed: " . $message, $statusCode),
        };
    }
}
