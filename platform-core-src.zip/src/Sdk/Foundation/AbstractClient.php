<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

use Psr\Log\LoggerInterface;

abstract class AbstractClient
{
    protected string $baseUrl;
    protected string $apiKey;
    protected TransportInterface $transport;
    protected RetryPolicy $retryPolicy;
    protected CircuitBreaker $circuitBreaker;
    protected ?LoggerInterface $logger;

    public function __construct(
        string $baseUrl,
        string $apiKey,
        int $timeout = 10,
        int $retries = 3,
        ?LoggerInterface $logger = null
    ) {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->apiKey = $apiKey;
        $this->logger = $logger;
        
        $this->transport = new StreamTransport($timeout, $logger);
        $this->retryPolicy = new RetryPolicy($retries, 200, $logger);
        $this->circuitBreaker = new CircuitBreaker(5, 30, $logger);
    }

    protected function request(string $method, string $endpoint, array $payload = [], array $headers = []): array
    {
        $url = $this->baseUrl . $endpoint;
        
        // Setup Headers
        $headers['Authorization'] = 'Bearer ' . $this->apiKey;
        $headers['Accept'] = 'application/json';
        $headers = TelemetryDecorator::inject($headers);

        $action = function() use ($method, $url, $headers, $payload) {
            $response = $this->transport->execute($method, $url, $headers, empty($payload) ? null : $payload);
            
            // Map HTTP errors to PlatformErrors
            ErrorMapper::map($response['status'], (string)$response['body']);
            
            $decoded = json_decode((string)$response['body'], true);
            if (json_last_error() !== JSON_ERROR_NONE && $response['status'] !== 204) {
                // If the response is not valid JSON and we didn't expect empty
                $this->logger?->warning("Invalid JSON response from $url", ['body' => $response['body']]);
                return []; 
            }
            return $decoded ?? [];
        };

        return $this->circuitBreaker->execute(function() use ($action) {
            return $this->retryPolicy->execute($action);
        });
    }
}
