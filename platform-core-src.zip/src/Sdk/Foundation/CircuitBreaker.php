<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

use AirRoofers\PlatformCore\Error\PlatformError;
use Psr\Log\LoggerInterface;

class CircuitBreaker
{
    private int $failureCount = 0;
    private int $failureThreshold;
    private int $resetTimeout;
    private ?int $lastFailureTime = null;
    private string $state = 'CLOSED'; // CLOSED, OPEN, HALF_OPEN
    private ?LoggerInterface $logger;

    public function __construct(int $failureThreshold = 5, int $resetTimeout = 30, ?LoggerInterface $logger = null)
    {
        $this->failureThreshold = $failureThreshold;
        $this->resetTimeout = $resetTimeout;
        $this->logger = $logger;
    }

    public function execute(callable $action): mixed
    {
        if ($this->state === 'OPEN') {
            if (time() - $this->lastFailureTime > $this->resetTimeout) {
                $this->state = 'HALF_OPEN';
                $this->logger?->info("CircuitBreaker: Transitioning to HALF_OPEN");
            } else {
                throw new PlatformError("CircuitBreaker is OPEN. Request blocked to prevent cascading failure.");
            }
        }

        try {
            $result = $action();
            
            if ($this->state === 'HALF_OPEN') {
                $this->state = 'CLOSED';
                $this->failureCount = 0;
                $this->logger?->info("CircuitBreaker: Transitioning to CLOSED");
            }
            
            return $result;
        } catch (\Throwable $e) {
            $this->failureCount++;
            $this->lastFailureTime = time();
            
            if ($this->failureCount >= $this->failureThreshold) {
                $this->state = 'OPEN';
                $this->logger?->error("CircuitBreaker: Threshold reached. Transitioning to OPEN");
            }
            
            throw $e;
        }
    }
}
