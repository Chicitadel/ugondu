<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

class TelemetryDecorator
{
    public static function inject(array $headers, ?string $correlationId = null): array
    {
        $requestId = bin2hex(random_bytes(16));
        
        $correlationId = $correlationId ?? $_SERVER['HTTP_X_CORRELATION_ID'] ?? $requestId;

        $headers['X-Request-ID'] = $requestId;
        $headers['X-Correlation-ID'] = $correlationId;
        $headers['User-Agent'] = 'AirRoofers-Platform-Sdk/1.0';

        return $headers;
    }
}
