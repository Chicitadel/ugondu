<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

use AirRoofers\PlatformCore\Error\PlatformError;
use Psr\Log\LoggerInterface;

class CurlTransport implements TransportInterface
{
    private ?LoggerInterface $logger;
    private int $timeout;

    public function __construct(int $timeout = 10, ?LoggerInterface $logger = null)
    {
        $this->timeout = $timeout;
        $this->logger = $logger;
    }

    public function execute(string $method, string $url, array $headers = [], ?array $payload = null): array
    {
        $ch = curl_init();
        
        $curlHeaders = [];
        foreach ($headers as $k => $v) {
            $curlHeaders[] = "$k: $v";
        }
        
        if ($payload !== null && !isset($headers['Content-Type'])) {
            $curlHeaders[] = 'Content-Type: application/json';
            $payloadStr = json_encode($payload);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payloadStr);
        }

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $curlHeaders,
            CURLOPT_TIMEOUT => $this->timeout,
        ]);

        $this->logger?->debug("CurlTransport: Executing $method $url");
        $start = microtime(true);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $duration = microtime(true) - $start;

        if ($response === false) {
            $this->logger?->error("CurlTransport: cURL Error on $method $url: $error");
            throw new PlatformError("Network Error: " . $error);
        }

        $this->logger?->debug("CurlTransport: Completed $method $url in {$duration}s with status $statusCode");

        return [
            'status' => $statusCode,
            'body' => $response
        ];
    }
}
