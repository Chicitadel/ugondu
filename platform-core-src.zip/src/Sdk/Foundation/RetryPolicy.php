<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

use Psr\Log\LoggerInterface;
use Throwable;

class RetryPolicy
{
    public function __construct(
        private int $maxAttempts = 3,
        private int $baseDelayMs = 200,
        private ?LoggerInterface $logger = null
    ) {}

    public function execute(callable $action): mixed
    {
        $attempts = 0;
        
        while (true) {
            try {
                $attempts++;
                return $action();
            } catch (Throwable $e) {
                if ($attempts >= $this->maxAttempts) {
                    $this->logger?->error("RetryPolicy: Max attempts ($this->maxAttempts) reached. Failing.");
                    throw $e;
                }
                
                // Exponential backoff
                $delay = $this->baseDelayMs * (2 ** ($attempts - 1));
                $this->logger?->warning("RetryPolicy: Action failed. Retrying in {$delay}ms. Attempt $attempts of {$this->maxAttempts}", ['error' => $e->getMessage()]);
                
                usleep($delay * 1000);
            }
        }
    }
}
