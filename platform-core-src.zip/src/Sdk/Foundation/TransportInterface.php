<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk\Foundation;

interface TransportInterface
{
    /**
     * Executes an HTTP request.
     * 
     * @param string $method GET, POST, PUT, DELETE, etc.
     * @param string $url The full absolute URL
     * @param array $headers Associative array of headers
     * @param array|null $payload Optional JSON payload
     * @return array Returns ['status' => int, 'body' => string]
     * @throws \AirRoofers\PlatformCore\Error\PlatformError On network failure
     */
    public function execute(string $method, string $url, array $headers = [], ?array $payload = null): array;
}
