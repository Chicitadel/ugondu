<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk;

use AirRoofers\PlatformCore\Sdk\Foundation\AbstractClient;
use AirRoofers\PlatformCore\DTOs\LicenseDTO;

class LicenseClient extends AbstractClient
{
    public function getLicense(string $licenseId): ?LicenseDTO
    {
        $response = $this->request('GET', "/api/v1/licenses/{$licenseId}");
        return new LicenseDTO();
    }

    public function verifyEntitlement(string $orgId, string $productId): bool
    {
        $response = $this->request('GET', "/api/v1/organizations/{$orgId}/entitlements/{$productId}");
        return isset($response['entitled']) && $response['entitled'] === true;
    }
}
