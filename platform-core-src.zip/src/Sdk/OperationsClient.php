<?php
declare(strict_types=1);

namespace AirRoofers\PlatformCore\Sdk;

use AirRoofers\PlatformCore\Sdk\Foundation\AbstractClient;

class OperationsClient extends AbstractClient
{
    public function reportHealth(string $service, string $status): void
    {
        $this->request('POST', '/api/v1/telemetry/health', ['service' => $service, 'status' => $status]);
    }

    public function registerPlatform(string $platformId): void
    {
        $this->request('POST', '/api/v1/platforms/register', ['platform_id' => $platformId]);
    }
}
