<?php
namespace AirRoofers\PlatformCore\Engine;

interface EngineInterface {
    /**
     * Evaluate context against rules to determine outcome
     */
    public function evaluate(array $context): bool;

    /**
     * Execute the engine's primary capability based on context
     */
    public function execute(array $context): array;

    /**
     * Validate the context to ensure all required parameters are present
     */
    public function validate(array $context): bool;

    /**
     * Provide a structured explanation of the last decision
     */
    public function explain(): array;

    /**
     * Return the version of the engine ruleset currently active
     */
    public function version(): string;

    /**
     * Return metadata about the engine (owner, descriptive name, etc)
     */
    public function metadata(): array;

    /**
     * Return list of capabilities this engine supports
     */
    public function capabilities(): array;

    /**
     * Return diagnostic information for the engine
     */
    public function diagnostics(): array;
}
