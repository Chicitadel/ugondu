<?php
namespace AirRoofers\PlatformCore\Governance;

class DataClassification {
    public const PUBLIC = 'PUBLIC';
    public const INTERNAL = 'INTERNAL';
    public const CONFIDENTIAL = 'CONFIDENTIAL';
    public const RESTRICTED = 'RESTRICTED';
    public const SECRET = 'SECRET';

    public static function getValidClassifications(): array {
        return [
            self::PUBLIC,
            self::INTERNAL,
            self::CONFIDENTIAL,
            self::RESTRICTED,
            self::SECRET
        ];
    }
}
