<?php
namespace AirRoofers\PlatformCore\Governance;

class CapabilityType {
    public const PLATFORM_INFRASTRUCTURE = 'PLATFORM_INFRASTRUCTURE';
    public const BUSINESS_CAPABILITY = 'BUSINESS_CAPABILITY';
    public const EXPERIENCE_APPLICATION = 'EXPERIENCE_APPLICATION';

    public static function getValidTypes(): array {
        return [
            self::PLATFORM_INFRASTRUCTURE,
            self::BUSINESS_CAPABILITY,
            self::EXPERIENCE_APPLICATION
        ];
    }
}
