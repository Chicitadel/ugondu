<?php
namespace AirRoofers\PlatformCore\Governance;

class LifecycleStatus {
    public const DRAFT = 'Draft';
    public const PENDING = 'Pending';
    public const APPROVED = 'Approved';
    public const ACTIVE = 'Active';
    public const ARCHIVED = 'Archived';
    public const DELETED = 'Deleted';

    public static function getValidStatuses(): array {
        return [
            self::DRAFT,
            self::PENDING,
            self::APPROVED,
            self::ACTIVE,
            self::ARCHIVED,
            self::DELETED
        ];
    }
}
