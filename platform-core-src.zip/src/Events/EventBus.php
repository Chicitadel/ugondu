<?php
namespace AirRoofers\PlatformCore\Events;

class EventBus {
    protected static array $subscribers = [];
    protected static string $logPath = __DIR__ . '/../../storage/events.log';

    public static function subscribe(string $eventType, callable $handler): void {
        self::$subscribers[$eventType][] = $handler;
    }

    public static function dispatch(string $source, string $type, array $data): CloudEventEnvelope {
        $id = 'evt_' . bin2hex(random_bytes(8));
        $time = date('c');
        $event = new CloudEventEnvelope($id, $source, $type, $time, $data);

        // Persist to local event log stream
        $logDir = dirname(self::$logPath);
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0775, true);
        }
        @file_put_contents(self::$logPath, json_encode($event) . PHP_EOL, FILE_APPEND);

        // Notify subscribers
        if (isset(self::$subscribers[$type])) {
            foreach (self::$subscribers[$type] as $handler) {
                try {
                    call_user_func($handler, $event);
                } catch (\Throwable $e) {
                    error_log("[EventBus] Subscriber exception for {$type}: " . $e->getMessage());
                }
            }
        }

        return $event;
    }
}
