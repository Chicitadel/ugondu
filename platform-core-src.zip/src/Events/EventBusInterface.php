<?php
namespace AirRoofers\PlatformCore\Events;

interface EventBusInterface {
    public function publish(string $eventName, array $payload): void;
    public function subscribe(string $eventName, callable $handler): void;
    public function dispatch(): void;
}
