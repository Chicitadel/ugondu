<?php
namespace AirRoofers\PlatformCore\Events;

class CloudEventEnvelope {
    public string $specversion = "1.0";
    public string $id;
    public string $source;
    public string $type;
    public string $datacontenttype = "application/json";
    public string $time;
    public array $data;

    public function __construct(string $id, string $source, string $type, string $time, array $data) {
        $this->id = $id;
        $this->source = $source;
        $this->type = $type;
        $this->time = $time;
        $this->data = $data;
    }
}
