<?php
namespace AirRoofers\PlatformCore\Events;

require_once __DIR__ . '/EventBusInterface.php';

class LocalEventBusAdapter implements EventBusInterface {
    protected array $listeners = [];
    protected array $queue = [];

    public function publish(string $eventName, array $payload): void {
        $this->queue[] = ['event' => $eventName, 'payload' => $payload];
    }

    public function subscribe(string $eventName, callable $handler): void {
        if (!isset($this->listeners[$eventName])) {
            $this->listeners[$eventName] = [];
        }
        $this->listeners[$eventName][] = $handler;
    }

    public function dispatch(): void {
        while (!empty($this->queue)) {
            $current = array_shift($this->queue);
            $eventName = $current['event'];
            $payload = $current['payload'];

            if (isset($this->listeners[$eventName])) {
                foreach ($this->listeners[$eventName] as $handler) {
                    call_user_func($handler, $payload);
                }
            }
        }
    }
}
