/**
 * Mandatag
 * Auth UI Runtime (Unauthenticated Scope)
 *
 * Location: /public_htmlhttps://static.airroofers.eu/global/js/auth-runtime.js
 *
 * Purpose:
 * - Handles login UI interactions
 * - Password toggle
 * - Caps lock detection
 * - Zero dependency on admin runtime
 *
 * PATCH LEVEL: Phase 70 – Auth Runtime Isolation
 *
 * Guarantees:
 * - Zero regression
 * - No admin module leakage
 * - Lightweight + deterministic
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtAuthInitialized) return;

Object.defineProperty(window, "__mtAuthInitialized", {
    value: true,
    writable: false
});

/* =========================================================
   PASSWORD TOGGLE
========================================================= */

document.addEventListener("click", function(e){

    const btn = e.target.closest(".pw-toggle");
    if (!btn) return;

    const targetId = btn.dataset.target;
    const input = document.getElementById(targetId);

    if (!input) return;

    const isPassword = input.type === "password";

    input.type = isPassword ? "text" : "password";

    btn.setAttribute("aria-pressed", isPassword ? "true" : "false");

});

/* =========================================================
   CAPS LOCK DETECTION
========================================================= */

document.addEventListener("keyup", function(e){

    const input = e.target;

    if (!input || input.name !== "password") return;

    const warning = document.getElementById("capsWarning");

    if (!warning) return;

    if (e.getModifierState && e.getModifierState("CapsLock")) {
        warning.textContent = "Caps Lock is ON";
        warning.style.color = "#dc2626";
    } else {
        warning.textContent = "";
    }

});

/* =========================================================
   DEBUG
========================================================= */

console.debug("[MT AUTH] Runtime initialized");

})();