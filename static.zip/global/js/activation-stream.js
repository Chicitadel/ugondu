/**
 * Mandatag
 * Activation Stream Client (WebSocket + SSE Fallback)
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * Purpose:
 * - Real-time activation monitoring
 * - WebSocket primary transport
 * - SSE fallback (non-breaking)
 * - Auth-aware session handling
 * - UI-safe rendering
 *
 * PATCH LEVEL: Phase 35 – Transport Resilience + UI Integrity
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - WebSocket-first architecture preserved
 * - SSE fallback added (non-intrusive)
 * - Production safe
 */

(function(){
"use strict";

/* ============================================================
   MT-PATCH-STREAM-HARD-DISABLE-001
   Global transport kill-switch (authoritative)
============================================================ */

if (window.__MT_DISABLE_TRANSPORT__ === true) {
    console.debug("[Mandatag] Transport globally disabled → stream aborted");
    return;
}

/* ============================================================
   GLOBAL STREAM CONFLICT GUARD (PHASE 36)
============================================================ */

/*
|--------------------------------------------------------------------------
| Prevent multiple competing stream systems
|--------------------------------------------------------------------------
| If another stream system already exists → do not initialize
|--------------------------------------------------------------------------
*/

if (window.__mtActivationStreamActive) {
    console.debug("[Mandatag] Stream already active → aborting duplicate instance");
    return;
}

window.__mtActivationStreamActive = true;

/* ============================================================
   DOM CONTRACT RESOLUTION (MANDATAG SAFE MODE)
============================================================ */

const feed =
    document.querySelector('[data-mt-stream="activation"]') ||
    document.getElementById('activationFeed') ||
    document.getElementById('live-activations');

/*
|--------------------------------------------------------------------------
| HARD CONTRACT GUARD
|--------------------------------------------------------------------------
| Prevents JS crash on pages without stream UI
| Ensures cross-page compatibility
|--------------------------------------------------------------------------
*/

if (!feed) {
    console.warn("[Mandatag] activationFeed not found → stream disabled on this page");
    return;
}

/*
|--------------------------------------------------------------------------
| REAL METRIC ENGINE (WINDOWED)
|--------------------------------------------------------------------------
| Prevent fake activation spikes caused by:
| - reconnect replay
| - SSE resume bursts
| - startup math inflation
|--------------------------------------------------------------------------
*/

let anomalies = 0;

/*
|--------------------------------------------------------------------------
| Rolling activation timestamps
|--------------------------------------------------------------------------
*/

const activationWindow = [];

/*
|--------------------------------------------------------------------------
| Rate window = 60 seconds
|--------------------------------------------------------------------------
*/

const RATE_WINDOW_MS = 60000;

/*
|--------------------------------------------------------------------------
| HARD WINDOW CAP
|--------------------------------------------------------------------------
| Prevent pathological memory growth
|--------------------------------------------------------------------------
*/

const MAX_WINDOW_EVENTS = 5000;

let connectionAttempts = 0;
let wsInstance = null;
let reconnectTimer = null;

let wsStopped = false;          // 🔒 HARD STOP FLAG
let sseStopped = false;         // 🔒 HARD STOP FLAG
let transportStopped = false;   // 🔒 MASTER SWITCH

/* 🔒 GLOBAL COOLDOWN (CRITICAL FIX) */
let transportCooldown = false;
let transportCooldownTimer = null;

let sseRetries = 0;             // 🔒 PERSISTENT (NOT INSIDE FUNCTION)
let sseReconnectTimer = null;   // 🔒 track timer

const MAX_RETRY = 8;            // 🔒 controlled retry limit // 🔥 NEVER STOP
const BASE_DELAY = 2000;
const MAX_DELAY = 15000;
const MAX_RENDER_QUEUE = 500;

/* ============================================================
   UI HELPERS
============================================================ */

function updateMetrics(){

    const now = Date.now();

    /*
    |--------------------------------------------------------------------------
    | Keep only last 60s events
    |--------------------------------------------------------------------------
    */

    while (
        activationWindow.length &&
        activationWindow[0] < (now - RATE_WINDOW_MS)
    ) {
        activationWindow.shift();
    }

    const rate = document.getElementById("metric-rate");
    const anomaly = document.getElementById("metric-anomalies");

    /*
    |--------------------------------------------------------------------------
    | True rolling per-minute rate
    |--------------------------------------------------------------------------
    */

    if (rate) {
        rate.innerText = String(activationWindow.length);
    }

    if (anomaly) {
        anomaly.innerText = String(anomalies);
    }
}

const renderQueue = [];

let renderScheduled = false;
let renderFrameId = null;

const MAX_VISIBLE_EVENTS = 150;

function renderEvent(data, risk){

    /*
    |--------------------------------------------------------------------------
    | Skip rendering in hidden tabs
    |--------------------------------------------------------------------------
    */

    if (document.visibilityState !== "visible") {
        return;
    }

    if (renderQueue.length >= MAX_RENDER_QUEUE) {
        renderQueue.shift();
    }

    renderQueue.push({
        data,
        risk
    });

    scheduleRender();
}

function scheduleRender(){

    if (renderScheduled) {
        return;
    }

    renderScheduled = true;

    renderFrameId =
        requestAnimationFrame(
            flushRenderQueue
        );
}

function flushRenderQueue(){

    renderScheduled = false;
    renderFrameId = null;

    if (!renderQueue.length) {
        return;
    }

    const fragment = document.createDocumentFragment();

    /*
    |--------------------------------------------------------------------------
    | Preserve scroll behavior
    |--------------------------------------------------------------------------
    */

    const nearBottom =
        (feed.scrollHeight - feed.scrollTop - feed.clientHeight) < 80;

    const queue =
        renderQueue.splice(
            0,
            50
        );

    for (const item of queue) {

        const row = buildRow(
            item.data,
            item.risk
        );

        fragment.appendChild(row);
    }

    /*
    |--------------------------------------------------------------------------
    | APPEND (NOT PREPEND)
    |--------------------------------------------------------------------------
    */

    feed.appendChild(fragment);

    /*
    |--------------------------------------------------------------------------
    | HARD DOM CAP
    |--------------------------------------------------------------------------
    */

    while (feed.children.length > MAX_VISIBLE_EVENTS) {

        feed.removeChild(
            feed.firstElementChild
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Auto-scroll only if user near bottom
    |--------------------------------------------------------------------------
    */

    if (nearBottom) {

        feed.scrollTop = feed.scrollHeight;
    }

    /*
    |--------------------------------------------------------------------------
    | Continue draining queue safely
    |--------------------------------------------------------------------------
    */

    if (renderQueue.length > 0) {
        scheduleRender();
    }
}

function sanitizeStreamPayload(data){

    /*
    |--------------------------------------------------------------------------
    | HARD OBJECT VALIDATION
    |--------------------------------------------------------------------------
    */

    if (
        !data ||
        typeof data !== "object" ||
        Array.isArray(data)
    ) {
        data = {};
    }

    /*
    |--------------------------------------------------------------------------
    | SAFE SCORE NORMALIZATION
    |--------------------------------------------------------------------------
    */

    let safeScore = Number(data.score);

    if (!Number.isFinite(safeScore)) {
        safeScore = 0;
    }

    safeScore =
        Math.max(
            0,
            Math.min(999999, safeScore)
        );

    return {

        license_id:
            String(data.license_id || "UNKNOWN")
                .replace(/[\r\n\t]/g, "")
                .slice(0, 120),

        install_id:
            String(data.install_id || "-")
                .replace(/[\r\n\t]/g, "")
                .slice(0, 120),

        score: safeScore
    };
}

const ALLOWED_RISKS = Object.freeze({
    low: true,
    medium: true,
    high: true,
    critical: true
});

function normalizeRisk(risk){

    const normalized =
        String(risk || "")
            .toLowerCase()
            .trim();

    return ALLOWED_RISKS[normalized]
        ? normalized
        : "low";
}

function buildRow(data, risk){

    const row = document.createElement("div");

    const safeRisk = normalizeRisk(risk);

    row.className =
        "mt-stream-row risk-" + safeRisk;

    const licenseId =
        String(data.license_id || "UNKNOWN");

    const installId =
        String(data.install_id || "-");

    const score =
        Number(data.score || 0);

    const timestamp =
        new Date().toLocaleTimeString();

    /*
    |--------------------------------------------------------------------------
    | BUILD SAFELY (NO innerHTML)
    |--------------------------------------------------------------------------
    */

    const main =
        document.createElement("div");

    main.className = "mt-stream-main";

    const riskPill =
        createSpan(
            "mt-risk-pill",
            safeRisk.toUpperCase()
        );

    const license =
        createSpan(
            "mt-license",
            licenseId
        );

    const install =
        createSpan(
            "mt-install",
            installId
        );

    const scoreNode =
        createSpan(
            "mt-score",
            "score " + score
        );

    const time =
        createSpan(
            "mt-time",
            timestamp
        );

    main.append(
        riskPill,
        license,
        install,
        scoreNode,
        time
    );

    row.appendChild(main);

    return row;
}

function createSpan(className, text){

    const span = document.createElement("span");

    span.className = className;

    span.textContent = String(text || "");

    return span;
}

/* ============================================================
   EVENT HANDLER
============================================================ */

function handlePayload(payload){

    if (!payload) return;

    /*
    |--------------------------------------------------------------------------
    | ADMIN INVALIDATION EVENT
    |--------------------------------------------------------------------------
    */

    if (payload.event === "admin.invalidate") {

        const targetAdminId = payload.admin_id;

        if (
            typeof window.CURRENT_ADMIN_ID !== "undefined" &&
            Number(window.CURRENT_ADMIN_ID) === Number(targetAdminId)
        ) {
            window.location.href = "/admin/login?forced=1";
            return;
        }

        return;
    }

    /*
    |--------------------------------------------------------------------------
    | NOTIFICATION EVENT
    |--------------------------------------------------------------------------
    */

    if (payload.event === "notification") {

        if (
            window.mtNotificationRuntime &&
            typeof window.mtNotificationRuntime.add === "function"
        ) {

            window.mtNotificationRuntime.add(
                payload.data?.payload || {}
            );
        }

        return;
    }

    /*
    |--------------------------------------------------------------------------
    | ACTIVATION EVENT
    |--------------------------------------------------------------------------
    */

    if (payload.event !== "activation") {
        return;
    }

    const rawData = payload.data?.payload || payload.data || {};
    const data = sanitizeStreamPayload(rawData);
    const risk = payload.data?.risk ?? "low";

    activationWindow.push(Date.now());

    /*
    |--------------------------------------------------------------------------
    | HARD SAFETY CAP
    |--------------------------------------------------------------------------
    */

    if (activationWindow.length > MAX_WINDOW_EVENTS) {
        activationWindow.shift();
    }

    if (risk !== "low") {
        anomalies++;
    }

    updateMetrics();
    renderEvent(data, risk);
}

/* ============================================================
   WEBSOCKET PRIMARY
============================================================ */

function connectWebSocket(){

    if (transportStopped || wsStopped || transportCooldown) {
        return;
    }

    if (wsInstance && wsInstance.readyState === WebSocket.OPEN) {
        return; // 🔒 already connected
    }

    if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
    }

    try {

        if (window.__MT_DISABLE_WS__ === true) {
            return;
        }

        if (wsInstance) {

            try {
                wsInstance.close();
            } catch(e){}

            wsInstance = null;
        }

        wsInstance = new WebSocket("wss://" + location.hostname + ":8443");

        wsInstance.onopen = function(){
            connectionAttempts = 0;
            console.log("[Mandatag] WebSocket connected");
        };

        wsInstance.onmessage = function(e){
            try {
                const payload = JSON.parse(e.data);
                handlePayload(payload);
            } catch(err){
                console.warn("[Mandatag] Invalid WS payload", err);
            }
        };

        wsInstance.onerror = function(){
            console.warn("[Mandatag] WebSocket error");
        };

        wsInstance.onclose = function(){

            console.warn("[Mandatag] WebSocket closed");

            const delay = Math.min(
                BASE_DELAY * Math.pow(2, connectionAttempts),
                MAX_DELAY
            );

            connectionAttempts++;

            if (connectionAttempts > MAX_RETRY) {

                console.warn("[Mandatag] WS retry limit reached → switching to SSE only");

                wsStopped = true;

                /* 🔒 GLOBAL COOLDOWN ACTIVATION */
                transportCooldown = true;

                if (transportCooldownTimer) {
                    clearTimeout(transportCooldownTimer);
                }

                if (renderFrameId) {
                    cancelAnimationFrame(renderFrameId);
                }

                transportCooldownTimer = setTimeout(()=>{
                    transportCooldown = false;
                    console.log("[Mandatag] Transport cooldown released");
                }, 30000); // 30s hard cooldown

                /* 🔒 CLEAR TIMERS */
                if (reconnectTimer) {
                    clearTimeout(reconnectTimer);
                    reconnectTimer = null;
                }

                /* 🔁 SWITCH TO SSE */
                if (!transportStopped && (!sseInstance || sseInstance.readyState !== 1)) {
                    connectSSE();
                }

                return;
            }

            reconnectTimer = setTimeout(() => {
                connectWebSocket();
            }, delay);

        };

    } catch (e) {
        console.warn("[Mandatag] WS init failed → fallback to SSE");
        connectSSE();
    }
}

/* ============================================================
   SSE FALLBACK (NON-REGRESSIVE)
============================================================ */

let sseInstance = null;

function connectSSE(){

    if (transportStopped || sseStopped) {
        return;
    }

    if (sseInstance && sseInstance.readyState === 1) {
        return; // 🔒 already connected
    }

    try {

        if (sseInstance) {
            sseInstance.close();
        }

        /* ============================================================
           SSE ENDPOINT WITH RESUME SUPPORT
        ============================================================ */

        let lastEventId = localStorage.getItem("mt_last_event_id") || "";

        const SSE_ENDPOINT =
            (window.__MT_STREAM_ENDPOINT__ || "/v1/telemetry/stream") +
            (lastEventId ? ("?lastEventId=" + encodeURIComponent(lastEventId)) : "");
        /*
        |--------------------------------------------------------------------------
        | Ensure endpoint is valid before connecting
        |--------------------------------------------------------------------------
        */

        if (!SSE_ENDPOINT || typeof SSE_ENDPOINT !== "string") {
            console.warn("[Mandatag] Invalid SSE endpoint → aborting");
            return;
        }

        sseInstance = new EventSource(SSE_ENDPOINT);


        sseInstance.addEventListener("activation", function(e){
            try {
                /* ============================================================
                   EVENT PROCESSING + ID TRACKING
                ============================================================ */

                if (e.lastEventId) {
                    localStorage.setItem("mt_last_event_id", e.lastEventId);
                }

                const payload = JSON.parse(e.data);

                if (
                    !payload ||
                    typeof payload !== "object"
                ) {
                    return;
                }

                handlePayload({
                    event: "activation",
                    data: payload
                });
            } catch(err){
                console.warn("[Mandatag] SSE parse error", err);
            }
        });

        /* ============================================================
           PHASE 38 — DEVTOOLS LIVE STREAM
        ============================================================ */

        sseInstance.addEventListener("devtools", function(e){

            try {

                const payload = JSON.parse(e.data);

                /*
                |--------------------------------------------------------------------------
                | Dispatch global event
                |--------------------------------------------------------------------------
                */

                window.dispatchEvent(new CustomEvent("mt:devtools", {
                    detail: payload
                }));

            } catch (err) {
                console.warn("[Mandatag] devtools stream parse error", err);
            }

        });

        sseInstance.addEventListener("auth_error", function(e){
            try {
                const data = JSON.parse(e.data);
                window.location.href = data.redirect || "/admin/login";
            } catch {
                window.location.href = "/admin/login";
            }
        });

        /* ============================================================
           SSE ERROR HANDLER (PHASE 36 — STABILITY HARDENING)
        ============================================================ */

        let stableConnectionTime = 0;

        sseInstance.onopen = function(){
            console.log("[Mandatag] SSE connected");
            stableConnectionTime = Date.now();
        };

        sseInstance.onerror = function(event){

            const lived = Date.now() - stableConnectionTime;

            /* ============================================================
               EXPECTED LIFECYCLE CLOSE (NOT AN ERROR)
            ============================================================ */

            if (lived > 30000) {

                console.debug("[Mandatag] SSE cycle completed (lifetime: " + lived + "ms)");

            } else {

                console.warn("[Mandatag] SSE error detected (lifetime: " + lived + "ms)");

            }

            /*
            |--------------------------------------------------------------------------
            | HARD FAILURE DETECTION
            |--------------------------------------------------------------------------
            | If connection dies too fast → server is unstable
            |--------------------------------------------------------------------------
            */

            if (sseInstance.readyState === 2) {
                console.warn("[Mandatag] SSE permanently closed by server");
            }

            sseInstance.close();

            /*
            |--------------------------------------------------------------------------
            | SMART RETRY CONTROL
            |--------------------------------------------------------------------------
            */

            if (lived < 2000) {

                console.warn("[Mandatag] SSE rejected immediately → server unavailable");

                /* 🔥 HARD FAIL (NO LOOP) */
                sseRetries = 999;

            } else {
                sseRetries++;
            }

            /*
            |--------------------------------------------------------------------------
            | HARD STOP CONDITION
            |--------------------------------------------------------------------------
            */

            if (sseRetries > 5) {

                console.warn("[Mandatag] SSE retry limit reached → stopping");

                sseStopped = true;
                transportStopped = true;
                transportCooldown = true;

                if (transportCooldownTimer) {
                    clearTimeout(transportCooldownTimer);
                }

                transportCooldownTimer = setTimeout(()=>{
                    transportCooldown = false;
                    transportStopped = false;
                    sseStopped = false;
                    wsStopped = false;
                    connectionAttempts = 0;
                    sseRetries = 0;

                    console.log("[Mandatag] Transport reset after cooldown");

                    connectWebSocket();

                }, 60000);

                if (sseReconnectTimer) {
                    clearTimeout(sseReconnectTimer);
                    sseReconnectTimer = null;
                }

                if (reconnectTimer) {
                    clearTimeout(reconnectTimer);
                    reconnectTimer = null;
                }

                console.warn("[Mandatag] ALL transport stopped (cooldown)");

                return;
            }

            /*
            |--------------------------------------------------------------------------
            | CONTROLLED BACKOFF
            |--------------------------------------------------------------------------
            */

            const delay = Math.min(4000 * Math.pow(2, sseRetries), 30000);

            sseReconnectTimer = setTimeout(() => {

                if (transportStopped || sseStopped || transportCooldown) return;

                console.debug("[Mandatag] Reconnecting SSE...");
                connectSSE();

            }, delay);
        };

    } catch (e) {
        console.error("[Mandatag] SSE failed completely", e);
    }
}

/* ============================================================
   BOOT
============================================================ */
if (location.hostname !== "localhost") {
    window.__MT_DISABLE_HOTRELOAD__ = true;
}

/* ============================================================
   TRANSPORT STRATEGY (PRODUCTION HARDENED)
============================================================ */

/*
|--------------------------------------------------------------------------
| RULE:
| - WebSocket ONLY if explicitly enabled
| - Otherwise → SSE immediately
| - Prevent retry storms in shared hosting
|--------------------------------------------------------------------------
*/

if (window.__MT_ENABLE_WS__ === true) {

    console.log("[Mandatag] WebSocket explicitly enabled");
    connectWebSocket();

} else {

    console.log("[Mandatag] Using SSE transport (stable mode)");
    wsStopped = true;

    /* 🔥 FAIL-SAFE: If backend is down → stop transport completely */
    setTimeout(() => {

        if (!sseInstance || sseInstance.readyState !== 1) {

            if (window.__MT_STREAM_STOPPED) return;

            window.__MT_STREAM_STOPPED = true;

            console.warn("[Mandatag] Stream backend unavailable → entering passive mode");

            transportStopped = true;

        }

    }, 15000);

    /* 🔒 HARD DISABLE WS COMPLETELY */
    window.__MT_DISABLE_WS__ = true;

    connectSSE();

}

/*
|--------------------------------------------------------------------------
| TAB VISIBILITY RECOVERY (CRITICAL FIX)
|--------------------------------------------------------------------------
*/

let visibilityLock = false;

document.addEventListener("visibilitychange", function(){

    if (document.visibilityState !== "visible") return;

    if (visibilityLock) return;

    if (transportStopped || transportCooldown) {
        console.log("[Mandatag] Transport stopped → no reconnect");
        return;
    }

    visibilityLock = true;

    console.log("[Mandatag] Tab active → reconnect check");

    setTimeout(() => {

        if (!wsStopped && !window.__MT_DISABLE_WS__) {

            if (!wsInstance || wsInstance.readyState !== WebSocket.OPEN) {
                connectWebSocket();
            }

        } else if (!sseStopped) {

            if (!sseInstance || sseInstance.readyState !== 1) {
                connectSSE();
            }

        }

        visibilityLock = false;

    }, 1500); // 🔒 debounce

});

window.addEventListener("beforeunload", function(){

    transportStopped = true;

    if (reconnectTimer) {
        clearTimeout(reconnectTimer);
    }

    if (sseReconnectTimer) {
        clearTimeout(sseReconnectTimer);
    }

    if (transportCooldownTimer) {
        clearTimeout(transportCooldownTimer);
    }

    try {

        if (wsInstance) {
            wsInstance.close();
        }

        if (sseInstance) {
            sseInstance.close();
        }

    } catch(e){}
});
})();