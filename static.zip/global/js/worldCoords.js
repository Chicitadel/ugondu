'use strict';

/* --------------------------------------------------------------------
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: worldCoords.js
 * Location: /public_htmlhttps://static.airroofers.eu/global/js/
 *
 * Purpose:
 *   Global country coordinate registry used by activation telemetry
 *
 * ZERO REGRESSION GUARANTEE
 * --------------------------------------------------------------------
 */

window.MANDATAG_WORLD_COORDS = {

US:[220,210], CA:[200,140], MX:[210,260],

BR:[330,330], AR:[330,420], CL:[300,420], CO:[310,290], PE:[300,340], VE:[320,270],

GB:[480,170], IE:[460,170], FR:[505,200], ES:[480,230], PT:[460,240],
DE:[520,180], NL:[515,170], BE:[510,185], IT:[540,230], CH:[525,205], AT:[540,200],
PL:[550,170], CZ:[540,185], HU:[560,205], RO:[580,210], GR:[575,250],

SE:[540,120], NO:[520,100], FI:[580,110], DK:[520,150],

RU:[650,120], UA:[590,170], TR:[610,220],

SA:[640,270], AE:[670,260], IL:[620,240], IR:[650,220], IQ:[640,230],
EG:[600,260], MA:[470,250], DZ:[500,250], TN:[520,240], LY:[540,250],

NG:[520,320], GH:[500,330], CI:[495,340], SN:[470,320],
KE:[600,330], ET:[620,310], TZ:[610,350], UG:[590,330],
ZA:[560,420], NA:[520,400],

IN:[680,260], PK:[660,250], BD:[700,260], LK:[690,300],
NP:[690,240],

CN:[740,220], MN:[720,190], KZ:[690,200],
JP:[820,210], KR:[790,210], KP:[780,205],

TH:[720,300], VN:[740,300], MY:[720,330], SG:[730,350], ID:[760,360],
PH:[790,300],

AU:[840,360], NZ:[900,400],

GE:[620,200], AM:[630,210], AZ:[640,205],

AF:[670,230], TJ:[700,210], KG:[710,210], UZ:[690,220],

IS:[430,120], GL:[250,80]

};