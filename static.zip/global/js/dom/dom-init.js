/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: dom-init.js
 * Location: /public_html/Assets/dom/
 * Purpose: Deterministic bootstrap orchestrator (NO UI RENDERING)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 58 — Render Ownership Enforcement
 *
 * Guarantees:
 * - Zero regression
 * - No UI overwrite
 * - Deterministic execution
 * - Memory safe
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD (STRICT — NON WRITABLE)
========================================================= */

if (window.__mtDomInit === true) return;

Object.defineProperty(window, "__mtDomInit", {
    value: true,
    writable: false,
    configurable: false
});

/* =========================================================
   SAFE EXECUTION WRAPPER
========================================================= */

function safe(name, fn){
    try {
        return fn();
    } catch (e){
        console.warn("[MT INIT ERROR]", name, e);
    }
}

/* =========================================================
   READY STATE HANDLER (DETERMINISTIC)
========================================================= */

function ready(fn){
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", fn, { once:true });
    } else {
        fn();
    }
}

/* =========================================================
   GLOBAL ESC HANDLER (DRAWER SAFE)
========================================================= */

document.addEventListener("keydown", function(e){

    if (e.key !== "Escape") return;

    const panel = document.getElementById("mt-drawer");
    if (panel) {
        panel.remove();
        console.debug("[MT] Drawer closed via ESC");
    }

});

/* =========================================================
   CONFIRMATION UTILITY (NO UI ENGINE CONFLICT)
========================================================= */

window.mtConfirm = function(message, onConfirm){

    const overlay = document.createElement("div");
    overlay.className = "mt-confirm-overlay";
    overlay.style.cssText = `
        position:fixed;
        inset:0;
        background:rgba(0,0,0,0.4);
        display:flex;
        align-items:center;
        justify-content:center;
        z-index:9999;
    `;

    const box = document.createElement("div");
    box.style.cssText = `
        background:#fff;
        padding:20px;
        border-radius:10px;
        width:320px;
        max-width:90%;
    `;

    const text = document.createElement("div");
    text.textContent = message;
    text.style.cssText = "margin-bottom:15px;font-weight:500;";

    const actions = document.createElement("div");
    actions.style.cssText = "display:flex;gap:10px;justify-content:flex-end;";

    const cancel = document.createElement("button");
    cancel.textContent = "Cancel";
    cancel.className = "mt-btn";

    const confirm = document.createElement("button");
    confirm.textContent = "Confirm";
    confirm.className = "mt-btn";
    confirm.style.cssText = "background:#dc2626;color:#fff;";

    cancel.onclick = () => overlay.remove();

    confirm.onclick = () => {
        overlay.remove();
        onConfirm?.();
    };

    actions.appendChild(cancel);
    actions.appendChild(confirm);

    box.appendChild(text);
    box.appendChild(actions);
    overlay.appendChild(box);

    document.body.appendChild(overlay);
};

/* =========================================================
   ACTION STYLES (SAFE — SINGLE INJECTION)
========================================================= */

safe("mtActionStyles", ()=>{

    if (document.getElementById("mt-action-style")) return;

    const style = document.createElement("style");
    style.id = "mt-action-style";

    style.textContent = `
    .mt-btn {
        padding:8px 12px;
        border-radius:6px;
        border:none;
        cursor:pointer;
        font-size:13px;
        font-weight:600;
        transition:all 0.2s ease;
    }

    .mt-btn:disabled {
        background:#e2e8f0 !important;
        color:#94a3b8 !important;
        cursor:not-allowed;
        opacity:0.7;
    }

    [data-action="activate-selected"]:disabled {
        background:#e5e7eb !important;
        color:#9ca3af !important;
    }

    .mt-btn[data-action="activate-selected"]:not(:disabled) {
        background:#16a34a;
        color:#fff;
    }

    .mt-btn[data-action="activate-license"] { background:#16a34a;color:#fff; }
    .mt-btn[data-action="deactivate-license"] { background:#64748b;color:#fff; }
    .mt-btn[data-action="revoke-license"] { background:#dc2626;color:#fff; }
    .mt-btn[data-action="suspend-license"] { background:#f59e0b;color:#000; }
    .mt-btn[data-action="reset-activations"] { background:#2563eb;color:#fff; }
    `;

    document.head.appendChild(style);

});

/* =========================================================
   🔥 BULK ACTIVATION (PHASE 72)
========================================================= */

safe("mtBulkActivation", ()=>{
    // 🔒 DISABLED — handled exclusively by mt-dispatcher.js
});

/* =========================================================
   BOOTSTRAP EXECUTION (STRICT ORDER)
========================================================= */

ready(function(){

    console.debug("[MT] Bootstrap start");

    /* ---------------- CORE ---------------- */

    safe("mtHealUI", ()=>window.mtHealUI?.());
    safe("monitorJwtExpiry", ()=>window.monitorJwtExpiry?.());
    safe("injectPulseStyles", ()=>window.injectPulseStyles?.());
    safe("verifyUiIntegrity", ()=>window.verifyUiIntegrity?.());

    /* ---------------- FORMS ---------------- */

    safe("mtBindForm", ()=>{
        if (typeof window.mtBindForm !== "function") return;

        document.querySelectorAll("form[data-mt-form]")
            .forEach(form=>{
                try { window.mtBindForm(form); }
                catch(e){ console.warn("[MT FORM ERROR]", e); }
            });
    });

    /* ---------------- SCHEMA ---------------- */

    safe("mtLoadSchemas", ()=>window.mtLoadSchemas?.());

    /* ---------------- MODULES ---------------- */

    safe("mtInitCommandPalette", ()=>window.mtInitCommandPalette?.());
    /* =========================================================
       🔒 NAV INIT GUARD (PHASE 73 — SINGLE EXECUTION)
    ========================================================= */

    safe("mtInitNavigationIntel", ()=>{

        if (window.__MT_NAV_INIT_DONE__) return;

        window.__MT_NAV_INIT_DONE__ = true;

        window.mtInitNavigationIntel?.();

    });

    /* ---------------- REDIRECT ---------------- */

    safe("mtSuccessRedirect", ()=>{

        const el = document.querySelector("[data-mt-redirect]");
        if (!el) return;

        const url = el.getAttribute("data-mt-redirect");
        const delay = parseInt(el.getAttribute("data-delay") || "1000", 10);

        setTimeout(()=>{
            window.location.href = url;
        }, delay);

    });

    /* ---------------- INSPECT LICENSE ---------------- */

    safe("mtInspectLicense", ()=>{
        // 🔒 delegated to dispatcher
    });

    /* ---------------- INSPECT INSTALL ---------------- */

    safe("mtInspectInstall", ()=>{
        // 🔒 delegated to dispatcher
    });

    /* =========================================================
       🔥 PHASE 72 — ACTIVATION ACTION ENGINE (NO RELOAD)
    ========================================================= */

    safe("mtActivationActions", ()=>{
        // 🔒 DISABLED — execution fully delegated to mt-dispatcher.js
    });
    
    /* MT_PATCH_REMOVE_UI_STATE_OVERRIDE_V1 */
    safe("mtUiStateSync", ()=>{
        console.debug("[MT] UI state sync disabled (contract-driven)");
    });

    console.debug("[MT] Bootstrap complete");

});

})();