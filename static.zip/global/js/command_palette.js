/* =========================================================
   Mandatag Command Palette
   Ctrl + K navigation
   Phase 53+ Stable Refactor
========================================================= */

(function(){

"use strict";

if (window.__mtCommandPaletteLoaded) return;
window.__mtCommandPaletteLoaded = true;

/* =========================================================
   STATE
========================================================= */

let palette = null;
let input = null;
let results = [];
let filtered = [];

/* =========================================================
   LOAD ROUTES (SAFE)
========================================================= */

async function loadRoutes(){

    try {

        const res = await fetch("/Mandatag/config/routes.registry.json");

        if (!res.ok) {
            throw new Error("Route registry fetch failed");
        }

        const routes = await res.json();

        if (!Array.isArray(routes)) return;

        results = [];

        routes.forEach(r => {

            if (r.method !== "GET") return;
            const routePath = String(
                r.path ||
                r.uri ||
                ''
            );

            if (!routePath.startsWith("/admin/")) return;
            if (routePath === "/admin/login") return;

            const label = routePath
                .replace("/admin/","")
                .replace(/-/g," ");

            results.push({
                label,
                path: routePath,
                type: "route"
            });

        });

        filtered = [...results];

    } catch (err) {
        console.warn("[MT] Command palette routes failed", err);
        results = [];
        filtered = [];
    }
}

/* =========================================================
   MT-PATCH-PALETTE-DOM-SOVEREIGN-001
   Bind ONLY to server-owned layout DOM
========================================================= */

function createUI(){

    /* 🔒 BIND EXISTING AUTHORITATIVE DOM */
    palette = document.getElementById("mt-command");

    if (!palette) {
        console.warn("[MT] Command palette container missing");
        return;
    }

    input = document.getElementById("mt-command-input");

    if (!input) {
        console.warn("[MT] Command palette input missing");
        return;
    }

    /* 🔒 SINGLE BIND GUARD */
    if (input.__mtBound === true) {
        return;
    }

    Object.defineProperty(input, "__mtBound", {
        value: true,
        writable: false
    });

    input.addEventListener("input", filter);

    console.debug("[MT] Command palette bound to layout DOM");
}

/* =========================================================
   FILTER
========================================================= */

function filter(){

    if (!input) return;

    const q = input.value.toLowerCase();

    filtered = results
    .filter(r => r.label.includes(q))
    .map(r => {

        let score = r.label.startsWith(q) ? 10 : 5;

        if (window.__DOC_COVERAGE__ !== undefined) {
            score += (window.__DOC_COVERAGE__ / 10);
        }

        return { ...r, _score: score };

    })
    .sort((a,b)=>b._score - a._score);

    render();
}

/* =========================================================
   RENDER
========================================================= */

function render(){

    const container = document.getElementById("mt-command-results");
    if (!container) return;

    container.innerHTML = "";

    filtered.slice(0,10).forEach(r => {

        const item = document.createElement("div");
        item.className = "mt-command-item";

        let icon = "📄";

        if (r.type === "route") icon = "🧭";
        if (r.type === "documentation") icon = "📘";

        item.textContent = icon + " " + r.label;

        item.onclick = () => {
            window.location.href = r.path;
        };

        container.appendChild(item);

    });
}

/* =========================================================
   OPEN / CLOSE
========================================================= */

function openPalette(){

    if (!palette || !input) return;

    palette.style.display = "flex";

    input.value = "";
    filtered = [...results];

    render();

    setTimeout(() => input.focus(), 10);
}

function closePalette(){

    if (!palette) return;

    palette.style.display = "none";
}

/* =========================================================
   KEY HANDLERS
========================================================= */

document.addEventListener("keydown", function(e){

    if (e.ctrlKey && e.key === "k") {
        e.preventDefault();
        openPalette();
    }

    if (e.key === "Escape") {
        closePalette();
    }

});

window.addEventListener("click", function(e){

    if (e.target.id === "mt-command") {
        closePalette();
    }

});

/* =========================================================
   GLOBAL INIT (DEFERRED SYSTEM)
========================================================= */

window.mtInitCommandPalette = async function(){

    if (palette) return; // 🔒 prevent duplicate init

    await loadRoutes();
    createUI();
};

})();

/* =========================================================
   MT-PATCH-PALETTE-AUTOBOOT-001
========================================================= */

(function(){

    if (window.__mtPaletteBooted === true) {
        return;
    }

    window.__mtPaletteBooted = true;

    const boot = () => {

        if (typeof window.mtInitCommandPalette !== "function") {
            console.warn("[MT] Command palette init unavailable");
            return;
        }

        window.mtInitCommandPalette()
            .then(() => {
                console.debug("[MT] Command palette ready");
            })
            .catch(err => {
                console.error("[MT] Command palette boot failed", err);
            });
    };

    if (window.__MT_UI_READY__ === true) {
        boot();
        return;
    }

    document.addEventListener("mt:ui-ready", boot, {
        once: true
    });

})();

