/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mutation-engine.js
 * Location: /public_html/Assets/dom/
 * Purpose: Deterministic async form submission handler
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 53 — Hardened Form Engine
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   STATE
========================================================= */

const ACTIVE_FORMS = new WeakSet();
const RETRY_LIMIT = 20;

/* =========================================================
   SAFE JSON PARSER
========================================================= */

async function safeJson(res){
    try {
        return await res.json();
    } catch {
        return { error: "Invalid server response" };
    }
}

/* =========================================================
   SAFE FETCH WITH TIMEOUT
========================================================= */

async function safeFetch(url, options = {}, timeout = 10000){

    const controller = new AbortController();
    const id = setTimeout(()=>controller.abort(), timeout);

    try {
        const res = await fetch(url, {
            ...options,
            signal: controller.signal
        });
        return res;
    } catch (e){
        if (e.name === "AbortError") {
            throw new Error("Request timeout");
        }
        throw e;
    } finally {
        clearTimeout(id);
    }
}

/* =========================================================
   MAIN BINDER
========================================================= */

const isFallback =
    typeof window.mtBindForm === "function" &&
    window.mtBindForm.toString().includes("[MT] mtBindForm fallback");

if (typeof window.mtBindForm !== "function" || isFallback) {

    try {
        Object.defineProperty(window, "mtBindForm", {
        value: function(form, attempt = 0){

    if (!form) return;

if (ACTIVE_FORMS.has(form)) return; // 🔒 HARD GUARD (STRONGER THAN DATASET)

if (form.dataset.asyncBound === "1") return;

    /* -----------------------------------------------------
       SCHEMA WAIT (SAFE RETRY)
    ----------------------------------------------------- */

    if (!window.__mtSchemasReady){

        if (attempt > RETRY_LIMIT) {
            console.warn("[MT] Schema load timeout — form skipped");
            return;
        }

        setTimeout(()=>window.mtBindForm(form, attempt + 1), 50);
        return;
    }

    form.dataset.asyncBound = "1";

    /* -----------------------------------------------------
       SUBMIT HANDLER
    ----------------------------------------------------- */

    // 🔥 MT-PATCH-PHASE-65-MUTATION-BYPASS-LICENSE-ACTIONS

    form.addEventListener("submit", async function(e){

        /* =====================================================
           🚫 BYPASS LICENSE ACTION FORMS (CRITICAL FIX)
           - Let dispatcher handle everything
           - Prevent wrong endpoint POST (/admin/activations)
        ===================================================== */

        if (
            form.hasAttribute("data-license-id") ||
            form.closest("[data-license-id]") ||
            form.hasAttribute("data-mt-license-form")
        ) {
            console.debug("[MT] mutation-engine bypassed (license form)");
            return; // 🔥 DO NOT intercept
        }

        if (form.dataset.sync === "1") return;

        e.preventDefault();

        if (ACTIVE_FORMS.has(form)) return;
        ACTIVE_FORMS.add(form);

        const fd = new FormData(form);

        try {

            const res = await safeFetch(window.location.href,{
                method:"POST",
                body: fd,
                credentials:"same-origin",
                headers:{ "X-Requested-With":"XMLHttpRequest" }
            });

            /* ---------------------------------------------
               REDIRECT HANDLING
            --------------------------------------------- */

            if (res.redirected){
                location.href = res.url;
                return;
            }

            /* ---------------------------------------------
               RESPONSE PARSE
            --------------------------------------------- */

            const data = await safeJson(res);

            /* MT-ACTION-RENDERER-SYNC */
            if (data && data.license_id && data.allowed_actions) {

                document.dispatchEvent(new CustomEvent("mt:license-updated", {
                    detail: {
                        license: data.license_id,
                        state: data.state,
                        allowed: data.allowed_actions,
                        meta: data.meta || {}
                    }
                }));
            }

            if (data.error){
                showToast(data.error, false);
                return;
            }

            showToast("Success", true);

            /* ---------------------------------------------
               DETERMINISTIC REFRESH
            --------------------------------------------- */

            if (typeof window.deterministicRefresh === "function"){
                await window.deterministicRefresh(window.scrollY);
            }

        } catch(e){

            console.warn("[MT FORM ERROR]", e);

            showToast(
                e.message === "Request timeout"
                    ? "Request timeout"
                    : "Request failed",
                false
            );

        } finally {

            /* ---------------------------------------------
               RELEASE LOCK (CRITICAL)
            --------------------------------------------- */

            ACTIVE_FORMS.delete(form);

        }

    });

        },
        writable: false,
        configurable: false

        });
        
    } catch(e) {
        console.warn("[MT] mtBindForm locked, skipping override");
    }
}

})();