/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: schema-engine.js
 * Location: /public_html/Assets/engine/
 * Purpose:
 *   Runtime schema consumer (no network, no concurrency)
 *
 * PATCH LEVEL: Phase 79 — Zero Fetch Runtime Engine
 *
 * Guarantees:
 * - Zero regression
 * - No fetch
 * - No concurrency issues
 * - Deterministic behavior
 * - Production safe
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtSchemaLoaderInitialized) return;

Object.defineProperty(window, "__mtSchemaLoaderInitialized", {
    value: true,
    writable: false
});

/* =========================================================
   MAIN LOADER
========================================================= */

function loadFormSchemas(){

    if (window.__mtSchemasReady === true) {
        console.debug("[MT] Schema already ready");
        return;
    }

    if (!window.FORM_SCHEMAS || !Array.isArray(window.FORM_SCHEMAS.schemas)) {

        console.error("[MT] Schema missing or invalid");

        window.FORM_SCHEMAS = {
            generated_at: Date.now(),
            schemas: [],
            _meta: { fallback: true }
        };

        window.__mtSchemasReady = true;
        return;
    }

    window.__mtSchemasReady = true;

    console.debug("[MT] Schema ready", window.FORM_SCHEMAS);

    /* ---------------------------------------------
       REBIND FORMS
    --------------------------------------------- */

    if (typeof window.mtBindForm === "function") {

        document.querySelectorAll("form[data-mt-form]")
            .forEach(form=>{
                try { window.mtBindForm(form); }
                catch(e){ console.warn("[MT FORM ERROR]", e); }
            });
    }
}

/* =========================================================
   PUBLIC API
========================================================= */

window.mtLoadSchemas = loadFormSchemas;

})();