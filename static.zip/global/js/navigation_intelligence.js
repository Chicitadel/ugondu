/**
 * Mandatag
 * Admin Navigation Intelligence Engine
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: navigation_intelligence.js
 * Location: /public_html/Assets/
 *
 * Purpose:
 * Adds intelligent navigation behaviour:
 *
 * - recent pages
 * - most visited pages
 * - search shortcuts
 * - telemetry indicator
 * - latency indicator
 *
 * Guarantees:
 * - Zero regression
 * - No backend dependency
 * - LocalStorage persistence
 * - Compatible with command palette
 * --------------------------------------------------------------------
 */

(function(){
    /* =========================================================
       🚫 PHASE 74 GLOBAL NAV DISABLE FLAG
    ========================================================= */

    window.__MT_NAV_CLIENT_DISABLED__ = "partial";

const RECENT_KEY = "mt_recent_pages";
const POPULAR_KEY = "mt_popular_pages";

function currentPage(){

return location.pathname;

}

function saveRecent(){

let pages = JSON.parse(localStorage.getItem(RECENT_KEY) || "[]");

const page = currentPage();

pages = pages.filter(p => p !== page);

pages.unshift(page);

pages = pages.slice(0,6);

localStorage.setItem(RECENT_KEY, JSON.stringify(pages));

}

function savePopular(){

let stats = JSON.parse(localStorage.getItem(POPULAR_KEY) || "{}");

const page = currentPage();

stats[page] = (stats[page] || 0) + 1;

localStorage.setItem(POPULAR_KEY, JSON.stringify(stats));

}

function getRecent(){

return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]");

}

function getPopular(){

const stats = JSON.parse(localStorage.getItem(POPULAR_KEY) || "{}");

return Object.keys(stats)

.sort((a,b)=>stats[b]-stats[a])

.slice(0,6);

}

function buildSection(title, pages){

if(!pages.length) return null;

const section = document.createElement("div");

section.className = "nav-intel-section";

const header = document.createElement("div");

header.className = "menu-group-title";

header.textContent = title;

section.appendChild(header);

pages.forEach(path=>{

const link = document.createElement("a");

link.href = path;

link.className = "nav-intel-link";

link.textContent = path.replace("/admin/","").replaceAll("-"," ");

section.appendChild(link);

});

return section;

}

function insertSidebar(){

/* =========================================================
   ✅ PHASE 75 — SAFE NAV INTELLIGENCE RENDER
   - Inject ONLY into dedicated slot
   - Singleton enforced
   - No sidebar root mutation
========================================================= */

const slot = document.getElementById("mt-nav-intel-slot");

if (!slot) return;

/* 🔒 SINGLETON GUARD */
if (slot.__mtNavIntelRendered === true) {
    return;
}

Object.defineProperty(slot, "__mtNavIntelRendered", {
    value: true,
    writable: false
});

/* 🔄 BUILD DATA */
const popular = buildSection("Popular", getPopular());
const recent  = buildSection("Recent", getRecent());

/* 🔒 CLEAR SLOT ONLY (NOT SIDEBAR) */
slot.innerHTML = "";

/* 🔽 INSERT IN ORDER */
if (recent)  slot.appendChild(recent);
if (popular) slot.appendChild(popular);

console.debug("[MT NAV] Intelligence rendered (safe slot)");

}

function probeHealth(){
    const start = performance.now();

    return fetch("/v1/health", { signal: AbortSignal.timeout(3000) })
        .then(r=>r.json())
        .then(data=>({
            ok: true,
            latency: Math.round(performance.now() - start),
            data
        }))
        .catch(()=>({
            ok: false,
            latency: null
        }));
}

function telemetryIndicator(result){
    const el = document.getElementById("sseStatus");
    if(!el) return;

    if(result.ok){
        el.classList.add("badge-active");
        el.classList.remove("badge-error");
    } else {
        el.classList.add("badge-error");
        el.classList.remove("badge-active");
        el.textContent = "OFFLINE";
    }
}

function latencyIndicator(result){
    if(!result.ok) return;

    let badge = document.getElementById("latencyBadge");

    if(!badge){
        badge = document.createElement("span");
        badge.id="latencyBadge";
        badge.className="badge";
        document.querySelector(".top-actions")?.appendChild(badge);
    }

    badge.textContent = "⚡ " + result.latency + " ms";
}

function highlightActive(){

const links = document.querySelectorAll("#sidebar a");

links.forEach(link=>{

if(link.pathname === location.pathname){

link.classList.add("active");

const parent = link.closest(".submenu");

if(parent){

parent.classList.add("open");

}

}

});

}

function init(){

saveRecent();

savePopular();

insertSidebar();

highlightActive();

probeHealth().then(result=>{
    telemetryIndicator(result);
    latencyIndicator(result);
});

}

/* =========================================================
   🔥 PHASE 53 PATCH — NAVIGATION INTEL INIT FIX
========================================================= */
// REMOVE DOMContentLoaded
window.mtInitNavigationIntel = init;

})();