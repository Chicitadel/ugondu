/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: license-inspector.js
 * Location: /public_html/Assets/
 * Purpose: License inspection UI (MT_UI driven, no DOM conflict)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 60 — Backend Authority + Forensic Restoration
 * MT-PATCH-FULL-FRONTEND-POLICY-REMOVAL-001
 */

(function(){

"use strict";

/* ============================================================
   SINGLE INSTANCE GUARD
============================================================ */

if (window.mtInspector) {
    console.debug("[MT Inspector] Already initialized");
    return;
}

console.debug("[MT Inspector] Initializing...");

/* ============================================================
   LEGACY COMPATIBILITY (UNCHANGED)
============================================================ */

window.mtInspectorLegacy = {
    inspectActivation(id){
        if (!id) return;

        fetch(`/v1/admin/license/inspect?activation_id=${id}`, {
            headers: {
                "Authorization": "Bearer " + window.MT_AUTH_TOKEN
            }
        })
        .then(r => r.json())
        .then(console.debug)
        .catch(console.error);
    }
};

document.addEventListener("click", function(e){

    const el = e.target.closest("[data-mt-action]");
    if (!el) return;

}, true);

/* ============================================================
   SANITIZER (KEEP)
============================================================ */

function sanitizeId(value){
    if (typeof value !== "string") return "";
    return /^[a-zA-Z0-9._:-]+$/.test(value) ? value : "";
}

/* =====================================================
   🔥 MT-PATCH-INSPECTOR-LABEL-RESOLVE-V2 (FINAL)
   Source of truth: DOM contract → data-meta
===================================================== */

function mtResolveActionLabel(action, license){

    try {

        if (!action) return "";

        const node = document.querySelector(
            `[data-license-id="${license}"]`
        );

        if (!node) return action;

        const metaAttr = node.getAttribute("data-meta");
        if (!metaAttr) return action;

        const meta = JSON.parse(metaAttr);

        if (
            meta &&
            typeof meta === "object" &&
            meta[action] &&
            typeof meta[action].label === "string"
        ) {
            return meta[action].label;
        }

        return action;

    } catch(e){
        console.warn("[MT LABEL RESOLVE]", e);
        return action;
    }
}

/* ============================================================
   PURE RENDER HELPERS (NO POLICY)
============================================================ */

function buildLicenseNode(data){
    const wrap = document.createElement("div");

    /* ============================================================
       🔥 BULK SELECTION HOOK (SAFE INJECTION)
    ============================================================ */

    const safeId = sanitizeId(String(data?.id || ""));

    // 🔥 CRITICAL: attach dispatcher contract anchor
    if (safeId){
        wrap.setAttribute("data-license-id", safeId);
    }

    const actions = Array.isArray(data.allowed_actions)
        ? data.allowed_actions
        : [];

    if (safeId && Array.isArray(actions)){
        mtBulk.register(safeId, actions);
    }


    [
        ["ID", data.id],
        ["Product", data.product_code],
        ["State", data.state],
        ["Issued", data.issued_at],
        ["Expires", data.expires_at],
        ["Anomaly", data.anomaly_score]
    ].forEach(([k,v])=>{
        const row = document.createElement("div");
        row.textContent = `${k}: ${v ?? "—"}`;
        wrap.appendChild(row);
    });

    return wrap;
}

function buildActionsNode(id, allowedActions, meta){

    const safeId = sanitizeId(String(id || ""));
    const wrap = document.createElement("div");

    wrap.style.cssText = "display:flex;gap:8px;flex-wrap:wrap;";

    if (!safeId || !Array.isArray(allowedActions)) return wrap;

    allowedActions.forEach(action => {

        /* 🔒 HARD BLOCK — NO RECURSIVE INSPECT */
        if (action === "inspect") return;

        const m = meta?.[action];
        if (!m) return;

        const btn = document.createElement("button");

        const dispatcherAction = m.action || action;

        btn.className = "mt-btn";
        btn.textContent = m.label || action;

        btn.style.background = m.color || "#334155";
        btn.style.color = m.text || "#fff";

        btn.dataset.mtAction = dispatcherAction;
        btn.dataset.action = dispatcherAction;
        btn.dataset.contract = "1";
        btn.dataset.license = safeId;

        if (m.confirm) {
            btn.dataset.confirm = "true";
        }

        wrap.appendChild(btn);
    });

    return wrap;
}

function buildInstallNode(data){
    const wrap = document.createElement("div");

    [
        ["Install ID", data.install_id],
        ["Environment", data.environment],
        ["IP", data.ip],
        ["Last Seen", data.last_seen]
    ].forEach(([k,v])=>{
        const row = document.createElement("div");
        row.textContent = `${k}: ${v ?? "—"}`;
        wrap.appendChild(row);
    });

    return wrap;
}

function buildInstallActionsNode(data, allowed){

    const wrap = document.createElement("div");
    wrap.style.cssText = "display:flex;gap:8px;flex-wrap:wrap;";

    const installId = sanitizeId(String(data.install_id || ""));
    const licenseId = sanitizeId(String(data.license_id || ""));

    if (!installId || !licenseId) return wrap;

    // 🔒 STRICT CONTRACT
    if (!Array.isArray(allowed)){
        console.warn("[MT Inspector] install allowed_actions invalid");
        return wrap;
    }

    if (!allowed.length){
        const empty = document.createElement("div");
        empty.textContent = "No actions available";
        empty.style.opacity = "0.6";
        wrap.appendChild(empty);
        return wrap;
    }

    // 🔥 DISPATCHER-SAFE ACTION MAP
    const INSTALL_ACTION_MAP = {
        revoke: "revoke",
        suspend: "suspend",
        inspect: "inspect"
    };

    allowed.forEach(action => {

        const mapped = INSTALL_ACTION_MAP[action];
        if (!mapped) return; // 🚫 block unsupported actions

        const btn = document.createElement("button");
        btn.className = "mt-btn";
        btn.textContent = mtResolveActionLabel(action, licenseId);

        btn.dataset.mtAction = mapped;
        btn.dataset.install = installId;
        btn.dataset.license = licenseId;
        btn.dataset.confirm = "true";

        wrap.appendChild(btn);
    });

    return wrap;
}

/* ============================================================
   CORE INSPECTOR (NOW PURE CONSUMER)
============================================================ */

window.mtInspector = {

    async open(id){

        if (!id){
            window.MT_UI?.toast("Invalid license reference", false);
            return;
        }

        try{
            const res = await fetch(`/admin/api/license-inspect?id=${encodeURIComponent(id)}`, {
                headers: { "X-Requested-With": "XMLHttpRequest" }
            });

            const text = await res.text();
            let json = null;

            try {
                json = JSON.parse(text);
            } catch {}

            if (!res.ok) {
                throw new Error(`HTTP ${res.status}: ${text}`);
            }

            if (!json || json.error){
                window.MT_UI?.toast("Inspection failed", false);
                return;
            }

            this._lastId = id;
            /* ============================================================
               🔥 MT-PATCH-INSPECTOR-CONTRACT-ALIGNMENT-002
               Native support for Phase 72 backend contract
            ============================================================ */

            let payload = null;

            /* -----------------------------------------
               NEW CONTRACT (PRIMARY)
            ----------------------------------------- */
            if (json && json.success === true && typeof json.license === "string") {

                payload = {
                    license: {
                        id: json.license,
                        state: json.state
                    },
                    allowed_actions: Array.isArray(json.allowed_actions)
                        ? json.allowed_actions
                        : [],
                    meta: json.meta || {},
                    activations: json.activations || [],
                    risk_score: json.risk_score || 0,
                    risk_factors: json.risk_factors || [],
                    timeline: json.timeline || []
                };
            }

            /* -----------------------------------------
               LEGACY FALLBACK (SAFE)
            ----------------------------------------- */
            else if (json && typeof json.data === "object") {
                payload = json.data;
            }

            if (!payload || typeof payload !== "object") {
                console.error("[MT Inspector] invalid payload", json);
                window.MT_UI?.toast("Invalid inspection data", false);
                return;
            }

            this.render(payload);

        }catch(e){
            console.error(e);
            window.MT_UI?.toast("Network error", false);
        }
    },

    render(data){

        if (!data || typeof data !== "object") {
            console.warn("[MT Inspector] render aborted — invalid data");
            return;
        }

        // 🔒 REMOVED: ALL STATE FALLBACKS / GLOBAL POLICY

        const risk = Number(data.risk_score ?? 0);

        const riskColor =
            risk >= 80 ? "#dc2626" :
            risk >= 50 ? "#f59e0b" :
            "#16a34a";

        // =====================================================
        // FORENSIC DATA (NON-POLICY — RESTORED)
        // =====================================================

        const factors = (data.risk_factors || [])
            .map(f => `• ${f}`)
            .join("\n") || "None";

        const timeline = (data.timeline || [])
            .map(e => `${e.ts} | ${e.event} | anomaly:${e.anomaly} | ip:${e.ip}`)
            .join("\n") || "No events";

        function buildActivationsNode(list, licenseId){

            const wrap = document.createElement("div");

            (list || []).forEach(a => {

                const row = document.createElement("div");
                row.style.cssText = "padding:6px 0;border-bottom:1px solid #eee;cursor:pointer;";

                const safeInstall = sanitizeId(String(a.install_id ?? ""));
                const safeLicense = sanitizeId(String(licenseId ?? ""));

                if (!safeInstall || !safeLicense) return;

                row.setAttribute("data-mt-action", "inspect-install");
                row.setAttribute("data-install", safeInstall);
                row.setAttribute("data-license", safeLicense);

                const strong = document.createElement("strong");
                strong.textContent = a.install_id || "—";

                const meta = document.createElement("span");
                meta.textContent = ` | ${a.environment || "—"} | ${a.activated_at || "—"}`;

                row.appendChild(strong);
                row.appendChild(meta);

                wrap.appendChild(row);
            });

            return wrap;
        }

        const payloadStr = JSON.stringify(data.payload || {}, null, 2);
        const safePayload = payloadStr.length > 5000
            ? payloadStr.slice(0, 5000) + "\n…truncated"
            : payloadStr;

        const sections = [
            {
                title: "🔥 Risk Score",
                content: (() => {
                    const el = document.createElement("div");
                    const strong = document.createElement("strong");

                    strong.style.color = riskColor;
                    strong.textContent = String(risk);

                    el.appendChild(document.createTextNode("Score: "));
                    el.appendChild(strong);

                    return el;
                })()
            },

            {
                title: "⚠️ Risk Factors",
                content: (data.risk_factors || []).join("\n") || "None"
            },

            {
                title: "🌍 Geo",
                content: data?.geo
                    ? `${data.geo.country} (${data.geo.ip})`
                    : "Unknown"
            },

            {
                title: "🧩 Activations",
                content: buildActivationsNode(data.activations, data.license?.id)
            },

            {
                title: "🔐 Payload",
                content: safePayload
            },

            {
                title: "📜 Timeline",
                content: (data.timeline || [])
                    .map(e => `${e.ts} | ${e.event}`)
                    .join("\n") || "No events"
            },

            {
                title: "📦 License",
                content: buildLicenseNode(data.license || {})
            },

            {
                title: "⚙️ Actions",
                content: buildActionsNode(
                    data.license?.id,
                    data.allowed_actions,
                    data.meta
                )
            }

        ];

        (window.mtInspectorDrawer || window.MT_UI?.drawer)?.("License Intelligence", sections);
    },

    renderInstall(data){

        const sections = [

            {
                title: "🧩 Install",
                content: buildInstallNode(data)
            },

            {
                title: "🔥 Risk",
                content: `Score: ${data.risk_score ?? 0}`
            },

            {
                title: "⚙️ Actions",
                content: buildInstallActionsNode(
                    data,
                    data.allowed_actions
                )
            }

        ];

        (window.mtInspectorDrawer || window.MT_UI?.drawer)?.("Install Intelligence", sections);
    },

    refresh(){
        if (this._lastId) this.open(this._lastId);
    }
};

/* ============================================================
   🔥 BULK SELECTION MODEL (NON-INTRUSIVE)
============================================================ */
const mtBulk = {

    selected: new Set(),
    allowedMap: new Map(),

    bar: null,
    countNode: null,
    actionsContainer: null,

    renderActions(container){

        if (!(container instanceof HTMLElement)) return;

        container.replaceChildren();

        const allowed = this.getBulkAllowed();
        const ids = this.getList(); // 🔥 REQUIRED

        // 🔒 No hardcoded action list — backend is authority
        // 🔥 Backend is authority — allow all
        const SAFE_ACTIONS = allowed;

        allowed.forEach(action => {

            if (!SAFE_ACTIONS.includes(action)) return;

            const label = mtResolveActionLabel(action, ids[0]);

            if (!label) return;

            container.appendChild(
                this.createBtn(`bulk-${action}`, label)
            );
        });
    },

    createBtn(action, label){
        const btn = document.createElement("button");
        btn.className = "mt-btn";
        btn.setAttribute("data-action", action);
        btn.textContent = label;
        return btn;
    },

    toggle(id){
        if (!id || typeof id !== "string") return;

        if (this.selected.has(id)) {
            this.selected.delete(id);
        } else {
            this.selected.add(id);
        }

        this.updateUI();
    },

    register(id, actions){
        if (!id || !Array.isArray(actions)) return;
        this.allowedMap.set(id, actions);
    },

    getBulkAllowed(){

        const ids = this.getList();
        if (!ids.length) return [];

        let intersection = null;

        ids.forEach(id => {

            const actions = this.allowedMap.get(id) || [];

            if (!intersection){
                intersection = new Set(actions);
            } else {
                intersection = new Set(
                    actions.filter(a => intersection.has(a))
                );
            }
        });

        return intersection ? Array.from(intersection) : [];
    },

    clear(){
        this.selected.clear();
        this.updateUI();
    },

    getList(){
        return Array.from(this.selected);
    },

    initBar(){

        if (this.bar) return;

        const bar = document.createElement("div");
        bar.className = "mt-bulk-bar";

        Object.assign(bar.style, {
            position: "fixed",
            bottom: "10px",
            left: "10px",
            right: "10px",
            background: "#111827",
            color: "#fff",
            padding: "10px",
            display: "none",
            justifyContent: "space-between",
            alignItems: "center",
            borderRadius: "8px",
            zIndex: "9999"
        });

        const left = document.createElement("div");
        this.countNode = document.createTextNode("0 selected");
        left.appendChild(this.countNode);

        const right = document.createElement("div");
        right.style.display = "flex";
        right.style.gap = "8px";

        this.actionsContainer = right;

        bar.appendChild(left);
        bar.appendChild(right);

        document.body.appendChild(bar);
        this.bar = bar;
    },

    updateUI(){
        // 🔒 MT-PATCH-STABILIZATION: Duplicate bulk bar disabled in favor of activations.view.php primary bar
        return;
    }
};

// 🔥 GLOBAL EXPORT (CRITICAL)
window.mtBulk = mtBulk;

/* ============================================================
   ACTION DISPATCH (UNCHANGED — PURE TRANSPORT)
============================================================ */

const root = document.querySelector(".admin-page") || document;

/* ============================================================
   🔥 MT-PATCH-DISPATCHER-DELEGATION-V2 (TCP FIX)
   - No late mutation
   - Dispatcher always sees action
   - Zero race condition
============================================================ */

root.addEventListener("click", function (e) {

    let el = e.target;

    /* 🔒 HARD WALK (same as dispatcher) */
    while (el && el !== document) {

        if (el.hasAttribute && el.hasAttribute("data-mt-action")) {
            break;
        }

        el = el.parentNode;
    }

    if (!el || el === document) return;

    /* 🔥 CRITICAL FIX: promote BEFORE dispatcher reads */
    if (!el.hasAttribute("data-action")) {

        let action = el.getAttribute("data-mt-action");
        if (!action) return;

        action = action.replace(/_/g, "-");

        el.setAttribute("data-action", action);
    }

}, true); // 🔥 CAPTURE PHASE (MATCH DISPATCHER)

/* ============================================================
   🔥 RESET ACTIVATIONS PREVIEW (DRY-RUN UI)
============================================================ */

function showResetPreview({ licenseId, count, environments }){

if (!licenseId || typeof licenseId !== "string") return;

    /* ============================================================
       🔒 SAFE HELPERS (LOCAL)
    ============================================================ */

    function strong(text){
        const s = document.createElement("strong");
        s.textContent = text;
        return s;
    }

    /* ============================================================
       ROOT CONTAINER
    ============================================================ */

    const content = document.createElement("div");
    content.style.padding = "10px";


    /* ============================================================
       TITLE
    ============================================================ */

    const title = document.createElement("div");
    title.style.marginBottom = "10px";

    const titleStrong = document.createElement("strong");
    titleStrong.textContent = "Reset Activations Preview";

    title.appendChild(titleStrong);


    /* ============================================================
       INFO BLOCK (SAFE)
    ============================================================ */

    const info = document.createElement("div");

    // line 1 — count
    const row1 = document.createElement("div");
    row1.appendChild(document.createTextNode("🔢 Activations affected: "));
    row1.appendChild(strong(String(count)));

    // line 2 — environments
    const row2 = document.createElement("div");
    row2.appendChild(document.createTextNode("🌍 Environments: "));
    row2.appendChild(
        strong(
            Array.isArray(environments) && environments.length
                ? environments.join(", ")
                : "none"
        )
    );

    // line 3 — warning
    const row3 = document.createElement("div");
    row3.style.marginTop = "8px";
    row3.style.color = "#b45309";
    row3.textContent = "⚠️ This will revoke all active installs for this license.";


    /* ============================================================
       ACTION BUTTONS
    ============================================================ */

    const actions = document.createElement("div");
    actions.style.marginTop = "15px";
    actions.style.display = "flex";
    actions.style.gap = "10px";

    const confirmBtn = document.createElement("button");
    confirmBtn.className = "mt-btn";
    confirmBtn.textContent = "Confirm Reset";

    confirmBtn.tabIndex = 0;

    const cancelBtn = document.createElement("button");
    cancelBtn.className = "mt-btn";
    cancelBtn.textContent = "Cancel";
    cancelBtn.style.opacity = "0.6";

    /* ============================================================
       🔐 TYPED CONFIRMATION (HUMAN SAFETY LOCK)
    ============================================================ */

    const confirmWrap = document.createElement("div");
    confirmWrap.style.marginTop = "12px";

    // 🔒 live validation
    const expected = `RESET ${licenseId}`;

    const confirmInput = document.createElement("input");
    confirmInput.type = "text";
    confirmInput.className = "mt-input";
    confirmInput.style.marginTop = "6px";
    confirmInput.style.padding = "6px";
    confirmInput.style.width = "100%";
    confirmInput.autocomplete = "off";
    confirmInput.placeholder = expected;

    const confirmLabel = document.createElement("div");
    confirmLabel.textContent = `Type "${expected}" to confirm`;
    confirmLabel.style.fontSize = "12px";
    confirmLabel.style.opacity = "0.7";

    // 🔒 disable by default
    confirmBtn.disabled = true;
    confirmBtn.style.opacity = "0.5";


    confirmInput.addEventListener("input", () => {

        const value = confirmInput.value.trim();
        const valid = value === expected;

        confirmBtn.disabled = !valid;
        confirmBtn.style.opacity = valid ? "1" : "0.5";
    });

    /* 🔒 ANTI MUSCLE-MEMORY (BLUR RESET) */
    confirmInput.addEventListener("blur", () => {
        confirmInput.value = "";
        confirmBtn.disabled = true;
        confirmBtn.style.opacity = "0.5";
        resetHold();
    });

    confirmWrap.appendChild(confirmLabel);
    confirmWrap.appendChild(confirmInput);

    /* 🔒 UX: AUTO-FOCUS INPUT */
    setTimeout(() => confirmInput.focus(), 0);

    /* 🔒 HARDENING: DISABLE PASTE (OPTIONAL BANK-GRADE) */
    confirmInput.addEventListener("paste", e => e.preventDefault());

    actions.appendChild(confirmBtn);
    actions.appendChild(cancelBtn);


    /* ============================================================
       ASSEMBLE
    ============================================================ */

    info.appendChild(row1);
    info.appendChild(row2);
    info.appendChild(row3);

    content.appendChild(title);
    content.appendChild(info);
    content.appendChild(confirmWrap);
    content.appendChild(actions);


    /* ============================================================
       DRAWER
    ============================================================ */

    const rawClose = (window.mtInspectorDrawer || window.MT_UI?.drawer)?.("⚠️ Confirm Reset", [
        { title: "Preview", content }
    ]);

    const close = () => {
        resetHold();
        rawClose?.();
    };


    /* ============================================================
       ACTION HANDLERS
    ============================================================ */

    /* ============================================================
   🔐 HOLD-TO-CONFIRM (SAFE IMPLEMENTATION)
============================================================ */

let holdTimer = null;
let holdActive = false;
let executed = false;

// visual feedback
confirmBtn.style.position = "relative";

const progress = document.createElement("div");
progress.style.position = "absolute";
progress.style.left = "0";
progress.style.bottom = "0";
progress.style.height = "2px";
progress.style.width = "0%";
progress.style.background = "#16a34a";
progress.style.transition = "width 0.3s linear";

confirmBtn.appendChild(progress);

function resetHold(){
    clearTimeout(holdTimer);
    holdTimer = null;
    holdActive = false;
    progress.style.width = "0%";
}

function triggerAction(){

    if (executed) return;
    executed = true;

    confirmBtn.disabled = true;

    fetch(`/admin/api/license-action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            action: "reset_activations",
            license_id: licenseId
        })
    })
    .then(res => res.json())
    .then(data => {

        if (data && data.license_id && data.allowed_actions){

            function isValidContract(d){
                return d &&
                    typeof d.license === "string" &&
                    typeof d.state === "string" &&
                    Array.isArray(d.allowed_actions);
            }

            document.dispatchEvent(new CustomEvent("mt:license-updated", {
                detail: {
                    license: data.license_id,
                    state: data.state,
                    allowed_actions: data.allowed_actions,
                    meta: data.meta || {}
                }
            }));
        }

        window.mtInspector?.refresh();
    })
}

// pointer down (mouse + touch)
confirmBtn.addEventListener("pointerdown", () => {

    if (confirmBtn.disabled || executed) return;

    holdActive = true;
    progress.style.width = "100%";

    holdTimer = setTimeout(() => {
        if (holdActive) triggerAction();
    }, 300);
});

// cancel conditions
["pointerup","pointerleave","pointercancel"].forEach(evt => {
    confirmBtn.addEventListener(evt, resetHold);
});

// 🔒 keyboard fallback (accessibility)
confirmBtn.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !confirmBtn.disabled){
        triggerAction();
    }
});

    const originalClose = close;

    const safeClose = () => {
        resetHold();
        originalClose?.();
    };

    cancelBtn.onclick = safeClose;
}

/* ============================================================
   [MT_INSPECTOR_SAFE_REFRESH_GUARD_V2]
   Phase 61 — Event-driven UI synchronization

   Guarantees:
   - Inspector auto-refresh on state change
   - Bulk permission map stays in sync
   - No stale allowed_actions anywhere
============================================================ */

(function(){

    if (window.__mtInspectorSyncBound) return;

    Object.defineProperty(window, "__mtInspectorSyncBound", {
        value: true,
        writable: false,
        configurable: false
    });

    /* ============================================================
       🔒 SAFE DRAWER HOOK (NO MUTATION OF MT_UI)
    ============================================================ */

    let inspectorOpen = false;

    const MT_UI_SAFE = window.MT_UI;

    if (MT_UI_SAFE && typeof MT_UI_SAFE.drawer === "function") {

        const originalDrawer = MT_UI_SAFE.drawer.bind(MT_UI_SAFE);

        /* ============================================================
           🔥 MT_PATCH_INSPECTOR_STATE_LIFECYCLE_V2 (AUTHORITATIVE)
           - Single source of truth for inspector open/close state
           - Clears dispatcher lock safely
           - No DOM guessing
        ============================================================ */

        window.mtInspectorDrawer = function(title, sections){

            inspectorOpen = true;

            const close = originalDrawer(title, sections);

            /* =========================================================
               🔒 MARK ACTIVE PANEL (AFTER DOM EXISTS)
            ========================================================= */

            requestAnimationFrame(() => {

                const panel = document.querySelector("[data-mt-inspector]");

                if (panel instanceof HTMLElement) {
                    panel.setAttribute("data-mt-inspector", "active");
                }
            });

            return function(){

                inspectorOpen = false;

                /* =====================================================
                   🔥 HARD RESET (CRITICAL FIX)
                   - Clears dispatcher identity lock
                   - Prevents stuck inspector state
                ===================================================== */

                const panel = document.querySelector("[data-mt-inspector]");

                if (panel instanceof HTMLElement) {
                    panel.removeAttribute("data-mt-inspector");
                    panel.removeAttribute("data-license-id");
                }

                return close?.();
            };
        };

    }

    /* ============================================================
       🔒 SAFE CONTRACT SYNC (NO FORCED REOPEN)
    ============================================================ */

    document.addEventListener("mt:license-updated", function(e){

        const detail = e?.detail || {};

        const license = typeof detail.license === "string"
            ? detail.license
            : null;

        const allowed = Array.isArray(detail.allowed_actions)
            ? detail.allowed_actions
            : null;

        if (!license) return;

        console.debug("[MT Inspector Sync]", {
            license,
            inspectorOpen
        });

        /* ----------------------------------------------------
           1. BULK MAP SYNC (ALWAYS SAFE)
        ---------------------------------------------------- */

        if (allowed && window.mtBulk?.register) {
            window.mtBulk.register(license, allowed);
        }

        /* ----------------------------------------------------
           2. 🔥 SAFE REFRESH (ONLY IF VISIBLE)
        ---------------------------------------------------- */

        if (
            inspectorOpen &&
            window.mtInspector &&
            window.mtInspector._lastId === license
        ) {
            console.debug("[MT Inspector] refreshing active view:", license);

            setTimeout(() => {
                window.mtInspector.refresh();
            }, 0);
        }

        /* ❌ DO NOT REOPEN IF CLOSED */

    });

})();


window.__mtInspectorReady = true;

console.debug("[MT Inspector] Fully initialized");

})();