'use strict';

/* --------------------------------------------------------------------
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 *
 * --------------------------------------------------------------------
 * File: activation.map.js
 * Location: /public_htmlhttps://static.airroofers.eu/global/js/
 *
 * Purpose:
 *   Global Activation Telemetry Engine
 *
 * Features
 *   - Pulse animation
 *   - Activation trails
 *   - Cluster bursts
 *   - Fraud detection highlight
 *   - Attack arcs
 *   - Heat accumulation
 *   - SSE reconnect
 *   - Geo + country fallback support
 *
 * ZERO REGRESSION GUARANTEE
 * --------------------------------------------------------------------
 */

(function(){

const SVG_NS="http://www.w3.org/2000/svg";

/* CONFIG (original values preserved) */

const CONFIG={
pulseDuration:2000,
trailDuration:4000,
burstThreshold:3,
maxDots:120,
reconnectDelay:3000
};

const coords=window.MANDATAG_WORLD_COORDS||{};

const map=document.getElementById("activationMap");

if(!map)return;

/* INTERNAL STATE */

let dots=[];
let clusterBuffer={};
let heat={};

/* SVG UTIL */

function svg(tag){
return document.createElementNS(SVG_NS,tag);
}

function riskColor(r){

if(r==="high")return "#dc2626";
if(r==="medium")return "#f59e0b";
return "#22c55e";

}

function randomOffset(){
return (Math.random()-0.5)*6;
}

/* GEO CONVERSION */

function latLonToXY(lat,lon){

const x=((lon+180)/360)*1000;
const y=((90-lat)/180)*500;

return [x,y];

}

/* PULSE */

function pulse(x,y,color){

const c=svg("circle");

c.setAttribute("cx",x);
c.setAttribute("cy",y);
c.setAttribute("r",4);
c.setAttribute("fill",color);

map.appendChild(c);

dots.push(c);

let start=performance.now();

function frame(t){

let p=(t-start)/CONFIG.pulseDuration;

if(p>=1){
c.remove();
return;
}

c.setAttribute("r",4+p*14);
c.style.opacity=1-p;

requestAnimationFrame(frame);

}

requestAnimationFrame(frame);

}

/* TRAIL */

function trail(x,y){

const t=svg("circle");

t.setAttribute("cx",x+randomOffset());
t.setAttribute("cy",y+randomOffset());
t.setAttribute("r",2);
t.setAttribute("fill","#38bdf8");

map.appendChild(t);

setTimeout(()=>t.remove(),CONFIG.trailDuration);

}

/* BURST */

function burst(x,y){

for(let i=0;i<6;i++){

const p=svg("circle");

p.setAttribute("cx",x);
p.setAttribute("cy",y);
p.setAttribute("r",3);
p.setAttribute("fill","#a78bfa");

map.appendChild(p);

let angle=(Math.PI*2)*(i/6);
let dist=0;

function move(){

dist+=2;

p.setAttribute("cx",x+Math.cos(angle)*dist);
p.setAttribute("cy",y+Math.sin(angle)*dist);

if(dist>40){
p.remove();
return;
}

requestAnimationFrame(move);

}

move();

}

}

/* FRAUD DETECTOR */

function fraudHighlight(x,y){

const r=svg("circle");

r.setAttribute("cx",x);
r.setAttribute("cy",y);
r.setAttribute("r",20);
r.setAttribute("stroke","#ef4444");
r.setAttribute("stroke-width","2");
r.setAttribute("fill","none");

map.appendChild(r);

setTimeout(()=>r.remove(),4000);

}

/* ATTACK ARC */

function arc(x1,y1,x2,y2){

const path=svg("path");

const midX=(x1+x2)/2;
const midY=(y1+y2)/2-60;

const d=`M ${x1} ${y1} Q ${midX} ${midY} ${x2} ${y2}`;

path.setAttribute("d",d);
path.setAttribute("stroke","#38bdf8");
path.setAttribute("stroke-width","1.5");
path.setAttribute("fill","none");

map.appendChild(path);

setTimeout(()=>path.remove(),5000);

}

/* HEAT */

function updateHeat(key){
heat[key]=(heat[key]||0)+1;
}

/* RENDER */

function render(data){

let x,y;

if(data.geo){

const p=latLonToXY(data.geo.lat,data.geo.lon);
x=p[0];
y=p[1];

}else{

const country=data.country||"US";

const point=coords[country]||[500,250];

x=point[0];
y=point[1];

}

const risk=data.risk||"low";

pulse(x,y,riskColor(risk));
trail(x,y);

const key=data.country||"global";

clusterBuffer[key]=(clusterBuffer[key]||0)+1;

if(clusterBuffer[key]>=CONFIG.burstThreshold){

burst(x,y);
clusterBuffer[key]=0;

}

updateHeat(key);

if(risk==="high"){
fraudHighlight(x,y);
}

}

/* SSE */

let stream;

function connect(){

try{

stream=new EventSource("/v1/telemetry/stream");

}catch(e){

console.warn("Telemetry stream unavailable");

return;

}

stream.addEventListener("activation",e=>{

try{

const data=JSON.parse(e.data);
render(data);

}catch(err){}

});

stream.onerror=function(){

try{stream.close()}catch(e){}

setTimeout(connect,CONFIG.reconnectDelay);

};

}

connect();

/* RESPONSIVE */

function scale(){

map.setAttribute(
"preserveAspectRatio",
"xMidYMid meet"
);

}

window.addEventListener("resize",scale);

scale();

})();


/* ==========================================================
   Mandatag Risk Dial Renderer
   Lightweight canvas gauge (no dependency)
========================================================== */

(function(){

const score = parseInt(document.body.dataset.risk || "0");
const canvas = document.getElementById("riskDial");

if(!canvas) return;

const ctx = canvas.getContext("2d");

const size = canvas.width;
const center = size/2;
const radius = 46;

ctx.clearRect(0,0,size,size);

/* base ring */

ctx.lineWidth = 10;
ctx.strokeStyle = "rgba(255,255,255,0.25)";
ctx.beginPath();
ctx.arc(center,center,radius,0,Math.PI*2);
ctx.stroke();

/* score arc */

const angle = (score/100) * (Math.PI*2);

let color="#22c55e";

if(score>=75) color="#ef4444";
else if(score>=40) color="#f59e0b";

ctx.strokeStyle = color;

ctx.beginPath();
ctx.arc(
center,
center,
radius,
-Math.PI/2,
angle-Math.PI/2
);

ctx.stroke();

/* center text */

ctx.fillStyle="#ffffff";
ctx.font="bold 14px system-ui";
ctx.textAlign="center";
ctx.textBaseline="middle";

ctx.fillText(score+"%",center,center);

})();



