/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-hotreload.js
 * Location: /public_html/Assets/core/
 * Purpose: Safe development-only UI hot reload transport layer
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 55 — Hot Reload Transport Hardening
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtHotReloadInitialized) return;
window.__mtHotReloadInitialized = true;

/* =========================================================
   GLOBAL TRANSPORT DISABLE
========================================================= */

if (window.__MT_DISABLE_TRANSPORT__ === true) {
    console.debug("[MT] Hot reload disabled (global transport off)");
    return;
}

/* =========================================================
   ENVIRONMENT DETECTION
========================================================= */

const isLocal =
    location.hostname === "localhost" ||
    location.hostname === "127.0.0.1";

/* 🔒 HARD STOP IN PRODUCTION */
if (!isLocal) {
    console.debug("[MT] Hot reload disabled (production)");
    return;
}

/* =========================================================
   STATE
========================================================= */

let socket = null;
let retries = 0;
let stopped = false;

const MAX_RETRIES = 3;
const BASE_DELAY = 2000;

/* =========================================================
   PROTOCOL RESOLUTION
========================================================= */

const WS_PROTOCOL = location.protocol === "https:" ? "wss://" : "ws://";

/* =========================================================
   CONNECT
========================================================= */

function connect(){

    if (stopped) return;

    if (retries >= MAX_RETRIES) {
        console.warn("[MT] Hot reload stopped (retry limit reached)");
        stopped = true;
        return;
    }

    try {

        socket = new WebSocket(WS_PROTOCOL + location.host + "/ui-live");

        socket.onopen = function(){
            retries = 0;
            console.debug("[MT] Hot reload connected");
        };

        socket.onmessage = function(e){

            let msg;

            try {
                msg = JSON.parse(e.data);
            } catch {
                return; // silently ignore invalid payload
            }

            if (msg?.type !== "ui:update") return;

            const target = document.querySelector(msg.target);

            if (!target) return;

            if (window.MT_RENDER && typeof window.MT_RENDER.renderSchema === "function") {
                try {
                    window.MT_RENDER.renderSchema(target, msg.schema);
                } catch (err) {
                    console.warn("[MT] Render failure", err);
                }
            }

        };

        socket.onerror = function(){
            try { socket.close(); } catch {}
        };

        socket.onclose = function(){

            retries++;

            const delay = BASE_DELAY * retries;

            console.debug(`[MT] Hot reload retry ${retries}/${MAX_RETRIES}`);

            setTimeout(connect, delay);
        };

    } catch {

        retries++;
        setTimeout(connect, BASE_DELAY * retries);
    }

}

/* =========================================================
   VISIBILITY CONTROL (CRITICAL)
========================================================= */

document.addEventListener("visibilitychange", function(){

    if (document.hidden) {
        if (socket) {
            try { socket.close(); } catch {}
        }
    } else {
        if (!stopped) {
            connect();
        }
    }

});

/* =========================================================
   START
========================================================= */

connect();

})();