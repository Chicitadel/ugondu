/**
 * Mandatag
 * Action Renderer — Backend Contract Driven UI (SECURE)
 *
 * Guarantees:
 * - Deterministic hydration (no race conditions)
 * - Zero frontend business logic
 * - Backend contract is single source of truth
 * - XSS-safe (strict sanitization)
 * - Idempotent rendering
 * - Live updates (SSE/event driven)
 */

(function(){

"use strict";

/* ============================================================
   INIT GUARD
============================================================ */

if (window.__mtActionRendererInit) return;
window.__mtActionRendererInit = true;

/* ============================================================
   🔒 SECURITY HELPERS (CRITICAL)
============================================================ */

function safeStr(v){
    return typeof v === "string" ? v : "";
}

function safeAction(v){
    // allow only dispatcher-safe tokens
    return /^[a-z0-9\-_]+$/i.test(v) ? v : "";
}

function safeColor(v){
    // allow hex or safe fallback
    return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v) ? v : "#334155";
}

function safeLicense(v){
    return /^[a-zA-Z0-9._:-]+$/.test(v) ? v : "";
}

/* ============================================================
   🔐 UNIVERSAL CONTRACT NORMALIZER (GLOBAL — SINGLE SOURCE)
============================================================ */
/* ===== MT_PATCH_RENDERER_UNIVERSAL_NORMALIZER_V2 ===== */

function normalizeRawContract(raw){

    if (typeof raw !== "string") return null;

    try {

        let s = raw.trim();

        if (s === "" || s === "null" || s === "undefined"){
            return null;
        }

        // decode URI
        if (s.includes("%7B") || s.includes("%22")){
            s = decodeURIComponent(s);
        }

        // fix escaped unicode quotes
        if (s.includes("\\u0022")){
            s = s.replace(/\\u0022/g, '"');
        }

        return JSON.parse(s);

    } catch {
        return null;
    }
}

/* ============================================================
   🚀 DETERMINISTIC BOOT (NO RACE CONDITIONS)
============================================================ */

/* ===== MT_PATCH_FINAL_HYDRATION_LOCK_V7 ===== */

document.addEventListener("DOMContentLoaded", () => {
    requestAnimationFrame(() => {
        document.querySelectorAll("[data-action-container]")
            .forEach(renderContainer);
    });
});

/* ============================================================
   🔁 MUTATION OBSERVER (LIVE DOM SUPPORT — FIXED)
============================================================ */

let __mtObserverLocked = false;

const observer = new MutationObserver((mutations) => {

    if (__mtObserverLocked) return;

    __mtObserverLocked = true;

    requestAnimationFrame(() => {

        for (const m of mutations) {

            for (const node of m.addedNodes) {

                if (!(node instanceof HTMLElement)) continue;

                if (node.hasAttribute("data-action-container")) {

                    // ✅ DO NOT RESET STATE
                    renderContainer(node);
                    continue;
                }

                const targets = node.querySelectorAll
                    ? node.querySelectorAll("[data-action-container]")
                    : [];

                targets.forEach(n => {
                    if (!n.__mtRendered){
                        renderContainer(n);
                    }
                });
            }
        }

        __mtObserverLocked = false;

    });

});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

/* ============================================================
   🔄 LIVE UPDATE (SSE / DISPATCH)
============================================================ */

document.addEventListener("mt:license-updated", onLicenseUpdate);

/* ============================================================
   🔁 HYDRATE ALL
============================================================ */

function hydrate(){

    document.querySelectorAll("[data-action-container]")
        .forEach(container => {
            renderContainer(container);
        });
}



/* ============================================================
   🎯 RENDER CONTAINER (SAFE + IDEMPOTENT — FINAL)
============================================================ */
// [MT_PATCH_RENDER_DEADLOCK_FIX_V5_HARD]

// ============================================================
// 🎯 RENDER CONTAINER (DEADLOCK-FREE FINAL)
// ============================================================

function renderContainer(container){

    if (!(container instanceof HTMLElement)) return;

    const licenseId = safeLicense(
        container.getAttribute("data-license-id")
    );

    let raw = container.getAttribute("data-contract");
    if (raw === "") raw = null;

    if (!licenseId){
        return renderFallback(container);
    }

    /* ============================================================
       📡 CONTRACT MISSING → REQUEST (NON-BLOCKING)
    ============================================================ */

    if (!raw || raw === "null" || raw === "undefined") {

        if (!container.__mtContractRequested){

            container.__mtContractRequested = true;

            document.dispatchEvent(new CustomEvent("mt:contract-request", {
                detail: { license: licenseId }
            }));
        }

        // 🔥 DO NOT EXIT SILENTLY → SHOW LOADING
        if (!container.__mtRendered){
            renderFallback(container, licenseId);
        }

        return;
    }

    /* ============================================================
       🔐 APPLY NORMALIZED PARSE (PRIMARY)
    ============================================================ */

    let contract = normalizeRawContract(raw);

    if (!contract){

        console.warn("[MT] contract parse failed — fallback", licenseId);

        if (!container.__mtRendered){
            renderFallback(container, licenseId);
        }

        return;
    }

    /* ============================================================
       🔒 STRICT CONTRACT VALIDATION
    ============================================================ */

    if (
        !contract ||
        !Array.isArray(contract.allowed_actions) ||
        typeof contract.meta !== "object"
    ){
        console.warn("[MT] invalid contract shape — preserving UI", licenseId);
        return;
    }

    /* ============================================================
       🔁 MT_PATCH_RENDERER_CONTRACT_NORMALIZATION_V8_FINAL
       - Single normalization path
       - Strict idempotency
       - No silent failure
       - No double parsing ambiguity
    ============================================================ */

    if (container.__mtUpdateScheduled === true) return;

    container.__mtUpdateScheduled = true;

    requestAnimationFrame(() => {

        container.__mtUpdateScheduled = false;

        const latestRaw = container.getAttribute("data-contract");
        if (!latestRaw) return;

        const parsed = normalizeRawContract(latestRaw);

        if (!parsed){
            console.warn("[MT] contract parse failed (latest)", licenseId);
            return;
        }

        if (
            !Array.isArray(parsed.allowed_actions) ||
            typeof parsed.meta !== "object"
        ){
            console.warn("[MT] invalid contract shape (latest)", licenseId);
            return;
        }

        const cacheKey = latestRaw;

        if (container.__mtContractCache === cacheKey){
            return;
        }

        container.replaceChildren();

        build(container, licenseId, parsed);

        if (container.children.length === 0){
            console.warn("[MT] prevented empty build", licenseId);
            return;
        }

        container.setAttribute(
            "data-contract-version",
            parsed.version
                ? String(parsed.version)
                : String(Date.now())
        );

        container.__mtRendered = true;
        container.__mtContractCache = cacheKey;
    });
}

/* ============================================================
   🧩 BUILD ACTIONS (STRICT CONTRACT ONLY)
============================================================ */

function build(container, licenseId, contract){

    /* ============================================================
       🎨 ENTERPRISE UX SPACING ALIGNMENT (SECURE)
       - Force container display-flex and gap spacing to avoid clustering
    ============================================================ */
    container.style.display = "flex";
    container.style.flexWrap = "wrap";
    container.style.gap = "6px";
    container.style.alignItems = "center";

    const allowed = Array.isArray(contract.allowed_actions)
        ? contract.allowed_actions
        : [];

    const meta = (contract.meta && typeof contract.meta === "object")
        ? contract.meta
        : {};

    allowed.forEach(action => {

        const safeAct = safeAction(action);
        if (!safeAct) return;

        // 🔥 SAFE META ACCESS (NO HARD DEPENDENCY)
        const m = (meta[safeAct] && typeof meta[safeAct] === "object")
            ? meta[safeAct]
            : {};

        /* 🔒 FULL SAFE EXTRACTION (NO UNDEFINED LEAKS) */
        // [MT_PATCH_LABEL_COLOR_FIX_V1]

        const labelSafe = formatLabel(
            safeStr(m.label || safeAct)
        );

        const dispatcherSafe = safeAction(m.action || safeAct);

        const normalized = safeAct
            .toLowerCase()
            .replace(/-/g, "_");

        /* ============================================================
           🔒 MT_PATCH_BACKEND_COLOR_AUTHORITY_V1
           - Backend is primary source
           - Frontend fallback ONLY if missing
        ============================================================ */

        const colorSafe = safeColor(
            m.color || '#334155'
        );

        const confirmSafe = !!m.confirm;
        /* ===== MT_PATCH_CONTRACT_STATE_UI_V1 ===== */

        /* ============================================================
           🔒 MT_PATCH_STRICT_CONTRACT_STATE_V1
           - Backend must explicitly control state
           - No frontend inference
        ============================================================ */

        const disabledSafe = m.disabled === true;

        /* 🚫 HARD GUARD */
        if (!dispatcherSafe) return;

        const btn = createBtn(
            labelSafe,
            dispatcherSafe,
            licenseId,
            colorSafe,
            confirmSafe,
            disabledSafe
        );

        /* 🔒 NULL SAFE APPEND */
        if (btn) {
            container.appendChild(btn);
        }
    });
}

/* ============================================================
   🔘 BUTTON FACTORY (XSS SAFE)
============================================================ */

function createBtn(label, action, licenseId, color, confirm, disabled){

    const btn = document.createElement("button");

    btn.className = "mt-btn mt-btn-sm";
    btn.textContent = safeStr(label);

    btn.style.background = safeColor(color);
    btn.style.color = "#fff";

    const safeAct = safeAction(action);
    const safeLic = safeLicense(licenseId);

    if (!safeAct || !safeLic) return null;

    btn.dataset.mtAction = safeAct;
    btn.dataset.action   = safeAct;
    btn.dataset.license  = safeLic;
    btn.dataset.contract = "1";

    if (disabled){
        btn.disabled = true;
        btn.style.pointerEvents = "none";
        btn.style.opacity = "0.5";
    } else {
        btn.disabled = false;
        btn.style.pointerEvents = "auto";
        btn.style.opacity = "1";
    }

    if (confirm){
        btn.dataset.confirm = "true";
    }

    return btn;
}

/* ============================================================
   🛟 FALLBACK (NEVER EMPTY)
============================================================ */
/* ===== MT_PATCH_FALLBACK_NO_WIPE_V7_CRITICAL ===== */

function renderFallback(container){

    if (!(container instanceof HTMLElement)) {
        return;
    }

    if (container.__mtFallbackRendered === true) {
        return;
    }

    container.__mtFallbackRendered = true;

    const wrap = document.createElement('span');

    wrap.className = 'mt-contract-loading';

    wrap.textContent = 'Loading…';

    container.replaceChildren(wrap);
}

/* ============================================================
   🎨 UI NORMALIZERS (NON-BUSINESS SAFE)
============================================================ */

function formatLabel(v){
    const s = safeStr(v).replace(/[_\-]+/g, " ").trim();
    return s.replace(/\b\w/g, c => c.toUpperCase());
}

/* ============================================================
   🔄 LIVE UPDATE HANDLER (SAFE + TARGETED)
============================================================ */

function onLicenseUpdate(e){

    const detail = e?.detail;
    if (!detail || typeof detail !== "object") return;

    const license = safeLicense(detail.license);
    if (!license) return;

    const allowed = Array.isArray(detail.allowed_actions)
        ? detail.allowed_actions
        : [];

    const meta = (detail.meta && typeof detail.meta === "object")
        ? detail.meta
        : {};

    document
        .querySelectorAll("[data-action-container]")
        .forEach(container => {

            const id = safeLicense(
                container.getAttribute("data-license-id")
            );

            if (id !== license) return;

            // [MT_RENDERER_NO_CONTRACT_WRITE_V1]

            // 🔒 DO NOT WRITE CONTRACT HERE
            // Forward update to contract layer (SSOT)

            document.dispatchEvent(new CustomEvent("mt:apply-contract", {
                detail: {
                    license: license,
                    allowed_actions: allowed,
                    meta: meta
                }
            }));

            if (container.__mtUpdateScheduled === true) return;

            container.__mtUpdateScheduled = true;

            requestAnimationFrame(() => {

                container.__mtUpdateScheduled = false;
                renderContainer(container);
            });
        });
}

document.addEventListener("mt:force-refresh", hydrate);

if (!window.__mtActionRenderer){
    Object.defineProperty(window, "__mtActionRenderer", {
        value: Object.freeze({
            refreshAll: hydrate
        }),
        writable: false
    });
}

})();