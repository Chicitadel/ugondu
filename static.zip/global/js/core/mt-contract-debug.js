/* =========================================================
   [MT_DEBUG_OVERLAY_V3_STABLE_PATCH]
   FIXED: No infinite loop / No UI blocking
========================================================= */

(function(){

"use strict";

if (window.__mtDebugOverlay) return;
window.__mtDebugOverlay = true;

/* =========================================================
   ROOT
========================================================= */

const root = document.createElement("div");
root.setAttribute("data-mt-debug-root", "1");

root.style.position = "fixed";
root.style.bottom = "10px";
root.style.right = "10px";
root.style.zIndex = "999999";
root.style.fontFamily = "monospace";

document.body.appendChild(root);

/* =========================================================
   PANEL
========================================================= */

const panel = document.createElement("div");

panel.style.background = "#020617";
panel.style.color = "#e2e8f0";
panel.style.fontSize = "11px";
panel.style.padding = "10px";
panel.style.borderRadius = "10px";
panel.style.width = "340px";
panel.style.maxHeight = "420px";
panel.style.overflow = "auto";
panel.style.boxShadow = "0 0 0 1px #1e293b";

root.appendChild(panel);

/* =========================================================
   HEADER
========================================================= */

const header = document.createElement("div");
header.style.display = "flex";
header.style.justifyContent = "space-between";
header.style.marginBottom = "6px";

panel.appendChild(header);

header.innerHTML = `
<b style="color:#38bdf8">MT DEBUG</b>
<div>
<button id="mt-min">_</button>
<button id="mt-copy">⧉</button>
</div>
`;

const content = document.createElement("div");
panel.appendChild(content);

/* =========================================================
   CONTROLS
========================================================= */

let minimized = false;

header.querySelector("#mt-min").onclick = () => {
    minimized = !minimized;
    content.style.display = minimized ? "none" : "block";
};

header.querySelector("#mt-copy").onclick = () => {
    navigator.clipboard.writeText(content.innerText || "");
};

/* =========================================================
   SAFE HELPERS
========================================================= */

function safe(v){ return v || "-"; }

function getContract(container){
    try {
        return JSON.parse(container.getAttribute("data-contract") || "{}");
    } catch {
        return null;
    }
}

/* =========================================================
   RENDER LOCK (CRITICAL FIX)
========================================================= */

let __mtAnalyzing = false;
let __mtScheduled = false;

/* =========================================================
   ANALYZE (SAFE)
========================================================= */

function analyze(){

    if (__mtAnalyzing) return;
    __mtAnalyzing = true;

    try {

        let html = "";

        const rows = document.querySelectorAll(
            "[data-action-container][data-license-id]"
        );

        rows.forEach(row => {

            const license = row.getAttribute("data-license-id");

            const container = row;
            const buttons = container
                ? container.querySelectorAll("button[data-action]")
                : [];

            const contract = container ? getContract(container) : null;

            const version = container?.getAttribute("data-contract-version");

            let issues = [];

            if (!container) issues.push("❌ no container");
            if (!contract) issues.push("❌ invalid JSON");
            if (!version) issues.push("⚠ no version");

            if (container && buttons.length === 0){
                issues.push("🔥 buttons missing");
            }

            html += `
            <div style="margin-bottom:6px;padding:6px;border:1px solid #1e293b;border-radius:6px;">
                <b>${license}</b><br>
                actions: ${buttons.length}<br>
                version: ${safe(version)}<br>
                ${
                    issues.length
                    ? `<span style="color:#f87171">${issues.join("<br>")}</span>`
                    : `<span style="color:#4ade80">✔ OK</span>`
                }
            </div>`;
        });

        /* 🔒 SAFE UPDATE (NO MUTATION LOOP) */
        if (content.innerHTML !== html){
            content.innerHTML = html;
        }

    } finally {
        __mtAnalyzing = false;
    }
}

/* =========================================================
   DEBOUNCED SCHEDULER
========================================================= */

function scheduleAnalyze(){

    if (__mtScheduled) return;
    __mtScheduled = true;

    requestAnimationFrame(() => {
        __mtScheduled = false;
        analyze();
    });
}

/* =========================================================
   MUTATION OBSERVER (SAFE FILTER)
========================================================= */

const observer = new MutationObserver(mutations => {

    for (const m of mutations){

        /* 🔒 IGNORE DEBUG PANEL CHANGES */
        if (m.target.closest?.("[data-mt-debug-root]")) continue;

        scheduleAnalyze();
        break;
    }

});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

/* =========================================================
   EVENTS
========================================================= */

[
    "mt:apply-contract",
    "mt:contract-request",
    "mt:force-refresh",
    "mt:license-updated"
].forEach(evt => {
    document.addEventListener(evt, scheduleAnalyze);
});

/* =========================================================
   LIGHT INTERVAL (SAFE)
========================================================= */

setInterval(scheduleAnalyze, 2000); // reduced load

/* =========================================================
   DUPLICATE SCRIPT CHECK
========================================================= */

(function(){

    const seen = new Map();

    document.querySelectorAll("script[src]").forEach(s => {
        const src = s.getAttribute("src");
        seen.set(src, (seen.get(src) || 0) + 1);
    });

    seen.forEach((count, src) => {
        if (count > 1){
            console.warn("[MT DEBUG] duplicate:", src, "x", count);
        }
    });

})();

})();