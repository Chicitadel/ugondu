/**
 * Mandatag
 * Modal Activation Renderer — Backend Contract Driven UI (SECURE)
 *
 * File: mt-modal-activation.js
 * Location: /public_html/Assets/core/
 *
 * [MT_MODAL_ACTIVATION_ENGINE_V3_FINAL]
 * Guarantees:
 * - Zero frontend business logic
 * - Backend contract is single source of truth
 * - XSS hardened (strict sanitization)
 * - No innerHTML injection
 * - Dispatcher-safe buttons
 * - Live filtering (safe)
 * - Deterministic rendering
 *
 * © Air Roofers SAS
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 * --------------------------------------------------------------------
 */

(function () {

    "use strict";

    /* ============================================================
       🔒 SECURITY HELPERS
    ============================================================ */

    function safeStr(v) {
        return typeof v === "string" ? v : "";
    }

    function safeLicense(v) {
        return /^[a-zA-Z0-9._:-]+$/.test(v) ? v : "";
    }

    function safeAction(v) {
        return /^[a-z0-9\-_]+$/i.test(v) ? v : "";
    }

    function safeColor(v) {
        return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v) ? v : "#334155";
    }

    // [MT_PATCH_STATE_FORMATTER_V2_UPPERCASE]
    // 🔒 Presentation-only (NO business logic)
    function formatStateLabel(v) {

        const s = safeStr(v).trim();

        if (!s) return "";

        return s.toUpperCase();
    }

    /* ============================================================
       STATE
    ============================================================ */

    let DATA = [];

    /* ============================================================
       DOM RESOLUTION (SAFE — ON DEMAND)
    ============================================================ */

    function getBody() {
        return document.getElementById("mt-license-table-body");
    }

    /* ============================================================
       INIT DATA (SAFE)
    ============================================================ */

    function loadData() {

        const body = getBody();
        if (!body) return false;

        const raw = body.dataset.mtSource;
        if (!raw) return false;

        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                DATA = parsed;
                return true;
            }
        } catch { }

        renderEmpty("Invalid data");
        return false;
    }

    /* ============================================================
       RENDER CORE
    ============================================================ */

    function render(list) {

        const body = getBody();
        if (!body) return;

        body.replaceChildren();

        if (!Array.isArray(list) || list.length === 0) {
            renderEmpty("No results");
            return;
        }

        list.forEach(row => {

            const license = safeLicense(row.id);
            if (!license) return;

            const tr = document.createElement("tr");

            /* ---------- CHECKBOX ---------- */
            const tdCheck = document.createElement("td");
            const cb = document.createElement("input");
            cb.type = "checkbox";

            /* 🔥 CRITICAL: bulk UI contract binding */
            cb.setAttribute("data-license-checkbox", "1");
            cb.value = license;

            /* 🔒 keep existing attribute for compatibility */
            cb.dataset.license = license;
            tdCheck.appendChild(cb);

            /* ---------- LICENSE ---------- */
            const tdLicense = document.createElement("td");
            tdLicense.textContent = license;

            /* ---------- STATE ---------- */
            const tdState = document.createElement("td");
            tdState.textContent = formatStateLabel(row.state);

            /* ---------- ACTIVATIONS ---------- */
            const tdAct = document.createElement("td");
            tdAct.textContent = (row.meta && row.meta.activations !== undefined)
                ? row.meta.activations
                : "0";

            /* ---------- ACTIONS (CONTRACT-DRIVEN) ---------- */
            const tdActions = document.createElement("td");

            // [MT_PATCH_MODAL_RENDER_RESET_V1]

            tdActions.__mtRendered = false;
            tdActions.__mtContractCache = null;
            tdActions.__mtUpdateScheduled = false;
            tdActions.__mtContractRequested = false;

            /* 🔒 STRICT: renderer owns ALL buttons */
            /* ===== MT_PATCH_MODAL_CONTRACT_BOOTSTRAP_V1 ===== */

            tdActions.setAttribute("data-action-container", "1");
            tdActions.setAttribute("data-license-id", license);

            /* 🔒 OPTIONAL: layout only (no logic) */
            tdActions.style.display = "flex";
            tdActions.style.flexWrap = "wrap";
            tdActions.style.gap = "8px";

            tr.appendChild(tdCheck);
            tr.appendChild(tdLicense);
            tr.appendChild(tdState);
            tr.appendChild(tdAct);
            tr.appendChild(tdActions);

            getBody()?.appendChild(tr);
        });
    }

    /* ============================================================
       EMPTY STATE
    ============================================================ */
    /* ===== MT_PATCH_MODAL_RENDER_EMPTY_SAFE_V2 ===== */

    function renderEmpty(msg) {

        const body = getBody();
        if (!body) return;

        /* 🔒 NEVER use innerHTML */

        /* 🔒 SAFE CLEAR */
        while (body.firstChild) {
            body.removeChild(body.firstChild);
        }

        const tr = document.createElement("tr");
        const td = document.createElement("td");

        td.colSpan = 5;
        td.className = "mt-empty";
        td.textContent = safeStr(msg);

        tr.appendChild(td);
        body.appendChild(tr);
    }

    /* ============================================================
       FILTER ENGINE
    ============================================================ */

    function applyFilters() {

        const searchInput = document.getElementById("mt-search");
        const stateFilter = document.getElementById("mt-filter-state");

        let list = [...DATA]; // 🔥 copy

        const q = safeStr(searchInput?.value).toLowerCase();
        const state = safeStr(stateFilter?.value);

        if (q) {
            list = list.filter(r =>
                safeStr(r.id).toLowerCase().includes(q)
            );
        }

        if (state) {
            list = list.filter(r =>
                safeStr(r.state_raw) === state
            );
        }

        render(list);
    }

    /* ============================================================
       EVENTS
    ============================================================ */

    document.addEventListener("input", e => {
        if (e.target?.id === "mt-search") applyFilters();
    });

    document.addEventListener("change", e => {
        if (e.target?.id === "mt-filter-state") applyFilters();
    });

    /* ============================================================
       🔥 FILTER UX CONTROLS (SAFE — NO CONTRACT IMPACT)
       [MT_PATCH_FILTER_BEHAVIOR_V2]
    ============================================================ */

    (function () {

        const searchInput = document.getElementById("mt-search");
        const clearBtn = document.getElementById("mt-search-clear");
        const resetBtn = document.getElementById("mt-filter-reset");
        const stateFilter = document.getElementById("mt-filter-state");

        if (!searchInput) return;

        /* ============================================================
           🔍 CLEAR BUTTON VISIBILITY
        ============================================================ */

        function toggleClear() {
            if (!clearBtn) return;
            clearBtn.style.display = searchInput.value ? "block" : "none";
        }

        searchInput.addEventListener("input", toggleClear);

        /* ============================================================
           ❌ CLEAR SEARCH
        ============================================================ */

        clearBtn?.addEventListener("click", () => {
            searchInput.value = "";
            toggleClear();
            applyFilters();
        });

        /* ============================================================
           🔄 FULL RESET
        ============================================================ */

        resetBtn?.addEventListener("click", () => {

            searchInput.value = "";
            if (stateFilter) stateFilter.value = "";

            toggleClear();

            applyFilters();
        });

        /* ============================================================
           INIT STATE
        ============================================================ */

        toggleClear();

    })();

    /* ============================================================
       🔥 MODAL OPEN HOOK (CRITICAL)
    ============================================================ */

    document.addEventListener("mt:modal-opened", function (e) {

        if (e?.detail?.id !== "activation-modal") return;

        if (!loadData()) return;

        applyFilters();
    });

    /* ============================================================
       🔄 LIVE CONTRACT SYNC
    ============================================================ */

    document.addEventListener("mt:license-updated", function (e) {

        const detail = e?.detail;
        if (!detail || typeof detail !== "object") return;

        const license = safeLicense(detail.license);
        if (!license) return;

        // [MT_PATCH_MODAL_NO_FULL_RERENDER_V1]

        /* ============================================================
           🔒 UPDATE STATE ONLY — NO REBUILD
        ============================================================ */

        DATA = DATA.map(row => {

            if (safeLicense(row.id) !== license) return row;

            return {
                ...row,
                state: detail.state || row.state,
                state_raw: detail.state || row.state_raw
            };
        });

        /* ============================================================
           🔥 UPDATE ONLY VISIBLE ROW (NO DOM RESET)
        ============================================================ */

        // [MT_PATCH_LIVE_SYNC_REGEN_V2]
        // 🔒 Robust sync: target ALL tables that might contain this license
        const affectedRows = document.querySelectorAll(`tr[data-license-id="${license}"]`);

        affectedRows.forEach(row => {
            // Target specifically by data-column (hardened) or fallback to generic state badge
            const stateCell = row.querySelector('[data-column="state"]')
                || row.querySelector('[data-column="status"]')
                || row.querySelector('.badge[data-license-id]');

            if (stateCell) {
                stateCell.textContent = formatStateLabel(detail.state);
            }
        });

        /* ❌ DO NOT CALL applyFilters() */
    });


})();

