/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-core.js
 * Location: /public_html/Assets/core/
 * Purpose: Core runtime bootstrap, global state, plugin system foundation
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 55 — Core Runtime Hardening
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtCoreInitialized) return;
Object.defineProperty(window, "__mtCoreInitialized", {
    value: true,
    writable: false,
    configurable: false
});

/* =========================================================
   ENV DETECTION (STRICT)
========================================================= */

const HOST = location.hostname;

const ENV = Object.freeze({
    isLocal: HOST === "localhost" || HOST === "127.0.0.1",
    isProd: HOST === "license.airroofers.eu"
});

/* =========================================================
   TRANSPORT POLICY (FIXED)
========================================================= */

/**
 * Transport (WS/SSE) ONLY allowed in production backend context
 * Hot reload ONLY allowed in local
 */
Object.defineProperty(window, "__MT_DISABLE_TRANSPORT__", {
    value: !ENV.isProd,
    writable: false
});

/* =========================================================
   SAFE GLOBAL HELPER
========================================================= */

function safeGlobal(name, fallback){

    if (typeof window[name] === "undefined") {
        Object.defineProperty(window, name, {
            value: fallback,
            writable: true,
            configurable: true
        });
        return fallback;
    }

    return window[name];
}

const noop = function(){};

/* =========================================================
   CORE STATE ENGINE (REACTIVE BASE)
========================================================= */

const MT = {

    state: Object.create(null),
    listeners: Object.create(null),

    setState(key, value){

        this.state[key] = value;

        const subs = this.listeners[key];
        if (!subs) return;

        for (let i = 0; i < subs.length; i++){
            try { subs[i](value); }
            catch(e){ console.warn("[MT] listener error", e); }
        }
    },

    getState(key){
        return this.state[key];
    },

    bind(key, fn){

        if (typeof fn !== "function") return;

        if (!this.listeners[key]) {
            this.listeners[key] = [];
        }

        this.listeners[key].push(fn);
    }

};

/* 🔓 CORE MUST REMAIN EXTENSIBLE (CRITICAL FOR REACTIVE + PLUGINS) */
// DO NOT freeze / seal / preventExtensions

/* EXPORT SAFELY (Allow extension, orchestrated freeze in mt-boot) */
window.MT = MT;

/* =========================================================
   COMMAND BUS (SAFE)
========================================================= */

Object.defineProperty(window, "MT_COMMAND_BUS", {
    value: Object.create(null),
    writable: false
});


/* =========================================================
   REQUIRED GLOBAL FALLBACKS (CONTROLLED)
========================================================= */

safeGlobal("showToast", (msg, ok)=>console.log(`[${ok?"OK":"ERR"}]`, msg));

safeGlobal("verifyUiIntegrity", async ()=>true);

safeGlobal("mtBindPasswordModule", noop);

safeGlobal("mtBindForm", function(){
    console.warn("[MT] mtBindForm fallback");
});

safeGlobal("deterministicRefresh", async ()=>location.reload());

/* =========================================================
   CRITICAL FIXES (YOUR ERROR)
========================================================= */

safeGlobal("monitorJwtExpiry", function(){
    
    let interval = null;
    const POLLING_INTERVAL = 20000; // 20 seconds for active balance

    const check = async () => {
        try {
            const resp = await fetch('/admin/api/session-status');
            if (!resp.ok) {
                if (resp.status === 401 || resp.status === 403) {
                     window.location.href = '/admin/login?timeout=1';
                }
                return;
            }
            
            const data = await resp.json();
            if (data.status !== 'authenticated') {
                clearInterval(interval);
                window.location.href = '/admin/login?timeout=1';
            }
        } catch (e) {
            // network issues or server down — don't force logout immediately
        }
    };
    
    interval = setInterval(check, POLLING_INTERVAL);
    
    // Initial check (slightly delayed for page stability)
    setTimeout(check, 3000);
});

safeGlobal("injectPulseStyles", noop);
safeGlobal("mtHealUI", noop);

/* =========================================================
   SAFE EXECUTION WRAPPER
========================================================= */

Object.defineProperty(window, "mtSafe", {
    value: function(fn){
        try { return fn(); }
        catch(e){ console.warn("[MT SAFE]", e); }
    },
    writable: false
});

/* =========================================================
   MT BOOTSTRAP ENGINE (MANDATORY CONTRACT)
   MT-PATCH-BOOT-ENGINE-001
========================================================= */

/* =========================================================
   MT-PATCH-BOOT-INTEGRATION-V1
   - Do NOT override MT_BOOT
   - Register core readiness instead
========================================================= */

(function registerCoreToBoot(){

    function signal(){

        if (window.MT_BOOT && typeof window.MT_BOOT.ready === "function") {
            window.MT_BOOT.ready("core");
        } else {
            setTimeout(signal, 25);
        }
    }

    signal();

})();

/* =========================================================
   DEBUG MODE
========================================================= */

if (!ENV.isProd) {
    console.log("[MT] Core initialized (DEV)");
}

})();