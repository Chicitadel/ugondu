// [MT_CONTRACT_APPLY_FULL_REPLACE_TCP_V3]
/**
 * Mandatag
 * UI Contract Layer — Single Source of UI Truth
 *
 * File: mt-contract-apply.js
 * Location: /public_html/Assets/core/
 *
 * MT CONTRACT CORE — TCP FINAL (STABLE)
 *
 * © Air Roofers SAS
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * --------------------------------------------------------------------
 */

// [MT_CONTRACT_APPLY_TCP_V5_DISPATCHER_COMPAT]

(function(){

"use strict";

/* ============================================================
   INIT GUARD
============================================================ */

if (window.__mtContractApply) return;

Object.defineProperty(window, "__mtContractApply", {
    value: true,
    writable: false
});

/* ============================================================
   🔒 SECURITY HELPERS
============================================================ */

function safeStr(v){
    return typeof v === "string" ? v : "";
}

/* ===== MT_PATCH_CANONICAL_CONTRACT_SERIALIZER_V1 ===== */
function serializeContract(obj){
    try {
        // 🔒 STRICT JSON — NO FORMAT MUTATION
        return JSON.stringify(obj);
    } catch {
        return "{}";
    }
}

function safeLicense(v){
    return /^[a-zA-Z0-9._:-]+$/.test(v) ? v : "";
}

function safeAction(v){
    return /^[a-z0-9\-_]+$/i.test(v) ? v : "";
}

function safeColor(v){
    return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v) ? v : "#334155";
}

/* ============================================================
   🧪 CONTRACT NORMALIZER (CRITICAL FIX)
============================================================ */
/* ===== MT_PATCH_NORMALIZE_CONTRACT_SAFE_V2 ===== */

function normalizeContract(raw){

    if (!raw || typeof raw !== "object") return null;

    const license = safeLicense(raw.license);
    if (!license) return null;

    const allowed = Array.isArray(raw.allowed_actions)
        ? raw.allowed_actions.map(safeAction).filter(Boolean)
        : [];

    const metaRaw = (raw.meta && typeof raw.meta === "object")
        ? raw.meta
        : {};

    const meta = {};

    for (const key in metaRaw){

        const safeKey = safeAction(key);
        if (!safeKey) continue;

        const m = metaRaw[key];
        if (!m || typeof m !== "object") continue;

        const action = safeAction(m.action || safeKey);
        if (!action) continue;

        meta[safeKey] = {
            label: safeStr(m.label || safeKey),
            action: action,
            color: safeColor(m.color),
            confirm: !!m.confirm,
            disabled: !!m.disabled,
            enabled: m.enabled !== false
        };
    }

    /* 🔥 GUARANTEE INSPECT ONLY AFTER BOTH EXIST */
    if (!allowed.includes("inspect") && meta.inspect) {
        allowed.unshift("inspect");
    }

    return {
        license,
        state: safeStr(raw.state || ""),
        allowed_actions: allowed,
        meta
    };
}

/* ============================================================
   🚀 APPLY CONTRACT (CORE ENGINE)
============================================================ */
// [MT_PATCH_CONTRACT_APPLY_RENDER_FIX_V6]

function applyContract(raw){

    const contract = normalizeContract(raw);
    if (!contract) return;

    const safeContractJSON = serializeContract({

        license: contract.license,

        state: contract.state,

        version: contract.version || Date.now(),

        allowed_actions: contract.allowed_actions,

        meta: contract.meta
    });

    const containers = document.querySelectorAll(
        `[data-action-container][data-license-id="${contract.license}"]`
    );

    containers.forEach(container => {

        if (!(container instanceof HTMLElement)) return;

        const prev = container.getAttribute("data-contract");

        /* ========================================================
           🔥 ALWAYS WRITE CONTRACT (NO HARD LOCK)
        ======================================================== */

        /* ===== MT_PATCH_APPLY_CHANGE_DETECTION_V1 ===== */

        if (container.getAttribute("data-contract") === safeContractJSON){
            return; // 🔥 prevent render storm
        }

        container.setAttribute("data-contract", safeContractJSON);

        /* ========================================================
           🔁 FORCE RENDER RESET (CRITICAL FIX)
        ======================================================== */

        container.__mtRendered = false;
        container.__mtContractRequested = false;
        container.__mtFallbackRendered = false;

        /* ========================================================
           🔥 FORCE IMMEDIATE RENDER (NO WAIT)
        ======================================================== */

        if (window.__mtActionRenderer){
            window.__mtActionRenderer.refreshAll();
        }

        /* ========================================================
           🔥 STATE SYNC (ROW SAFE)
        ======================================================== */

        const row = container.closest('tr');

        if (row instanceof HTMLElement) {

            row.setAttribute(
                'data-license-id',
                contract.license
            );

            row.setAttribute(
                'data-license-state',
                contract.state || 'unknown'
            );

            /* ==========================================================
               🔥 MT_PATCH_TEXT_SYNC_V1
               Update visible state labels inside the row immediately.
            ========================================================== */
            const stateCells = row.querySelectorAll('[data-column="state"], [data-column="status"]');
            stateCells.forEach(cell => {
                // capitalize or format if needed, here we just use the raw state
                cell.textContent = (contract.state || 'unknown').toUpperCase();
            });
        }

    });

    /* ============================================================
       🔁 GLOBAL SYNC (UNCHANGED)
    ============================================================ */

    document.dispatchEvent(new CustomEvent("mt:contract-sync", {
        detail: contract
    }));

    console.debug("[MT CONTRACT] Applied", contract.license, contract.state);
}
/* ============================================================
   🔥 BACKWARD COMPATIBILITY (CRITICAL FIX)
============================================================ */

Object.defineProperty(window, "mtApplyBackendContract", {
    value: function(payload){
        applyContract(payload);
    },
    writable: false
});

/* ============================================================
   OPTIONAL VALIDATOR (DISPATCHER COMPAT)
============================================================ */

// 🔥 MT_PATCH_CONTRACT_VALIDATION_STRICT_V2 START

Object.defineProperty(window, "mtValidateContract", {
    value: function(c){

        if (!c || typeof c !== "object") return false;

        if (typeof c.license !== "string" || !c.license) return false;

        if (!Array.isArray(c.allowed_actions)) return false;

        if (!c.meta || typeof c.meta !== "object") return false;

        if (typeof c.state !== "string") return false;

        return true;
    },
    writable: false
});

// 🔥 MT_PATCH_CONTRACT_VALIDATION_STRICT_V2 END

/* ============================================================
   📡 EVENT INPUTS
============================================================ */

document.addEventListener("mt:apply-contract", e => {
    applyContract(e.detail || {});
});

document.addEventListener("mt:license-updated", e => {
    applyContract(e.detail || {});
});

document.addEventListener("mt:bulk-contract", e => {
    (Array.isArray(e.detail) ? e.detail : []).forEach(applyContract);
});

/* ============================================================
   DEBUG (LOCAL ONLY)
============================================================ */

if (location.hostname === "localhost"){
    window.__mtApplyContractDebug = applyContract;
}

})();