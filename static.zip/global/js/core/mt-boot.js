/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Organization: Air Roofers SAS
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-boot.js
 * Location: /public_html/Assets/core/
 * Purpose:
 *   Deterministic Admin Boot Orchestrator
 *
 * Responsibilities:
 *   - Safe sequential module loading
 *   - Script deduplication
 *   - Load failure containment
 *   - Sidebar integrity validation
 *   - Safe lifecycle cleanup
 *   - Controlled core freeze
 *
 * Guarantees:
 * - No duplicate script injection
 * - No race conditions
 * - No memory leaks
 * - Retry-safe loader
 * - Injection-safe execution
 * - Production hardened
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   SINGLETON GUARD
========================================================= */

if (window.MT_BOOT) return;

/* =========================================================
   INTERNAL STATE
========================================================= */

let __queue = Promise.resolve();
const __registry = new Map();
let __started = false;

/* =========================================================
   CONFIG
========================================================= */

const VERSION = window.__MT_ASSET_VERSION__ || "1.0.0";
const LOAD_TIMEOUT = 10000;

/* =========================================================
   SAFE SCRIPT LOADER (SEQUENTIAL + DEDUPE)
========================================================= */

function loadScript(src){

    const normalized = new URL(src, location.origin).pathname;

    if (__registry.has(normalized)) {
        return __registry.get(normalized);
    }

    const promise = __queue = __queue.then(()=>new Promise((resolve, reject)=>{

        const alreadyLoaded = Array.from(document.scripts).some(s=>{
            try {
                return new URL(s.src, location.origin).pathname === normalized;
            } catch {
                return false;
            }
        });

        if (alreadyLoaded) {
            console.debug("[MT_BOOT] script already loaded, skipping:", src);
            resolve();
            return;
        }

        const script = document.createElement("script");
        script.src = src + (src.includes("?") ? "&" : "?") + "v=" + VERSION;
        script.defer = true;

        const timeout = setTimeout(()=>{
            __registry.delete(normalized);
            reject(new Error("[MT_BOOT] Timeout: " + src));
        }, LOAD_TIMEOUT);

        script.onload = () => {
            clearTimeout(timeout);
            __registry.delete(normalized);
            resolve();
        };

        script.onerror = (err) => {
            clearTimeout(timeout);
            __registry.delete(normalized);
            reject(err);
        };

        document.head.appendChild(script);

    }));

    __registry.set(normalized, promise);

    return promise;
}

/* =========================================================
   SIDEBAR INTEGRITY CHECK
========================================================= */

function checkSidebar(){

    try {

        const sidebar = document.getElementById("sidebar");

        if (!sidebar) {
            console.warn("[MT_BOOT] Sidebar not found");
            return;
        }

        const hasMenu = sidebar.querySelectorAll(".menu-group, .submenu").length > 0;

        if (!hasMenu) {
            sidebar.setAttribute("data-mt-state", "error");
            console.error("[MT_BOOT] Sidebar integrity failure");
            return;
        }

        sidebar.setAttribute("data-mt-state", "ok");

    } catch(e){
        console.error("[MT_BOOT] Sidebar check failed", e);
    }
}

/* =========================================================
   SAFE CLEANUP (DEDUPED)
========================================================= */

function initCleanup(){

    let cleaned = false;

    function safeCleanup(){

        if (cleaned) return;
        cleaned = true;

        try {
            console.debug("[MT_BOOT] Cleanup executed");
        } catch(e){}
    }

    window.addEventListener("pagehide", safeCleanup);

    document.addEventListener("visibilitychange", function(){
        if (document.visibilityState === "hidden"){
            safeCleanup();
        }
    });

    // optional fallback (safe, non-blocking)
    window.addEventListener("beforeunload", safeCleanup);
}

/* =========================================================
   MODULE LOAD PIPELINE
========================================================= */

async function loadAdminModules(){
    // Use the global CDN paths for production stability
    const modulesRoot = "https://static.airroofers.eu/apps/governance-console/js/modules/";
    const globalRoot = "https://static.airroofers.eu/global/js/";

    await loadScript(modulesRoot + "password-module.js");
    await loadScript(modulesRoot + "dashboard-module.js");
    await loadScript(modulesRoot + "recovery-code.js");

    await new Promise(resolve => {
        let tries = 40;
        (function wait(){
            if (window.MT?.dispatcher || window.mtDispatcher) {
                return resolve();
            }
            if (--tries <= 0) {
                console.error("[MT_BOOT] Dispatcher missing after wait");
                return resolve();
            }
            setTimeout(wait, 25);
        })();
    });

    await loadScript(modulesRoot + "email-queue.js");
    await loadScript(globalRoot + "navigation_intelligence.js");
}


/* =========================================================
   START (PUBLIC API)
========================================================= */

async function start(config){

    if (__started) {
        console.debug("[MT_BOOT] Already started");
        return;
    }

    if (!config || config.context !== "admin") {
        console.warn("[MT_BOOT] Invalid context");
        return;
    }

    __started = true;

    try {

        /* ---------------------------
           LOAD MODULES
        --------------------------- */

        await loadAdminModules();

        /* ---------------------------
           POST-LOAD STABILIZATION
        --------------------------- */

        checkSidebar();
        setTimeout(checkSidebar, 300);

        initCleanup();

        // allow microtasks to complete before freeze
        setTimeout(() => {
            if (window.MT && Object.isExtensible(window.MT)) {
                try {
                    Object.freeze(window.MT);
                    console.debug("[MT_BOOT] Core frozen");
                } catch(e){
                    console.warn("[MT_BOOT] Freeze failed", e);
                }
            }
        }, 50);

        console.debug("[MT_BOOT] Admin boot complete", config);

    } catch(e){

        console.error("[MT_BOOT] Boot failure", e);

    }
}

/* =========================================================
   BOOT STATE TRACKING (UNIFIED)
========================================================= */

const __readyState = {
    core: false,
    policy: false,
    reactive: false,
    dispatcher: false
};

function markReady(name){

    if (!(__readyState.hasOwnProperty(name))) {
        console.warn("[MT_BOOT] Unknown ready signal:", name);
        return;
    }

    __readyState[name] = true;

    console.debug("[MT_BOOT] ready:", name);

    checkReady();
}

function checkReady(){

    if (
        __readyState.core &&
        __readyState.policy &&
        __readyState.reactive &&
        __readyState.dispatcher
    ){
        document.documentElement.setAttribute("data-mt", "ready");
        console.log("[MT_BOOT] SYSTEM READY");
    }
}

/* =========================================================
   EXPORT
========================================================= */

window.MT_BOOT = Object.freeze({
    start,
    ready: markReady
});

})();