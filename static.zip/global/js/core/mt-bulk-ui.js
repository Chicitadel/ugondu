/**
 * MT-BULK-UI — CONTRACT DRIVEN (TRUE FINAL)
 *
 * Guarantees:
 * - ZERO hardcoding of action names
 * - Backend is the ONLY source of truth
 * - Button → action resolution (dynamic)
 * - Modal-scoped execution
 * - No UI bleed / overlay bugs
 * - Live contract sync (no reload)
 */

(function(){

"use strict";

if (!window.mtSelection){
    window.mtSelection = new Set();
}

if (window.__mtBulkUI) return;

/* =====================================================
   SELECTORS
===================================================== */

const SELECTOR = {
    checkbox: "[data-license-checkbox]",
    row: "[data-license-id]",
    master: "[data-bulk-master]",
    select: "#mt-bulk-action-select",
    apply: "#mt-bulk-apply"
};

/* =====================================================
   STATE
===================================================== */

let contractReady = false;

/* =====================================================
   BULK EXECUTION TRACKER
===================================================== */

const mtBulkExec = {

    total: 0,
    success: 0,
    failed: 0,
    action: null,
    active: false,
    seen: new Set(),

    start(ids, action){
        this.total = ids.length;
        this.success = 0;
        this.failed = 0;
        this.action = action;
        this.active = true;
        this.seen.clear();

        renderBulkProgress(this);
    },

    resolve(id, ok){

        if (!this.active) return;
        if (this.seen.has(id)) return; // 🔒 prevent double count

        this.seen.add(id);

        if (ok) this.success++;
        else this.failed++;

        renderBulkProgress(this);

        if ((this.success + this.failed) >= this.total){
            this.active = false;
            renderBulkFinal(this);
        }
    }
};

mtBulkExec._timer && clearTimeout(mtBulkExec._timer);

mtBulkExec._timer = setTimeout(() => {

    if (!mtBulkExec.active) return;

    mtBulkExec.failed = mtBulkExec.total - mtBulkExec.success;
    mtBulkExec.active = false;

    renderBulkFinal(mtBulkExec);

}, 6000);

/* =====================================================
   SCOPE (STRICT MODAL BOUNDARY)
===================================================== */

function getScope(){

    const modal = document.getElementById("activation-modal");

    if (modal && !modal.classList.contains("hidden")){
        return modal;
    }

    return document;
}

// [MT_PATCH_NOTE]
// Action buttons are rendered AFTER DOM insertion via renderRowActions()
// [MT_PATCH_RENDER_ROW_SAFE_V2]
function renderRow(l){

    const safeMeta = encodeURIComponent(JSON.stringify(l.meta || {}));
    const safeAllowed = encodeURIComponent(JSON.stringify(l.allowed_actions || []));

    return `
    <tr data-license-id="${l.id}"
        data-license-state="${l.state}"
        data-meta="${safeMeta}"
        data-allowed-actions="${safeAllowed}">

        <td>
            <input type="checkbox" data-license-checkbox value="${l.id}">
        </td>

        <td>${l.id}</td>

        <td>
            <span class="badge">${l.state}</span>
        </td>

        <td>—</td>

        <td 
          data-action-container
          data-license-id="${l.id}">
        </td>
    </tr>`;
}

/* =====================================================
   CORE HELPERS
===================================================== */

function getRow(id){
    return getScope().querySelector(`[data-license-id="${id}"]`);
}

// [MT_PATCH_ALLOWED_STRICT_CONTRACT_ONLY_V2]
function getAllowedForLicense(id){

    const row = getRow(id);
    if (!row) return [];

    const container = row.querySelector("[data-action-container]");
    if (!container) return [];

    try {

        const raw = container.getAttribute("data-contract");
        if (!raw) return [];

        const parsed = JSON.parse(raw);

        if (!Array.isArray(parsed.allowed_actions)){
            return [];
        }

        return parsed.allowed_actions;

    } catch {

        return [];
    }
}

/* =====================================================
   SELECTION ELIGIBILITY
===================================================== */

function isSelectable(id){

    const actions = getAllowedForLicense(id);

    // 🔥 DO NOT depend on contractReady
    if (!Array.isArray(actions)) return false;

    // 🔥 selectable if backend provided actions
    return actions.length > 0;
}

/* =====================================================
   ENFORCE CHECKBOX STATE (BACKEND DRIVEN)
===================================================== */

function enforceSelectableState(){

    const scope = getScope();

    scope.querySelectorAll(SELECTOR.checkbox).forEach(cb => {

        const id = cb.value;
        if (!id) return;

        const actions = getAllowedForLicense(id);

        // 🔥 skip rows not hydrated yet (do NOT disable)
        if (!Array.isArray(actions) || actions.length === 0){
            cb.disabled = false;
            return;
        }

        const allowed = isSelectable(id);

        cb.disabled = !allowed;

        if (!allowed){
            cb.checked = false;
        }

        /* 🔒 isolate styling to checkbox cell only */
        const row = getRow(id);
        if (row){
            const cell = row.querySelector("td:first-child");
            if (cell){
                cell.style.opacity = allowed ? "1" : "0.35";
            }
        }

    });
}

/* =====================================================
   SELECTED IDS
===================================================== */

// [MT_PATCH_SELECTION_SOURCE_UNIFICATION_V3_STABLE]
function getSelected(){

    const scope = getScope();

    return Array.from(scope.querySelectorAll(SELECTOR.checkbox))
        .filter(cb => cb.checked && cb.value)
        .map(cb => cb.value);
}

/* =====================================================
   BULK BUTTON STATE (STRICT CONTRACT)
===================================================== */

// [MT_PATCH_UPDATE_BULK_STABLE_V2]
function updateBulk(){

    const scope = getScope();

    const applyBtn = scope.querySelector(SELECTOR.apply);
    const select = scope.querySelector(SELECTOR.select);

    if (!applyBtn || !select) return;

    const selected = getSelected();

    renderBulkActions();

    if (!selected.length){
        applyBtn.disabled = true;
        select.disabled = true;
        return;
    }

    // 🔥 enable select even before intersection (UX fix)
    select.disabled = false;

    const hasAction = !!select.value;

    applyBtn.disabled = !hasAction;

    syncMasterCheckbox();
}


// [MT_PATCH_INTERSECTION_DEFERRED_V3]
function getBulkIntersection(ids){

    if (!ids.length) return [];

    let intersection = null;

    for (const id of ids){

        const actions = getAllowedForLicense(id);

        // 🔥 DEFER until contract is ready
        if (!Array.isArray(actions) || actions.length === 0){
            continue;
        }

        if (!intersection){
            intersection = new Set(actions);
        } else {
            intersection = new Set(
                actions.filter(a => intersection.has(a))
            );
        }
    }

    return intersection ? Array.from(intersection) : [];
}

// [MT_PATCH_DECODE_META_V1]
function getActionMeta(action, id){

    const row = getRow(id);
    if (!row) return null;

    const container = row.querySelector("[data-action-container]");
    if (!container) return null;

    try {

        const raw = container.getAttribute("data-contract");
        if (!raw) return null;

        const parsed = JSON.parse(raw);

        if (!parsed.meta || typeof parsed.meta !== "object"){
            return null;
        }

        return parsed.meta[action] || null;

    } catch {

        return null;
    }
}

// [MT_PATCH_GET_ALL_META_V1]
function getAllMeta(id){

    const row = getRow(id);
    if (!row) return {};

    try {
        const raw = row.getAttribute("data-meta");
        if (!raw) return {};

        return JSON.parse(decodeURIComponent(raw));
    } catch {
        return {};
    }
}

// [MT_PATCH_RENDER_ACTIONS_SINGLE_SOURCE_V2]
// [MT_PATCH_RENDER_ACTIONS_PASSIVE_MODE_V1]
function renderRowActions(id){

    /*
    |--------------------------------------------------------------------------
    | 🔒 PASSIVE MODE
    |--------------------------------------------------------------------------
    | mt-action-renderer.js is the ONLY renderer allowed
    | to mutate [data-action-container].
    |--------------------------------------------------------------------------
    */

    return;
}

function renderBulkActions(){

    const scope = getScope();
    const select = scope.querySelector(SELECTOR.select);
    if (!select) return;

    // 🔒 safe clear
    while (select.firstChild){
        select.removeChild(select.firstChild);
    }

    const defaultOpt = document.createElement("option");
    defaultOpt.value = "";
    defaultOpt.textContent = "Bulk Actions";
    select.appendChild(defaultOpt);

    const selected = getSelected();

    if (!selected.length){
        select.disabled = true;
        return;
    }

    const intersection = getBulkIntersection(selected);
    // [MT_PATCH_ALLOW_PENDING_CONTRACT_V1]
    if (!intersection.length){

        // 🔥 allow pending state instead of hard disable
        select.disabled = true;

        const opt = document.createElement("option");
        opt.value = "";
        opt.textContent = "Loading actions...";
        select.appendChild(opt);

        return;
    }

    const refId = selected[0];

    intersection.forEach(actionKey => {

        const meta = getActionMeta(actionKey, refId);

        const dispatcherAction = meta?.action || actionKey;
        const label = meta?.label || actionKey;

        const opt = document.createElement("option");
        opt.value = dispatcherAction;
        opt.textContent = label;

        select.appendChild(opt);
    });

    /* 🔥 AUTO-SELECT (ONCE, deterministic) */
    if (select.options.length > 1 && !select.value){
        select.selectedIndex = 1;
    }

    select.disabled = select.options.length <= 1;
}

function renderBulkProgress(state){

    const scope = getScope();

    let node = scope.querySelector("[data-bulk-progress]");

    if (!node){
        node = document.createElement("div");
        node.setAttribute("data-bulk-progress", "1");

        node.style.marginTop = "8px";
        node.style.fontSize = "13px";
        node.style.color = "#38bdf8";

        const applyBtn = scope.querySelector(SELECTOR.apply);
        if (applyBtn){
            applyBtn.parentNode.appendChild(node);
        }
    }

    node.textContent =
        `Processing ${state.success + state.failed}/${state.total}...`;
}

function renderBulkFinal(state){

    const scope = getScope();

    let node = scope.querySelector("[data-bulk-result]");

    if (!node){
        node = document.createElement("div");
        node.setAttribute("data-bulk-result", "1");

        node.style.marginTop = "8px";
        node.style.fontSize = "13px";

        const applyBtn = scope.querySelector(SELECTOR.apply);
        if (applyBtn){
            applyBtn.parentNode.appendChild(node);
        }
    }

    const label = state.action
        .replace(/-license$/, "")
        .replace(/-/g, " ");

    node.style.color = state.failed ? "#f59e0b" : "#16a34a";

    node.textContent =
        `✔ ${state.success}/${state.total} succeeded, ` +
        `${state.failed} failed (${label})`;

    setTimeout(() => {
        node.style.opacity = "0";
    }, 3000);
}

/* =====================================================
   🔥 SELECTION STATUS INDICATOR
===================================================== */

// [MT_PATCH_SELECTION_SUMMARY_V2]
function renderSelectionStatus(){

    const scope = getScope();

    let indicator = scope.querySelector("[data-bulk-status]");
    
    if (!indicator){
        indicator = document.createElement("span");
        indicator.setAttribute("data-bulk-status", "1");

        indicator.style.marginLeft = "10px";
        indicator.style.fontSize = "12px";
        indicator.style.opacity = "0.8";

        const applyBtn = scope.querySelector(SELECTOR.apply);
        if (applyBtn){
            applyBtn.insertAdjacentElement("afterend", indicator);
        }
    }

    const selected = getSelected();

    if (!selected.length){
        indicator.textContent = "";
        return;
    }

    const counts = {};

    // [MT_PATCH_SUMMARY_STATE_RESILIENT_V1]

    selected.forEach(id => {

        const row = getRow(id);
        if (!row) return;

        let state = row.getAttribute("data-license-state");

        // 🔥 FALLBACK — attempt badge recovery (UI source of truth)
        if (!state){
            const badge = row.querySelector(".badge");
            if (badge){
                state = badge.textContent;
            }
        }

        // 🔥 FINAL GUARD
        if (!state || state === "undefined" || state === "null"){
            return;
        }

        const key = String(state).toLowerCase();

        counts[key] = (counts[key] || 0) + 1;
    });

    const count = selected.length;
    const states = Object.keys(counts);

    if (!states.length){
        indicator.textContent = `${count} selected (unknown)`;
        return;
    }

    if (states.length === 1){
        indicator.textContent = `${count} selected (${states[0]})`;
        return;
    }

    const breakdown = states
        .map(s => `${counts[s]} ${s}`)
        .join(", ");

    indicator.textContent = `${count} selected (${breakdown})`;
}

function handleBulkApply(){

    const scope = getScope();

    const select = scope.querySelector(SELECTOR.select);
    const action = select?.value;

    if (!action) return;

    const ids = getSelected();
    if (!ids.length) return;

    mtBulkExec.start(ids, action);

    console.debug("[MT BULK] dispatch via DOM", action, ids);

    ids.forEach(id => {

        const proxy = document.createElement("button");

        proxy.type = "button";
        proxy.setAttribute("data-action", action);
        proxy.setAttribute("data-license", id);
        proxy.setAttribute("data-contract", "1");

        proxy.style.display = "none";
        document.body.appendChild(proxy);

        proxy.dispatchEvent(new Event("click", { bubbles: true }));
        proxy.remove();
    });

    /* 🔄 reset AFTER dispatch */
    scope.querySelectorAll(SELECTOR.checkbox).forEach(cb => {
        cb.checked = false;
    });

    if (select) select.value = "";

    updateBulk();
    renderBulkActions();
    updateApplyState();
    renderSelectionStatus();
}

function setState(btn, enabled){

    btn.disabled = !enabled;

    btn.classList.toggle("mt-btn-active", enabled);
    btn.classList.toggle("mt-btn-disabled", !enabled);
}

function updateApplyState(){

    const scope = getScope();

    const select = scope.querySelector(SELECTOR.select);
    const applyBtn = scope.querySelector(SELECTOR.apply);

    if (!select || !applyBtn) return;

    const hasAction = !!select.value;
    const hasSelection = getSelected().length > 0;

    const enabled = hasAction && hasSelection;

    applyBtn.disabled = !enabled;

    applyBtn.classList.toggle("mt-btn-active", enabled);
    applyBtn.classList.toggle("mt-btn-disabled", !enabled);
}

function pruneSelection(){

    if (!window.mtSelection) return;

    window.mtSelection.forEach(id => {
        if (!getRow(id)){
            window.mtSelection.delete(id);
        }
    });
}

/* =====================================================
   MASTER CHECKBOX
===================================================== */

function handleMasterToggle(e){

    const master = e.target;
    if (!master.matches(SELECTOR.master)) return;

    const scope = master.closest("table") || getScope();

    scope.querySelectorAll(SELECTOR.checkbox).forEach(cb => {

        if (!cb.disabled){

            cb.checked = master.checked;

            if (window.mtSelection){
                if (master.checked){
                    window.mtSelection.add(cb.value);
                } else {
                    window.mtSelection.delete(cb.value);
                }
            }
        }

    });

    updateBulk();

    renderSelectionStatus();
}

function syncMasterCheckbox(){

    const scope = getScope();
    const master = scope.querySelector(SELECTOR.master);

    if (!master) return;

    const checkboxes = Array.from(
        scope.querySelectorAll(SELECTOR.checkbox)
    ).filter(cb => !cb.disabled);

    if (!checkboxes.length){
        master.checked = false;
        master.indeterminate = false;
        return;
    }

    const checked = checkboxes.filter(cb => cb.checked);

    master.checked = checked.length === checkboxes.length;
    master.indeterminate =
        checked.length > 0 && checked.length < checkboxes.length;
}

/* =====================================================
   LIVE STATUS COLOR SYNC (NO RELOAD)
===================================================== */

document.addEventListener("mt:license-updated", function(e){

    const { license, state } = e.detail || {};
    if (!license || !state) return;

    const row = document.querySelector(`[data-license-id="${license}"]`);
    if (!row) return;

    const badge = row.querySelector(".badge");
    if (!badge) return;

    const s = String(state).toLowerCase();

    const map = {
        active: "badge badge-active",
        suspended: "badge badge-suspended",
        revoked: "badge badge-revoked",
        expired: "badge badge-expired",
        archived: "badge",
        issued: "badge"
    };

    badge.className = map[s] || "badge";
    badge.textContent = state;

});

/* =====================================================
   EVENTS
===================================================== */

document.addEventListener("change", function(e){

    const scope = getScope();

    /* 🔹 checkbox change */
    if (e.target.matches(SELECTOR.checkbox)){

        const id = e.target.value;
        const row = getRow(id);

        if (!row){
            e.target.checked = false;
            return;
        }

        // 🔒 ensure row is hydrated before allowing selection
        const hasState = row.hasAttribute("data-license-state");
        const hasActions = row.hasAttribute("data-allowed-actions");

        // [MT_PATCH_SELECTION_NON_BLOCKING_V1]
        // Allow selection even if contract not hydrated yet
        // Contract enforcement happens later

        // 🔁 optional memory sync (non-authoritative)
        if (window.mtSelection){
            if (e.target.checked){
                window.mtSelection.add(id);
            } else {
                window.mtSelection.delete(id);
            }
        }

        updateBulk();
        renderSelectionStatus();
        renderBulkActions();
        updateApplyState();
        syncMasterCheckbox();
    }

    /* 🔹 master checkbox */
    if (e.target.matches(SELECTOR.master)){
        handleMasterToggle(e);
        renderBulkActions();
        updateApplyState();
    }

    /* 🔥 NEW: dropdown change */
    if (e.target.matches(SELECTOR.select)){
        updateApplyState();
    }

});

// [MT_PATCH_CONTRACT_SINGLE_SOURCE_RENDER_V4_STATE_FIX]
document.addEventListener("mt:contract-sync", function(e){

    const contract = e.detail;
    if (!contract || !contract.license) return;

    const id = contract.license;
    const row = getRow(id);
    if (!row) return;

    contractReady = true;

    try {

        /*
        |--------------------------------------------------------------------------
        | 🔒 STATE SYNC ONLY
        |--------------------------------------------------------------------------
        | Canonical contract already exists in:
        | [data-action-container][data-contract]
        |--------------------------------------------------------------------------
        */

        if (contract.state){
            row.setAttribute("data-license-state", contract.state);
        }

    } catch (err){

        console.warn("[MT CONTRACT] passive sync failed", err);
        return;
    }

    enforceSelectableState();

    renderBulkActions();
    updateBulk();
    renderSelectionStatus();
    updateApplyState();

    mtBulkExec.resolve(id, true);
});

let syncScheduled = false;


// [MT_PATCH_BULK_UI_PASSIVE_MODE_V1]
document.addEventListener("mt:modal-opened", function(){

    contractReady = false;

    if (window.mtSelection){
        window.mtSelection.clear();
    }

    const scope = getScope();

    const select = scope.querySelector(SELECTOR.select);
    const apply = scope.querySelector(SELECTOR.apply);

    if (select) select.value = "";
    if (apply) apply.disabled = true;

    setTimeout(() => {

        // [MT_PATCH_RENDER_ACTIONS_ON_MODAL_OPEN_V1]

        enforceSelectableState();
        updateBulk();
        renderSelectionStatus();
        renderBulkActions();
        updateApplyState();
    }, 150);
});

/* 🔥 INIT */
window.addEventListener("load", function(){
    setTimeout(() => {

        const scope = getScope();

        scope.querySelectorAll(SELECTOR.row).forEach(row => {
            const id = row.getAttribute("data-license-id");
            if (id){
                renderRowActions(id);
            }
        });

        enforceSelectableState();
        updateBulk();
        renderSelectionStatus();

    }, 200);
});

document.addEventListener("click", function(e){

    if (!e.target.matches(SELECTOR.apply)) return;

    e.preventDefault();

    updateApplyState(); // 🔒 re-validate

    const scope = getScope();
    const select = scope.querySelector(SELECTOR.select);

    // [MT_PATCH_APPLY_GUARD_V1]
    if (!select){
        console.warn("[MT BULK] missing select");
        return;
    }

    if (!select.value){
        console.warn("[MT BULK] no action selected");
        return;
    }

    handleBulkApply();

});

/* =====================================================
   LOCK
===================================================== */

Object.defineProperty(window, "__mtBulkUI", {
    value: true,
    writable: false
});

console.debug("[MT BULK STATE]", {
    selected: getSelected(),
    intersection: getBulkIntersection(getSelected())
});

})();