/**
 * Mandatag
 * Render Guard Engine (DOM Ownership Firewall — STABLE)
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-render-guard.js
 * Location: /public_html/Assets/core/
 * Purpose:
 *   Enterprise-safe DOM governance layer
 *   - Prevents structural corruption
 *   - Allows UI state mutations
 *   - Eliminates recursive mutation loops
 *
 * PATCH LEVEL: Phase 78 — Stable Adaptive Guard (Deduplicated)
 *
 * Guarantees:
 * - Zero regression
 * - No duplicate declarations
 * - No infinite mutation loops
 * - Sidebar safe
 * - Non-destructive enforcement
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__MT_RENDER_GUARD__) return;

Object.defineProperty(window, "__MT_RENDER_GUARD__", {
    value: true,
    writable: false
});

/* =========================================================
   CONFIG
========================================================= */

const LOCKED_STRUCTURE = new Set(["sidebar"]);

const ALLOWED_DYNAMIC_CONTAINERS = new Set([
    "mt-nav-intel-slot",
    "mt-command",
    "alertDrawer"
]);

/* =========================================================
   IGNORED HIGH-FREQUENCY ZONES (PATCH — PHASE 79)
   Prevents log spam from reactive render surfaces (e.g. SVG maps)
========================================================= */

const IGNORED_ROOT_IDS = new Set([
    "activationMap"
]);

/* =========================================================
   MT_PATCH_GUARD_DISABLE_SAFE_EXIT_V2
   - Hard stop before observer boot
   - Prevents any mutation loop
========================================================= */

if (window.__mtDisableGuard === true) {
    console.debug("[MT GUARD] Disabled via secure flag");
    return;
}

/* =========================================================
   SAFE CHECKS
========================================================= */

function isElement(node){
    return node && node.nodeType === 1;
}

function isAllowedContainer(el){
    if (!el) return false;
    return ALLOWED_DYNAMIC_CONTAINERS.has(el.id);
}

/* =========================================================
   IGNORED ZONE CHECK (PATCH — PHASE 79)
========================================================= */

function isIgnoredZone(el){
    if (!el) return false;

    // Direct match
    if (IGNORED_ROOT_IDS.has(el.id)) return true;

    // Inside ignored container
    if (typeof el.closest === "function") {
        for (const id of IGNORED_ROOT_IDS){
            if (el.closest("#" + id)) return true;
        }
    }

    return false;
}

/* =========================================================
   TRUSTED NODE FILTER
========================================================= */

const TRUSTED_NODE_CLASSES = new Set([
    "menu-group",
    "menu-item",
    "submenu",
    "menu-node",
    "submenu-children",
    "mt-menu-recovered"
]);

function isTrustedNode(node){
    if (!node || !node.classList) return false;

    for (const cls of TRUSTED_NODE_CLASSES){
        if (node.classList.contains(cls)) return true;
    }

    return false;
}

/* =========================================================
   MUTATION GUARD (SINGLE DECLARATION SAFE)
========================================================= */

let guardLock = false;

const observer = new MutationObserver((mutations)=>{

    if (guardLock) return;

    guardLock = true;

    try {

        for (const mutation of mutations){

            mutation.addedNodes.forEach(node=>{

                if (!isElement(node)) return;

                const parent = node.parentElement;
                if (!parent) return;

                /* =========================================
                   SIDEBAR (NON-DESTRUCTIVE)
                ========================================= */

                if (parent.id === "sidebar") {

                    if (isTrustedNode(node)) return;

                    console.debug("[MT GUARD] Sidebar mutation observed:", node);
                    return;
                }

                /* =========================================
                   SAFE ZONES
                ========================================= */

                if (isAllowedContainer(parent)) return;

                // 🚫 PATCH — ignore noisy reactive zones (SVG / maps / live UI)
                if (isIgnoredZone(parent)) return;

                if (parent === document.body) return;

            });

        }

    } catch(e){

        console.error("[MT GUARD ERROR]", e);

    } finally {

        guardLock = false;

    }

});

/* =========================================================
   START OBSERVER
========================================================= */

if (typeof MutationObserver !== "undefined") {

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

} else {

    console.warn("[MT] MutationObserver not supported");

}

/* =========================================================
   SIDEBAR ATTRIBUTE POLICY (NON-BLOCKING)
========================================================= */

const sidebar = document.getElementById("sidebar");

if (sidebar){

    new MutationObserver((mutations)=>{

        mutations.forEach(m=>{

            if (m.type !== "attributes") return;

            const attr = m.attributeName;

            /* ✅ ALWAYS ALLOW UI STATE */
            if (
                attr === "class" ||
                attr === "style" ||
                attr.startsWith("data-")
            ) {
                return;
            }

            console.debug("[MT GUARD] Attribute observed:", attr);

        });

    }).observe(sidebar, {
        attributes: true,
        attributeOldValue: true
    });

}

/* =========================================================
   DEBUG API
========================================================= */

window.MT_RENDER_GUARD = Object.freeze({
    version: "Phase 78",
    locked: Array.from(LOCKED_STRUCTURE),
    allowedContainers: Array.from(ALLOWED_DYNAMIC_CONTAINERS)
});

console.debug("[MT] Render Guard ACTIVE — Stable Mode");

})();