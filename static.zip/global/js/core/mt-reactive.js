/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-reactive.js
 * Location: /public_html/Assets/core/
 * Purpose: Reactive bindings layer extending MT core (Phase 54)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 54 — Reactive UI Stabilization
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   REQUIRE CORE
========================================================= */

if (!window.MT) {
    console.error("[MT] Core not loaded before reactive engine");
    return;
}

/* =========================================================
   EXTEND MT SAFELY (NO OVERRIDE)
========================================================= */

const MT = window.MT;

/* =========================================================
   SAFE DOM QUERY
========================================================= */

function $(selector){
    try {
        if (typeof selector !== "string") return null;
        return document.querySelector(selector);
    } catch {
        return null;
    }
}

/* =========================================================
   REACTIVE DOM BINDINGS
========================================================= */

function bindText(selector, key){

    const el = $(selector);
    if(!el) return;

    MT.bind(key, value=>{
        el.textContent =
            value === null || value === undefined
                ? ""
                : String(value);
    });
}

function bindHTML(selector, key){

    const el = $(selector);
    if(!el) return;

    MT.bind(key, value=>{

        // 🔒 HARD SAFETY: block non-string
        if (typeof value !== "string") {
            el.textContent = "";
            return;
        }

        // 🔒 BASIC SANITIZATION (no scripts)
        const safe = value
            .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "")
            .replace(/on\w+="[^"]*"/g, "")
            .replace(/javascript:/gi, "");

        el.innerHTML = safe;
    });
}

/* =========================================================
   SAFE NODE LIST BINDING (NEW — PRIMARY)
========================================================= */

function bindList(selector, key, renderer){

    const el = $(selector);
    if(!el) return;

    MT.bind(key, list=>{

        if(!Array.isArray(list)) return;

        try {

            // 🔒 FULL DOM CONTROL (NO HTML STRINGS)
            el.replaceChildren();

            list.forEach(item => {

                const node = renderer(item);

                if (node instanceof Node) {
                    el.appendChild(node);
                } else {
                    // fallback safe text
                    const div = document.createElement("div");
                    div.textContent = String(node ?? "");
                    el.appendChild(div);
                }

            });

        } catch(e){
            console.warn("[MT] bindList render error", e);
        }

    });
}

/* =========================================================
   SAFE ATTACH (NON-DESTRUCTIVE)
========================================================= */

function attach(name, fn){

    if (typeof MT[name] === "function") {
        console.warn("[MT] Skipping override:", name);
        return;
    }

    try {

        /* =====================================================
           🔒 IMMUTABLE CORE COMPATIBILITY (FIXED)
        ===================================================== */

        if (!Object.isExtensible(MT)) {

            console.debug("[MT] fallback binding:", name);

            const globalName = "mt_" + name;

            try {

                if (!window[globalName]) {
                    Object.defineProperty(window, globalName, {
                        value: fn,
                        writable: false,
                        configurable: false
                    });
                }

            } catch(e){
                console.warn("[MT] fallback attach failed:", name, e);
            }

            return;
        }

        Object.defineProperty(MT, name, {
            value: fn,
            writable: false,
            configurable: false
        });

    } catch(e){

        console.error("[MT] Attach failed (hard)", name, e);

    }
}

/* =========================================================
   EXTEND MT
========================================================= */

attach("bindText", bindText);
attach("bindHTML", bindHTML);
attach("bindList", bindList);

/* =========================================================
   DEBUG
========================================================= */

if (!window.__MT_DISABLE_TRANSPORT__) {
    console.debug("[MT] Reactive engine attached");
}

/* =====================================================
   MT-PATCH-BOOT-SIGNAL-REACTIVE-V1
===================================================== */

if (window.MT_BOOT && typeof window.MT_BOOT.ready === "function") {
    window.MT_BOOT.ready("reactive");
}

})();