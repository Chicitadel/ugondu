/**
 * Mandatag
 * Contract Provider Bridge — Dispatcher-Aligned Passive Layer
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-contract-provider.js
 * Location: /public_html/Assets/core/
 *
 * PATCH LEVEL: Phase 79 — Dispatcher Authority Alignment
 *
 * Guarantees:
 * - Dispatcher is SINGLE SOURCE OF TRUTH
 * - Zero backend fetch (no duplication)
 * - No race conditions
 * - No contract overwrite conflicts
 * - DOM + cache fast-path preserved
 * - XSS hardened
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* ============================================================
   INIT GUARD (HARD)
============================================================ */

if (window.__mtContractProvider) return;

Object.defineProperty(window, "__mtContractProvider", {
    value: true,
    writable: false
});

/* ============================================================
   🔒 INTERNAL STATE
============================================================ */

const __mtCache = new Map();

/* ============================================================
   🔒 HELPERS (SECURE)
============================================================ */

function safeLicense(v){
    return (typeof v === "string" && /^[a-zA-Z0-9._:-]+$/.test(v)) ? v : "";
}

function safeJsonParse(str){
    try { return JSON.parse(str); }
    catch { return null; }
}

function safeContractShape(data, license){

    if (!data || typeof data !== "object") return null;

    return {
        license,
        allowed_actions: Array.isArray(data.allowed_actions)
            ? data.allowed_actions
            : [],
        meta: (data.meta && typeof data.meta === "object")
            ? data.meta
            : {}
    };
}

function applyContract(data){

    if (!data || typeof data !== "object") return;
    if (!data.license) return;

    document.dispatchEvent(new CustomEvent("mt:apply-contract", {
        detail: data
    }));
}

/* ============================================================
   🔥 CONTRACT REQUEST HANDLER (PASSIVE MODE)
============================================================ */

document.addEventListener("mt:contract-request", function(e){

    const license = safeLicense(e?.detail?.license);
    if (!license) return;

    /* ============================================================
       🔥 STRATEGY 0: CACHE HIT (FAST PATH)
    ============================================================ */

    if (__mtCache.has(license)) {

        applyContract(__mtCache.get(license));

        console.debug("[MT CONTRACT PROVIDER] CACHE HIT", license);
        return;
    }

    /* ============================================================
       🔥 STRATEGY 1: DOM CONTRACT (SERVER OR APPLY LAYER)
    ============================================================ */

    const existing = document.querySelector(
        `[data-action-container][data-license-id="${license}"][data-contract]`
    );

    if (existing){

        const parsed = safeJsonParse(existing.getAttribute("data-contract"));

        const contract = safeContractShape(parsed, license);

        if (contract){

            __mtCache.set(license, contract);

            applyContract(contract);

            console.debug("[MT CONTRACT PROVIDER] DOM HIT", license);
            return;
        }
    }

    /* ============================================================
       🚫 NO FETCH — DISPATCHER OWNS CONTRACT FLOW
    ============================================================ */

    console.debug("[MT CONTRACT PROVIDER] PASS → dispatcher will resolve", license);

});

/* ============================================================
   🔄 CONTRACT SYNC LISTENER (CACHE UPDATE)
============================================================ */

document.addEventListener("mt:contract-sync", function(e){

    const data = e?.detail;
    const license = safeLicense(data?.license);

    if (!license) return;

    const contract = safeContractShape(data, license);
    if (!contract) return;

    __mtCache.set(license, contract);

});

/* ============================================================
   🔄 CACHE INVALIDATION
============================================================ */

document.addEventListener("mt:contract-invalidate", function(e){

    const license = safeLicense(e?.detail?.license);
    if (!license) return;

    __mtCache.delete(license);

    console.debug("[MT CONTRACT PROVIDER] CACHE INVALIDATED", license);
});

/* ============================================================
   READY
============================================================ */

console.debug("[MT CONTRACT PROVIDER] Passive Mode Ready");

})();