/**
 * Mandatag
 * Policy Engine — DEPRECATED (Backend Authority)
 *
 * File: mt-policy.js
 * Location: /public_html/Assets/core/
 *
 * PATCH LEVEL: Phase 61 — Policy Removal Shim
 *
 * Purpose:
 * - Preserve backward compatibility
 * - Prevent accidental frontend enforcement
 * - Ensure backend remains single source of truth
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtPolicyInitialized) return;

Object.defineProperty(window, "__mtPolicyInitialized", {
    value: true,
    writable: false,
    configurable: false
});

/* =========================================================
   🔥 DEPRECATED POLICY ENGINE
========================================================= */

/**
 * ⚠️ IMPORTANT
 *
 * Frontend policy is NO LONGER authoritative.
 *
 * All permissions must come from:
 *   → backend `allowed_actions`
 *
 * This function is retained ONLY for:
 * - legacy compatibility
 * - defensive fallback (always permissive)
 */
function mtEvaluatePolicy(){

    console.warn("[MT POLICY] Deprecated — backend allowed_actions must be used");

    // 🔒 DO NOT BLOCK ANYTHING
    // Dispatcher enforces via allowed_actions
    return true;
}

/* =========================================================
   EXPORT (SAFE SHIM)
========================================================= */

Object.defineProperty(window, "mtEvaluatePolicy", {
    value: mtEvaluatePolicy,
    writable: false,
    configurable: false
});

/* =========================================================
   BOOT SIGNAL
========================================================= */

(function signal(){

    if (window.MT_BOOT && typeof window.MT_BOOT.ready === "function") {
        window.MT_BOOT.ready("policy");
    } else {
        setTimeout(signal, 25);
    }

})();

/* =========================================================
   DEBUG
========================================================= */

console.debug("[MT POLICY] shim loaded (backend authority)");

})();