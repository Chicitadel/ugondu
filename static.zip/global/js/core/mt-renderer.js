/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-render.js
 * Location: /public_html/Assets/core/
 * Purpose: Secure server-driven UI rendering engine (DOM-safe, no injection)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 54 — Secure Reactive Renderer
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   SECURITY: SAFE TEXT
========================================================= */

function safeText(value){
    if (value === null || value === undefined) return "";
    return String(value);
}

/* =========================================================
   SECURITY: ATTRIBUTE FILTER
========================================================= */

function safeSetAttr(el, key, value){

    // 🚫 BLOCK dangerous attributes
    if (key.startsWith("on")) return; // onclick, onerror, etc.

    // 🚫 BLOCK javascript: URLs
    if (typeof value === "string" && value.trim().toLowerCase().startsWith("javascript:")) {
        return;
    }

    try {
        el.setAttribute(key, value);
    } catch {}
}

/* =========================================================
   CORE: CREATE NODE (SAFE)
========================================================= */

function createNode(node){

    if (!node || typeof node !== "object") {
        return document.createTextNode("");
    }

    const tag = node.tag || "div";

    // 🚫 Prevent script injection
    if (tag.toLowerCase() === "script") {
        return document.createTextNode("");
    }

    const el = document.createElement(tag);

    /* ---------- ATTRIBUTES ---------- */
    if (node.attrs && typeof node.attrs === "object") {
        Object.keys(node.attrs).forEach(k=>{
            safeSetAttr(el, k, node.attrs[k]);
        });
    }

    /* ---------- TEXT ---------- */
    if (node.text) {
        el.textContent = safeText(node.text);
    }

    /* ---------- CHILDREN ---------- */
    if (Array.isArray(node.children)) {
        node.children.forEach(child=>{
            el.appendChild(createNode(child));
        });
    }

    return el;
}

/* =========================================================
   RENDER (SAFE + ATOMIC)
========================================================= */

function renderSchema(target, schema){

    if (!target || !schema) return;

    const fragment = document.createDocumentFragment();

    const rootNode = createNode(schema);

    fragment.appendChild(rootNode);

    // 🔥 ATOMIC REPLACE (no innerHTML)
    target.replaceChildren(fragment);
}

/* =========================================================
   FETCH + RENDER
========================================================= */

async function fetchAndRender(url, target){

    try{

        const res = await fetch(url, {
            credentials: "same-origin"
        });

        if (!res.ok) throw new Error("Fetch failed");

        const schema = await res.json();

        renderSchema(target, schema);

    }catch(e){
        console.warn("[MT_RENDER] Render failed", e);
    }
}

/* =========================================================
   EXPORT
========================================================= */

window.MT_RENDER = {
    renderSchema,
    fetchAndRender
};

})();