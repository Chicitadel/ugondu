/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-dispatcher.js
 * Location: /public_html/Assets/core/
 * Purpose: Central action dispatcher (memory-safe, deterministic)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 59 — Dispatcher Extraction
 *
 * Guarantees:
 * - Zero regression
 * - Delegated event handling
 * - No duplicate binding
 * - Production safe
 * --------------------------------------------------------------------
 */
/**
 * MT-FINAL-DISPATCHER-TCP-V2
 * Absolute TCP Dispatcher (Deterministic / Production Safe)
 */

/**
 * MT-FINAL-DISPATCHER-TCP-V3
 * TCP Safe + Boot-Stable Dispatcher
 */

(function(){

"use strict";

/* =========================================================
   🔒 LOCAL SANITIZERS (DISPATCHER SAFE — NO DEPENDENCY)
   [MT_PATCH_DISPATCHER_SANITIZER_V1]
========================================================= */

function safeLicense(v){
    return (typeof v === "string" && /^[a-zA-Z0-9._:-]+$/.test(v))
        ? v
        : "";
}

console.log("[MT DISPATCHER] booting...");

document.documentElement.setAttribute("data-mt-dispatcher", "loading");

if (window.__mtDispatcher) return;
Object.defineProperty(window, "__mtDispatcher", { value: true });

/* =========================================================
   NETWORK LOCK (SAFE — NO CONTRACT DEPENDENCY)
========================================================= */

if (!window.__mtFetchLocked) {

    Object.defineProperty(window, "__mtFetchLocked", { value: true });

    const nativeFetch = window.fetch.bind(window);

    function lockedFetch(url, options = {}) {

        const u = String(url || "");

        if (
            u.includes("mutation-engine") ||
            u.includes("/admin/activations")
        ) {
            return Promise.resolve(new Response(
                JSON.stringify({ success:false, error:"blocked_route" }),
                { status:403 }
            ));
        }

        return nativeFetch(url, options);
    }

    Object.defineProperty(window, "fetch", {
        value: lockedFetch,
        writable: false
    });

    Object.defineProperty(window, "mtSafeFetch", {
        value: function(url, options = {}) {

            let u = String(url || "");

            if (
                u.includes("mutation-engine") ||
                (
                    u.includes("/admin/") &&
                    !u.includes("/admin/api/")
                )
            ) {
                return Promise.resolve(new Response(
                    JSON.stringify({ success:false, error:"blocked_route" }),
                    { status:403 }
                ));
            }

            if (u.includes("/admin/") && !u.includes("/admin/api/")) {
                u = u.replace("/admin/", "/admin/api/");
            }

            options.headers = options.headers || {};
            options.headers["X-MT-Dispatcher"] = "1";

            return nativeFetch(u, options);
        }
    });
}

/* =========================================================
   RESPONSE PARSER
========================================================= */

async function parseResponse(r){
    try {
        const d = await r.json();
        if (!r.ok) throw d;
        return d;
    } catch(e){
        return { success:false, error:"invalid_response", detail:e };
    }
}

/* =========================================================
   CORE DISPATCH (EXECUTION-TIME CONTRACT CHECK)
========================================================= */

function dispatchAction(el){

    console.log("[MT DISPATCH]", el.dataset.action);

    const action = el.getAttribute("data-action");

    /* =========================================================
       LICENSE INSPECT (TCP SAFE)
    ========================================================= */

    // [MT_DISPATCH_INSPECT_LICENSE_V5_IDEMPOTENT_GUARD]
    if (action === "inspect-license") {

        const license = safeLicense(el.dataset.license);
        if (!license) return;

        console.log("[MT TARGET FOUND] inspect-license", license);

        /* =====================================================
           🔒 IDENTITY GUARD (CRITICAL FIX)
           - Prevent re-dispatch if already inspecting same license
           - No UI duplication
           - No backend call duplication
        ===================================================== */

        const activePanel = document.querySelector("[data-mt-inspector]");
        const activeLicense = activePanel?.getAttribute("data-license-id");

        if (activeLicense === license) {
            console.debug("[MT DISPATCH] inspect skipped (already active)", license);
            return;
        }

        /* =====================================================
           🔥 FETCH CONTRACT (SSOT)
        ===================================================== */
        // [MT_PATCH_UNIFIED_CONTRACT_SOURCE_V2_FINAL]

        window.mtSafeFetch(`/admin/api/license/contract?license=${encodeURIComponent(license)}`, {
            method: "GET",
            credentials: "same-origin"
        })
        .then(r => r.json())
        .then(res => {

            if (!res || typeof res !== "object" || !res.license) {
                console.warn("[MT CONTRACT] invalid inspect payload", license);
                return;
            }

            mtApplyBackendContract(res);

            document.dispatchEvent(new CustomEvent("mt:license-updated", {
                detail: res
            }));

            if (window.mtInspector?.open) {
                window.mtInspector.open(license);
            }

            requestAnimationFrame(() => {
                window.__mtActionRenderer?.refreshAll();
            });

        });

        return;
    }

    /* UI ACTIONS (NON-CONTRACT) */

    if (action === "inspect-install") {

        const license = el.dataset.license;
        const install = el.dataset.install;

        console.log("[MT TARGET FOUND]", el.getAttribute("data-action"));

        if (!license) return;

        fetch(`/admin/api/license/contract?license=${encodeURIComponent(license)}`, {
            headers: { "Accept": "application/json" },
            credentials: "same-origin"
        })
            .then(r => r.json())
            .then(res => {

                if (!res?.success) return;

                mtApplyBackendContract(res);

                // optional: open modal here later
            });

        return;
    }


    if (!action) return;

    /* =========================================================
       🔥 MT-TCP-MODAL-OPEN-V3 (FINAL)
       - Full target resolution (up/down/global)
       - Modal isolation (no interference)
       - Contract refresh after DOM visibility
       - Hydration event emit
    ========================================================= */
    if (action === "open-modal") {

        let target = el.getAttribute("data-target");

        /* 🔍 1. SEARCH UPWARD */
        if (!target) {
            let node = el;
            while (node && node !== document) {
                if (node.getAttribute && node.getAttribute("data-target")) {
                    target = node.getAttribute("data-target");
                    break;
                }
                node = node.parentNode;
            }
        }

        /* 🔍 2. SEARCH DOWNWARD */
        if (!target && el.querySelector) {
            const child = el.querySelector("[data-target]");
            if (child) {
                target = child.getAttribute("data-target");
            }
        }

        /* 🔍 3. GLOBAL FALLBACK */
        if (!target) {
            const any = document.querySelector('[data-action="open-modal"][data-target]');
            if (any) {
                target = any.getAttribute("data-target");
            }
        }

        if (!target) {
            console.error("[MT] open-modal → target unresolved", el);
            return;
        }

        const modal = document.getElementById(target);

        if (!modal) {
            console.error("[MT] open-modal → modal not found:", target);
            return;
        }

        console.log("[MT] opening modal:", target);

        /* =====================================================
           🔒 MODAL ISOLATION (NO CROSS-CLOSE)
        ===================================================== */

        // Only close modals marked as exclusive
        document.querySelectorAll(".mt-modal[data-mt-exclusive='true']").forEach(m => {
            if (m !== modal) {
                m.classList.add("hidden");
                m.setAttribute("data-mt-state", "closed");
            }
        });

        /* =====================================================
           🔥 OPEN TARGET MODAL ONLY
        ===================================================== */

        modal.classList.remove("hidden");
        modal.setAttribute("data-mt-state", "open");

        // [MT_MODAL_CONTRACT_BOOTSTRAP_V2_FINAL]

        /* =====================================================
           🔥 EVENT: MODAL OPENED (HYDRATION HOOK)
        ===================================================== */

        document.dispatchEvent(new CustomEvent("mt:modal-opened", {
            detail: { id: target }
        }));

        /* =====================================================
           🔥 CONTRACT BOOTSTRAP (CRITICAL FIX)
           - Ensures modal rows receive backend contract
           - Prevents fallback-only rendering
           - Resets renderer state safely
        ===================================================== */

        requestAnimationFrame(() => {

            const containers = modal.querySelectorAll("[data-action-container]");

            containers.forEach(container => {

                if (!(container instanceof HTMLElement)) return;

                const license = container.getAttribute("data-license-id");
                if (!license) return;

                /* 🔥 REQUEST CONTRACT (SSOT) */
                document.dispatchEvent(new CustomEvent("mt:contract-request", {
                    detail: { license }
                }));
            });

            /* 🔁 FINAL RENDER PASS */
            window.__mtActionRenderer?.refreshAll();
        });

        return;
    }

    if (action === "close-modal") {

        let modal = el.closest(".mt-modal");

        if (!modal) {
            console.warn("[MT] close-modal → modal not found");
            return;
        }

        modal.classList.add("hidden");
        modal.setAttribute("data-mt-state", "closed");
    }

    // [MT_PATCH_CONTRACT_GATE_V2_SAFE]
    const isContractAction =
        el.dataset.contract === "1" ||
        el.hasAttribute("data-license");

    if (!isContractAction) {
        console.debug("[MT] Blocked — contract mismatch");
        return;
    }

    // [MT_MODAL_SCOPE_LICENSE_RESOLUTION_V1]
    let license = el.getAttribute("data-license");

    if (!license) {

        const modal = el.closest(".mt-modal");

        if (modal) {
            const row = modal.querySelector("[data-license-id]");
            if (row) {
                license = row.getAttribute("data-license-id");
            }
        }
    }

    if (!license) {
        license = el.closest("[data-license-id]")?.getAttribute("data-license-id");
    }

    if (!license) return;

    const map = {
        "activate-license":"activate",
        "deactivate-license":"deactivate",
        "suspend-license":"suspend",
        "revoke-license":"revoke",
        "expire-license":"expire",
        "archive-license":"archive",
        "reset-activations":"reset_activations"
    };

    const apiAction = map[action];
    if (!apiAction) return;

    /* =========================================================
       🔥 SENSITIVE ACTION CONFIRMATION (PHASE 9 HARDENING)
    ========================================================= */

    const SENSITIVE_ACTIONS = {
        "revoke-license": "Are you sure you want to PERMANENTLY REVOKE this license? This cannot be undone.",
        "suspend-license": "Are you sure you want to SUSPEND this license? It will block all future activations.",
        "reset-activations": "Are you sure you want to RESET ALL ACTIVATIONS for this license?",
        "archive-license": "Are you sure you want to ARCHIVE this license?",
        "expire-license": "Are you sure you want to FORCE EXPIRE this license?"
    };

    if (SENSITIVE_ACTIONS[action]) {
        if (typeof window.mtConfirm === "function") {
            window.mtConfirm(SENSITIVE_ACTIONS[action], () => {
                executeApiAction(el, apiAction, license);
            });
            return;
        }
    }

    executeApiAction(el, apiAction, license);
}

/**
 * Execute the actual API call after confirmation (if required).
 */
function executeApiAction(el, apiAction, license) {
    el.disabled = true;

    window.mtSafeFetch("/admin/api/license-action", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        credentials:"same-origin",
        body: JSON.stringify({
            action: apiAction,
            license_id: license
        })
    })
    .then(parseResponse)
    .then(res => {

        if (!res?.success) {
            window.MT_UI?.toast("Action failed", false);
            return;
        }

        /* =========================================================
           🔒 HARD CONTRACT VALIDATION (STATE REQUIRED)
        ========================================================= */

        if (
            !mtValidateContract(res) ||
            typeof res.state !== "string"
        ){
            console.error("[MT DISPATCH] invalid contract payload", res);
            throw new Error("invalid_contract");
        }

        /* =========================================================
           🔥 APPLY CONTRACT (SSOT)
        ========================================================= */

        mtApplyBackendContract(res);

        /* =========================================================
           🔥 GLOBAL STATE EVENT (CRITICAL FIX)
           - Required for modal + inspector sync
           - Single source broadcast
        ========================================================= */

        document.dispatchEvent(new CustomEvent("mt:license-updated", {
            detail: {
                license: res.license,
                state: res.state,
                allowed_actions: res.allowed_actions || [],
                meta: res.meta || {}
            }
        }));

        /* =========================================================
           🔄 CACHE INVALIDATION
        ========================================================= */

        __mtCache.delete(license);

        /* =========================================================
           🔁 RENDER REFRESH
        ========================================================= */

        requestAnimationFrame(() => {
            window.__mtActionRenderer?.refreshAll();
        });

    })
    .finally(()=> el.disabled = false);
}

/* =========================================================
   EVENT BUS (SAFE)
========================================================= */

/* =========================================================
   EVENT BUS (HARD CAPTURE — TCP AUTHORITY)
========================================================= */

const handled = new WeakSet();

/* 🔥 CAPTURE PHASE — RUN BEFORE ALL OTHER HANDLERS */
document.addEventListener("click", function(e){

    /* =========================================================
       ROBUST TARGET RESOLUTION (TCP HARDENED)
    ========================================================= */

    let el = e.target;

    /* walk up manually (bulletproof against wrappers) */
    while (el && el !== document) {

        if (el.hasAttribute && (
            el.hasAttribute("data-action") ||
            el.hasAttribute("data-mt-action")
        )) {
            break;
        }

        el = el.parentNode;
    }

    if (!el || el === document) return;

    /* =========================================================
       ACTION CLASSIFICATION (TCP SAFE)
    ========================================================= */

    const action = el.getAttribute("data-action");

    /* ✅ ALWAYS ALLOW UI ACTIONS */
    const UI_ACTIONS = new Set([
        "open-modal",
        "close-modal",
        "inspect-install",
        "inspect-license" // 🔥 FIX: allow inspector trigger
    ]);

    const isUI = UI_ACTIONS.has(action);
    const isContract = el.dataset.contract === "1";

    /* ❌ Ignore unknown actions */
    if (!isUI && !isContract) {
        return;
    }

    if (handled.has(el)) return;
    handled.add(el);

    /* 🔥 KILL ALL OTHER HANDLERS */
    e.preventDefault();
    e.stopImmediatePropagation();
    e.stopPropagation();

    dispatchAction(el);

    setTimeout(()=>handled.delete(el),0);

}, true); // 🔥 CAPTURE MODE (CRITICAL)

/* =========================================================
   🔥 CONTRACT REQUEST HANDLER (SSOT ENFORCER)
========================================================= */

/* =========================================================
   MT_PATCH_CONTRACT_DEDUPE_V3 (FINAL — STABLE)
   - In-flight request deduplication
   - Global concurrency cap
   - Strong throttle
   - Memory safe
   - No request storms
========================================================= */

// [MT_PATCH_CONTRACT_FLOW_FIX_V8_FINAL]

const __mtInFlight  = new Map();   // license → Promise
const __mtCache     = new Map();   // license → last contract

let __mtActiveRequests = 0;
const __MT_MAX_CONCURRENT = 10; // 🔥 increased (was 6)

/* =========================================================
   🔥 AUTHORITATIVE CONTRACT FETCH (UNIFIED ENDPOINT)
========================================================= */

// [MT_PATCH_FETCH_CONTRACT_SECURE_V2_FINAL]

function fetchContract(license){

    if (__mtInFlight.has(license)) {
        return __mtInFlight.get(license);
    }

    const exec = (async () => {

        while (__mtActiveRequests >= __MT_MAX_CONCURRENT){
            await new Promise(r => setTimeout(r, 20));
        }

        __mtActiveRequests++;

        try {

            const res = await window.mtSafeFetch(
                `/admin/api/license/contract?license=${encodeURIComponent(license)}`,
                {
                    method: "GET",
                    credentials: "same-origin"
                }
            );

            if (!res || !res.ok) return null;

            const data = await res.json().catch(() => null);

            if (
                !data ||
                typeof data !== "object" ||
                !data.license ||
                !Array.isArray(data.allowed_actions) ||
                typeof data.meta !== "object"
            ) {
                return null;
            }

            return data;

        } catch {
            return null;
        } finally {
            __mtActiveRequests--;
            __mtInFlight.delete(license);
        }

    })();

    __mtInFlight.set(license, exec);

    return exec;
}

/* =========================================================
   🔥 CONTRACT REQUEST HANDLER (NO THROTTLE LOSS)
========================================================= */

document.addEventListener("mt:contract-request", function(e){

    const license = safeLicense(e?.detail?.license);
    if (!license) return;

    /* =====================================================
       🔥 CACHE HIT (INSTANT APPLY)
    ===================================================== */

    if (__mtCache.has(license)) {

        const cached = __mtCache.get(license);

        mtApplyBackendContract(cached);

        if (!window.__mtRenderScheduled) {
            window.__mtRenderScheduled = true;

            requestAnimationFrame(() => {
                window.__mtRenderScheduled = false;
                window.__mtActionRenderer?.refreshAll();
            });
        }

        return;
    }

    console.log("[MT CONTRACT REQUEST]", license);

    fetchContract(license).then(res => {

        if (!res) {

            console.warn("[MT CONTRACT] EMPTY RESPONSE", license);

            if (!window.__mtRetryCount) {
                window.__mtRetryCount = new Map();
            }

            const count = window.__mtRetryCount.get(license) || 0;

            if (count >= 1) {
                console.warn("[MT CONTRACT] retry aborted", license);
                window.__mtRetryCount.delete(license); // ✅ CLEANUP
                return;
            }

            window.__mtRetryCount.set(license, count + 1);

            setTimeout(() => {
                document.dispatchEvent(new CustomEvent("mt:contract-request", {
                    detail: { license }
                }));
            }, 300);

            return;
        }

        __mtCache.set(license, Object.freeze(res));

        /* 🔥 APPLY CONTRACT IMMEDIATELY */
        mtApplyBackendContract(res);

        if (!window.__mtRenderScheduled) {
            window.__mtRenderScheduled = true;

            requestAnimationFrame(() => {
                window.__mtRenderScheduled = false;
                window.__mtActionRenderer?.refreshAll();
            });
        }

    });

});

/* =========================================================
   READY (NO CONTRACT DEPENDENCY)
========================================================= */

Object.defineProperty(window, "__MT_DISPATCHER_READY__", {
    value: true,
    writable: false
});

document.documentElement.setAttribute("data-mt-dispatcher", "ready");

/* 🔥 GUARANTEE GLOBAL ACCESS FOR BOOT */
if (!window.mtDispatcher) {
    Object.defineProperty(window, "mtDispatcher", {
        value: Object.freeze({ handle: dispatchAction }),
        writable: false
    });
}

if (window.MT_BOOT?.ready) {
    window.MT_BOOT.ready("dispatcher");
}

console.log("[MT DISPATCHER] READY");

})();