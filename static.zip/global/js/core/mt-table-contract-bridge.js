/**
 * Mandatag
 * Table Contract Bridge — TCP Secure Hydration Layer
 *
 * File: mt-table-contract-bridge.js
 * Location: /public_html/Assets/core/
 *
 * Purpose:
 * - Normalize DOM → Contract alignment
 * - Enforce container as SSOT (Single Source of Truth)
 * - Prevent contract corruption (meta/allowed mismatch)
 * - Ensure renderer receives valid contract
 *
 * Guarantees:
 * - Zero contract mutation
 * - XSS safe
 * - Idempotent hydration
 * - No duplicate writes
 * - Renderer compatible
 *
 * © Air Roofers SAS
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* ============================================================
   INIT GUARD
============================================================ */

if (window.__mtTableBridge) return;

Object.defineProperty(window, "__mtTableBridge", {
    value: true,
    writable: false
});

/* ============================================================
   🔒 HELPERS
============================================================ */

/* ===== MT_PATCH_UNIVERSAL_JSON_NORMALIZER_V1 ===== */
function safeJSONParse(str){

    if (typeof str !== "string") return null;

    try {

        let s = str.trim();

        // 🔒 decode URI encoding
        if (s.includes("%7B") || s.includes("%22")){
            s = decodeURIComponent(s);
        }

        // 🔒 normalize unicode escaped JSON
        if (s.includes("\\u0022")){
            s = s.replace(/\\u0022/g, '"');
        }

        return JSON.parse(s);

    } catch {
        return null;
    }
}

function safeJSONStringify(obj){
    try {
        return JSON.stringify(obj)
            .replace(/[<>"']/g, c => ({
                "<":"\\u003c",
                ">":"\\u003e",
                "\"":"\\u0022",
                "'":"\\u0027"
            }[c]));
    } catch {
        return "{}";
    }
}

function isValidContract(c){
    return (
        c &&
        typeof c === "object" &&
        Array.isArray(c.allowed_actions) &&
        typeof c.meta === "object"
    );
}

/* ============================================================
   🔒 LOOP GUARD STATE
============================================================ */

let scheduled = false;

/* ============================================================
   🚀 SAFE HYDRATE (IDEMPOTENT)
============================================================ */

function hydrate(){

    scheduled = false;

    document
        .querySelectorAll("[data-action-container]")
        .forEach(container => {

            if (!(container instanceof HTMLElement)) return;

            const raw = container.getAttribute("data-contract");

            const row = container.closest("tr");
            if (!row) return;

            const licenseId =
                container.getAttribute("data-license-id") ||
                row.getAttribute("data-license-id");

            if (!licenseId) return;

            const parsed = safeJSONParse(raw);

            /* ====================================================
               🔥 CRITICAL FIX — FORCE CONTRACT REQUEST
            ==================================================== */

            if (!isValidContract(parsed)){

                // 🔥 ensure renderer will request
                if (!container.__mtContractRequested){

                    container.__mtContractRequested = true;

                    document.dispatchEvent(new CustomEvent("mt:contract-request", {
                        detail: { license: licenseId }
                    }));
                }

                return;
            }

            /* ====================================================
               🔒 CHANGE DETECTION
            ==================================================== */

            const prev = row.__mtBridgeCache;
            const next = raw;

            if (prev === next) return;

            row.__mtBridgeCache = next;

            /* ====================================================
               🔁 APPLY (PASSIVE MIRROR)
            ==================================================== */

            row.setAttribute("data-license-id", licenseId);

            row.setAttribute(
                "data-allowed-actions",
                safeJSONStringify(parsed.allowed_actions)
            );

            row.setAttribute(
                "data-meta",
                safeJSONStringify(parsed.meta)
            );

        });
}

// [MT_TABLE_BRIDGE_CONTRACT_REQUEST_V3]

const __mtBridgeRequested = new Set();

function requestContracts(){

    document
        .querySelectorAll("[data-license-id]")
        .forEach(el => {

            const license = el.getAttribute("data-license-id");
            if (!license) return;

            if (__mtBridgeRequested.has(license)) return;
            __mtBridgeRequested.add(license);

            document.dispatchEvent(new CustomEvent("mt:contract-request", {
                detail: { license }
            }));

        });
}

/* ============================================================
   🧠 SCHEDULER (ANTI-STORM)
============================================================ */

function scheduleHydrate(){

    if (scheduled) return;
    scheduled = true;

    queueMicrotask(() => {
        hydrate();
        requestContracts(); // 🔥 ADD THIS LINE
    });
}

/* ============================================================
   📡 EVENTS (SAFE — NO RECURSION)
============================================================ */

document.addEventListener("DOMContentLoaded", scheduleHydrate);

/* 🔥 LISTEN — DO NOT EMIT */
document.addEventListener("mt:contract-sync", scheduleHydrate);

/* ============================================================
   🔁 OBSERVER (FILTERED)
============================================================ */

const observer = new MutationObserver(mutations => {

    for (const m of mutations){

        /* ONLY react to NEW NODES */
        if (m.type !== "childList") continue;

        if (m.addedNodes.length > 0){
            scheduleHydrate();
            return;
        }
    }
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

})();