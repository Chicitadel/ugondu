/**
 * Mandatag
 * MT CONTRACT HYDRATOR — Backend Contract Auto Sync Engine
 *
 * © Air Roofers SAS
 *
 * Author: Ignatus Chika Ujomor
 *
 * Version: 2.0.0 (Realtime + Matrix Enforcement Upgrade)
 *
 * Guarantees:
 * - No duplicate hydration
 * - Backend-driven UI (NO hardcoding)
 * - Injection-safe updates
 * - Realtime sync (non-destructive socket binding)
 * - Zero regression
 */

(function(){

"use strict";

/* =========================================================
   LOCK (PREVENT DUPLICATE INIT)
========================================================= */
if (window.__mtContractHydrator) return;

/* =========================================================
   SAFE JSON PARSE
========================================================= */
function safeParse(json){
    try {
        return JSON.parse(json);
    } catch(e){
        console.warn('[MT][JSON_PARSE_FAIL]', e);
        return null;
    }
}

/* =========================================================
   CORE MATRIX APPLY (CRITICAL)
========================================================= */
window.MT_CONTRACT_APPLY = function(contract){

    if (!contract || typeof contract !== 'object') {
        return;
    }

    document.dispatchEvent(new CustomEvent('mt:apply-contract', {
        detail: contract
    }));
};

/* =========================================================
   CORE HYDRATION
========================================================= */
function hydrateRow(row){

    const id = row.getAttribute("data-license-id");
    if (!id) return;

    document.dispatchEvent(new CustomEvent("mt:contract-request", {
        detail: { license: id }
    }));
}

/* =========================================================
   MODAL HYDRATION
========================================================= */
document.addEventListener("mt:modal-opened", function(e){

    const modalId = e?.detail?.id;
    if (!modalId) return;

    const modal = document.getElementById(modalId);
    if (!modal) return;

    const rows = modal.querySelectorAll("[data-license-id]");

    Promise.all(Array.from(rows).map(hydrateRow))
        .then(() => {
            document.dispatchEvent(new Event("mt:contract-ready"));
        });
});

/* =========================================================
   INITIAL HYDRATION
========================================================= */
document.addEventListener("DOMContentLoaded", function(){

    const rows = document.querySelectorAll("[data-license-id]");

    Promise.all(Array.from(rows).map(hydrateRow))
        .then(() => {
            document.dispatchEvent(new Event("mt:contract-ready"));
        });
});

/* =========================================================
   🔥 REALTIME CONTRACT SYNC (SAFE VERSION)
========================================================= */
(function initRealtimeContractSync(){

    if (!window.MT_SOCKET || window.__mtRealtimeBound) return;

    window.__mtRealtimeBound = true;

    // 🔥 MT-PATCH-REALTIME-TRACE-AWARE-003 START

    window.MT_SOCKET.addEventListener('message', function(evt){

        const msg = safeParse(evt.data);
        if (!msg || !msg.event || !msg.data) return;

        if (msg.event !== 'license.updated') return;

        const traceId = msg.data._trace_id || null;

        if (traceId) {
            console.debug('[MT TRACE]', traceId, msg.event);
        }

        /*
        |--------------------------------------------------------------------------
        | 🔥 DIRECT CONTRACT APPLY (NO FETCH — PREFERRED)
        |--------------------------------------------------------------------------
        */
        if (msg.data.contract && typeof msg.data.contract === 'object') {

            window.MT_CONTRACT_APPLY(msg.data.contract);
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | 🔄 FALLBACK FETCH (SAFE + TRACE PROPAGATION)
        |--------------------------------------------------------------------------
        */
        const id = msg.data.license_id;
        if (!id) return;

        fetch('/admin/api/license/contract?id=' + encodeURIComponent(id), {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'X-Trace-Id': traceId || ''
            },
            credentials: 'same-origin'
        })
        .then(r => r.ok ? r.json() : null)
        .then(contract => {

            if (!contract || typeof contract !== 'object') return;

            window.MT_CONTRACT_APPLY(contract);

        })
        .catch(err => {
            console.warn('[MT][REALTIME_FETCH_FAIL]', err);
        });

    });

    // 🔥 MT-PATCH-REALTIME-TRACE-AWARE-003 END

})();

/* =========================================================
   LOCK
========================================================= */
Object.defineProperty(window, "__mtContractHydrator", {
    value: true,
    writable: false
});

})();