/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-plugin.js
 * Location: /public_html/Assets/core/
 * Purpose: Deterministic, secure plugin registration and event system
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 55 — Plugin System Hardening
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtPluginEngineInitialized) return;
window.__mtPluginEngineInitialized = true;

/* =========================================================
   CORE REGISTRY
========================================================= */

const plugins = new Map();      // name → plugin
const hooks   = Object.create(null);

/* =========================================================
   SAFE EXECUTION WRAPPER
========================================================= */

function safeExec(fn, context = "plugin"){
    try {
        return fn();
    } catch (e) {
        console.error(`[MT Plugin Error][${context}]`, e);
    }
}

/* =========================================================
   VALIDATION
========================================================= */

function validatePlugin(plugin){

    if (!plugin || typeof plugin !== "object") {
        console.warn("[MT] Invalid plugin object");
        return false;
    }

    if (!plugin.name || typeof plugin.name !== "string") {
        console.warn("[MT] Plugin missing valid name");
        return false;
    }

    return true;
}

/* =========================================================
   REGISTER PLUGIN
========================================================= */

function register(plugin){

    if (!validatePlugin(plugin)) return;

    if (plugins.has(plugin.name)) {
        console.warn(`[MT] Plugin already registered: ${plugin.name}`);
        return;
    }

    /* 🔒 Freeze plugin (prevent mutation) */
    Object.freeze(plugin);

    plugins.set(plugin.name, plugin);

    /* 🔥 INIT SAFELY */
    if (typeof plugin.init === "function") {
        safeExec(() => plugin.init(window.MT || {}), plugin.name);
    }

}

/* =========================================================
   HOOK SYSTEM
========================================================= */

function on(event, handler){

    if (typeof handler !== "function") return;

    if (!hooks[event]) {
        hooks[event] = new Set();
    }

    hooks[event].add(handler);
}

function off(event, handler){

    if (!hooks[event]) return;

    hooks[event].delete(handler);
}

function emit(event, payload){

    if (!hooks[event]) return;

    hooks[event].forEach(fn => {
        safeExec(() => fn(payload), `hook:${event}`);
    });

}

/* =========================================================
   UTILITIES
========================================================= */

function list(){
    return Array.from(plugins.keys());
}

function get(name){
    return plugins.get(name);
}

/* =========================================================
   GLOBAL EXPORT
========================================================= */

Object.defineProperty(window, "MT_PLUGINS", {
    value: {
        register,
        on,
        off,
        emit,
        list,
        get
    },
    writable: false,
    configurable: false
});

/* =========================================================
   DEBUG (SAFE)
========================================================= */

if (!window.__MT_DISABLE_TRANSPORT__) {
    console.debug("[MT] Plugin engine initialized");
}

})();