// [MT_LICENSE_DATA_LAYER_V3_SECURE_ISOLATED]

/**
 * Mandatag
 * License Data Layer — Secure, Contract-Driven, Modal-Isolated
 *
 * © Air Roofers SAS
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: mt-license-data.js
 * Location: /public_html/Assets/core/
 *
 * Guarantees:
 * - XSS-safe (no innerHTML / no unsafe dataset injection)
 * - Contract-pure (no UI business logic)
 * - Dispatcher-compliant (mtSafeFetch only)
 * - Modal-safe (no overwrite of activation modal)
 * - Deterministic rendering
 * - Live updates via contract events
 */

(function(){

"use strict";

if (window.__mtLicenseData) return;
Object.defineProperty(window, "__mtLicenseData", { value:true });

/* =====================================================
   STATE
===================================================== */

const state = Object.seal({
    page: 1,
    limit: 25,
    search: "",
    filter: "",
    total: 0
});

/* =====================================================
   GLOBAL SELECTION
===================================================== */

const mtSelection = window.mtSelection || new Set();
window.mtSelection = mtSelection;

/* =====================================================
   SAFE DOM HELPERS
===================================================== */

function clearNode(node){
    while (node.firstChild){
        node.removeChild(node.firstChild);
    }
}

function createCell(text){
    const td = document.createElement("td");
    td.textContent = typeof text === "string" ? text : "—";
    return td;
}

function setTableMessage(body, message){
    if (!body) return;

    clearNode(body);

    const tr = document.createElement("tr");
    const td = document.createElement("td");

    td.colSpan = 5;
    td.className = "mt-empty";
    td.textContent = message;

    tr.appendChild(td);
    body.appendChild(tr);
}

/* =====================================================
   FETCH DATA (TABLE ONLY — NEVER MODAL)
===================================================== */

async function fetchLicenses(){

    const body = document.getElementById("mt-license-table-body");

    /* =====================================================
       🔒 MODAL ISOLATION (DO NOT TOUCH MODAL DATA)
    ===================================================== */

    const modal = document.getElementById("activation-modal");

    const modalOwnsTable =
        modal &&
        modal.getAttribute("data-mt-state") === "open" &&
        body &&
        body.closest(".mt-modal") === modal;

    if (modalOwnsTable){
        console.log("[MT] fetch blocked (modal owns dataset)");
        return;
    }

    /* =====================================================
       🧾 LOADING STATE
    ===================================================== */

    if (body){
        setTableMessage(body, "Loading licenses…");
    }

    /* =====================================================
       🌐 BUILD REQUEST
    ===================================================== */

    const url = new URL("/admin/api/licenses", location.origin);

    url.searchParams.set("page", String(state.page));
    url.searchParams.set("limit", String(state.limit));

    if (state.search){
        url.searchParams.set("search", state.search);
    }

    if (state.filter){
        url.searchParams.set("state", state.filter);
    }

    /* =====================================================
       🚀 FETCH (DISPATCHER SAFE)
    ===================================================== */

    let json;

    try {

        const res = await window.mtSafeFetch(url.toString(), {
            headers: { "X-Requested-With": "XMLHttpRequest" }
        });

        json = await res.json();

    } catch(e){

        console.error("[MT] fetch error", e);

        if (body){
            setTableMessage(body, "Failed to load");
        }

        return;
    }

    /* =====================================================
       ❌ VALIDATION
    ===================================================== */

    if (!json || json.success !== true){

        if (body){
            setTableMessage(body, "Failed to load");
        }

        return;
    }

    /* =====================================================
       ✅ STATE UPDATE
    ===================================================== */

    state.total = Number(json.total) || 0;

    /* =====================================================
       🎯 RENDER
    ===================================================== */

    renderTable(Array.isArray(json.data) ? json.data : []);
    renderPagination();
}
/* =====================================================
   RENDER TABLE (SAFE + CONTRACT EMIT ONLY)
===================================================== */

function renderTable(rows){

    mtSelection.clear();

    const body = document.getElementById("mt-license-table-body");
    if (!body) return;

    clearNode(body);

    if (!rows.length){
        setTableMessage(body, "No results");
        return;
    }

    rows.forEach(row => {

        const license = typeof row.id === "string" ? row.id : "";
        if (!license) return;

        const tr = document.createElement("tr");
        tr.setAttribute("data-license-id", license);

        /* ---------- CHECKBOX ---------- */

        const tdCheck = document.createElement("td");
        const checkbox = document.createElement("input");

        checkbox.type = "checkbox";
        checkbox.value = license;
        checkbox.setAttribute("data-license-checkbox","");

        tdCheck.appendChild(checkbox);

        /* ---------- LICENSE ---------- */

        const tdLicense = createCell(license);

        /* ---------- STATE ---------- */

        const tdState = document.createElement("td");
        const badge = document.createElement("span");

        const safeState = typeof row.state === "string" ? row.state : "unknown";

        badge.className = `badge badge-${safeState}`;
        badge.textContent = safeState;

        tdState.appendChild(badge);

        /* ---------- ACTIVATIONS ---------- */

        const tdAct = createCell("—");

        /* ---------- ACTION SLOT ---------- */

        const tdAction = document.createElement("td");
        tdAction.setAttribute("data-action-container","");
        tdAction.setAttribute("data-license-id", license);

        // [MT_LICENSE_DATA_NO_CONTRACT_WRITE_V1]

        // 🔒 DO NOT WRITE CONTRACT HERE
        // Backend contract will be injected via mtApplyBackendContract

        // ===== MT_PATCH_REMOVE_CONTRACT_WRITE_V2_CRITICAL =====

        /*
         🚫 ABSOLUTE RULE:
         - This layer MUST NEVER write contract
         - Not empty
         - Not placeholder
         - Not default
         - NOTHING

         Contract is owned exclusively by:
         → mt-contract-apply.js
        */

        // 🔒 DO NOTHING — CONTRACT WILL BE INJECTED LATER

        /* ---------- APPEND ---------- */

        tr.appendChild(tdCheck);
        tr.appendChild(tdLicense);
        tr.appendChild(tdState);
        tr.appendChild(tdAct);
        tr.appendChild(tdAction);

        body.appendChild(tr);

        // [MT_PATCH_INITIAL_RENDER_BIND_V2_CONTRACT_FIRST]
        const actionCell = tr.querySelector("[data-action-container]");

        if (actionCell){

            /* 🔒 RESET RENDER STATE */
            actionCell.__mtRendered = false;

            /* ======================================================
               🔥 ALWAYS REQUEST CONTRACT (SSOT ENFORCEMENT)
            ====================================================== */

            if (!actionCell.__mtContractRequested){
                actionCell.__mtContractRequested = true;

                document.dispatchEvent(new CustomEvent("mt:contract-request", {
                    detail: { license }
                }));
            }

        }

    });

    updateBulkUI();

    if (window.__mtActionRenderer?.refreshAll){
        window.__mtActionRenderer.refreshAll();
    }

    document.dispatchEvent(new Event("mt:selection-changed"));

}

function updateBulkUI(){

    const applyBtn = document.getElementById("mt-bulk-apply");
    const select = document.getElementById("mt-bulk-action-select");

    if (!applyBtn || !select) return;

    const active = mtSelection.size > 0;

    applyBtn.disabled = !active;
    select.disabled = !active;
}

document.addEventListener("mt:selection-changed", updateBulkUI);

/* =====================================================
   PAGINATION (SAFE)
===================================================== */

function renderPagination(){

    const el = document.getElementById("mt-pagination");
    if (!el) return;

    clearNode(el);

    const pages = Math.max(1, Math.ceil(state.total / state.limit));

    const prev = document.createElement("button");
    prev.textContent = "Prev";
    prev.disabled = state.page <= 1;
    prev.dataset.page = "prev";

    const next = document.createElement("button");
    next.textContent = "Next";
    next.disabled = state.page >= pages;
    next.dataset.page = "next";

    const label = document.createElement("span");
    label.textContent = `Page ${state.page} / ${pages}`;

    el.appendChild(prev);
    el.appendChild(label);
    el.appendChild(next);
}

/* =====================================================
   EVENTS (DEBOUNCED + SAFE)
===================================================== */

let searchTimer;

document.addEventListener("input", function(e){

    if (e.target.id === "mt-search"){

        clearTimeout(searchTimer);

        searchTimer = setTimeout(() => {

            state.search = String(e.target.value || "")
            .replace(/[<>]/g, "")
            .trim();
            state.page = 1;

            fetchLicenses();

        }, 300);
    }
});

document.addEventListener("change", function(e){

    if (e.target.id === "mt-filter-state"){

        state.filter = String(e.target.value || "")
        .replace(/[^a-z0-9_\-]/gi, "");
        state.page = 1;

        fetchLicenses();
    }

    if (e.target.matches("[data-license-checkbox]")){

        const id = String(e.target.value || "");
        if (!id) return;

        if (e.target.checked){
            mtSelection.add(id);
        } else {
            mtSelection.delete(id);
        }

        // 🔥 FORCE BULK SYNC
        document.dispatchEvent(new Event("mt:selection-changed"));

        if (window.__mtBulkUI){
            setTimeout(() => {
                document.dispatchEvent(new Event("mt:contract-sync"));
            }, 0);
        }
    }
});

/* =====================================================
   PAGINATION EVENTS
===================================================== */

document.addEventListener("click", function(e){

    const page = e.target?.dataset?.page;

    if (!page) return;

    if (page === "prev" && state.page > 1){
        state.page--;
        fetchLicenses();
    }

    if (page === "next"){
        state.page++;
        fetchLicenses();
    }
});

/* =====================================================
   INIT (STRICT — NO MODAL FETCH)
===================================================== */

document.addEventListener("mt:modal-opened", function(e){

    // 🔥 DO NOTHING for activation modal
    if (e.detail?.id === "activation-modal"){
        console.log("[MT] modal uses server dataset (no fetch)");
        return;
    }

    fetchLicenses();
});

})();