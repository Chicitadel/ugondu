<?php
/******************************************************************************
 * Project        : Air Roofers & Mandatag CDN Static Asset Engine
 * Module         : Edge CDN & Asset Distribution Server
 * File           : index.php
 * Version        : 3.0.0
 * Author         : Systems Architecture Group
 * Organization   : Air Roofers SASU / Chicitadel Enterprise
 * Created Date   : 2026-06-21
 * Last Modified  : 2026-07-26
 * Classification : ENTERPRISE | PUBLIC | CDN
 *
 * Governance:
 * - Enterprise Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Copyright (c) 2026 Air Roofers SASU / Chicitadel Enterprise
 * All Rights Reserved.
 ******************************************************************************/

// Global CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, HEAD, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-Correlation-ID');
header('Access-Control-Max-Age: 86400');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');

// Handle preflight OPTIONS request
$requestMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($requestMethod === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Base directory paths
$publicHtmlDir = __DIR__;
$staticRootDir = dirname(__DIR__);

// Request URI Parsing
$requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$requestUri = urldecode($requestUri);

// Standardize path
$path = ltrim($requestUri, '/');

// Alias mappings
$aliases = [
    '' => 'index',
    'favicon.ico' => 'brands/mandatag/favicon.ico',
    'logo.png' => 'brands/mandatag/logo.png',
    'logo.svg' => 'brands/mandatag/logo.svg',
    'css/design-system.css' => 'global/css/design-system.css',
    'css/auth-module.css' => 'global/css/auth-module.css',
    'css/ui-components.css' => 'global/css/ui-components.css',
    'js/auth-runtime.js' => 'global/js/auth-runtime.js',
];

if (isset($aliases[$path])) {
    $path = $aliases[$path];
}

// Security Check: prevent directory traversal
if (strpos($path, '..') !== false || strpos($path, "\0") !== false) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid path', 'status' => 400]);
    exit;
}

// Resolve candidate target files
$candidateFiles = [
    $publicHtmlDir . '/' . $path,
    $staticRootDir . '/' . $path
];

$filePath = null;
foreach ($candidateFiles as $candidate) {
    if (file_exists($candidate) && !is_dir($candidate)) {
        $filePath = realpath($candidate);
        break;
    }
}

// If requesting status or root
if ($path === 'index' || $filePath === null && (empty($path) || $path === 'index.php')) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'cdn' => 'Air Roofers & Mandatag Enterprise CDN',
        'status' => 'OPERATIONAL',
        'version' => '3.0.0',
        'cache_policy' => 'public, max-age=31536000, immutable',
        'allowed_origins' => '*',
        'timestamp' => date(DATE_ATOM),
        'endpoints' => [
            'brands' => '/brands/mandatag/logo.png',
            'favicon' => '/brands/mandatag/favicon.ico',
            'design_system' => '/global/css/design-system.css',
            'auth_runtime' => '/global/js/auth-runtime.js'
        ]
    ], JSON_PRETTY_PRINT);
    exit;
}

// Return 404 if file is not found
if (!$filePath || !file_exists($filePath) || is_dir($filePath)) {
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Asset Not Found', 'path' => '/' . $path, 'status' => 404]);
    exit;
}

// Ensure resolved file path is within allowed directories
$allowedStaticRoot = realpath($staticRootDir);
if (strpos($filePath, $allowedStaticRoot) !== 0) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Access Denied', 'status' => 403]);
    exit;
}

// MIME Type Determination
$mimeMap = [
    'css'   => 'text/css',
    'js'    => 'application/javascript',
    'png'   => 'image/png',
    'jpg'   => 'image/jpeg',
    'jpeg'  => 'image/jpeg',
    'gif'   => 'image/gif',
    'svg'   => 'image/svg+xml',
    'ico'   => 'image/x-icon',
    'json'  => 'application/json',
    'woff'  => 'font/woff',
    'woff2' => 'font/woff2',
    'ttf'   => 'font/ttf',
    'eot'   => 'application/vnd.ms-fontobject',
    'otf'   => 'font/otf',
    'pdf'   => 'application/pdf',
    'zip'   => 'application/zip',
    'map'   => 'application/json',
    'txt'   => 'text/plain',
    'html'  => 'text/html'
];

$ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
$contentType = $mimeMap[$ext] ?? mime_content_type($filePath) ?? 'application/octet-stream';

// HTTP Cache & ETag Headers
$fileMtime = filemtime($filePath);
$fileSize = filesize($filePath);
$etag = sprintf('"%x-%x"', $fileMtime, $fileSize);
$lastModified = gmdate('D, d M Y H:i:s', $fileMtime) . ' GMT';

header('Content-Type: ' . $contentType);
header('Content-Length: ' . $fileSize);
header('Cache-Control: public, max-age=31536000, immutable');
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
header('ETag: ' . $etag);
header('Last-Modified: ' . $lastModified);

// Validate 304 Not Modified
$ifNoneMatch = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
$ifModifiedSince = $_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '';

if (($ifNoneMatch && trim($ifNoneMatch) === $etag) || 
    ($ifModifiedSince && strtotime($ifModifiedSince) >= $fileMtime)) {
    http_response_code(304);
    exit;
}

// Serve file content
if ($_SERVER['REQUEST_METHOD'] === 'HEAD') {
    exit;
}

readfile($filePath);
exit;
