<?php
declare(strict_types=1);

/**
 * Mandatag CDN 2.0 Static Asset release packaging engine
 * 
 * © Air Roofers SAS
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 */

$root = dirname(__FILE__);
$outputPath = $root . '/static_08.zip';

$zip = new ZipArchive();
if ($zip->open($outputPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    die("Failed to create ZIP file at $outputPath\n");
}

$ignoredNames = [
    '.git',
    '.idea',
    '.vscode',
    '.gemini',
    '.antigravity'
];

$ignoredExtensions = [
    'zip'
];

$addedCount = 0;

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
    RecursiveIteratorIterator::SELF_FIRST
);

foreach ($iterator as $fileInfo) {
    $filePath = str_replace('\\', '/', $fileInfo->getRealPath());
    $relativePath = ltrim(substr($filePath, strlen($root)), '/');
    
    // Check if relative path contains ignored directories or files
    $parts = explode('/', $relativePath);
    $shouldIgnore = false;
    foreach ($parts as $part) {
        if (in_array($part, $ignoredNames, true)) {
            $shouldIgnore = true;
            break;
        }
    }
    
    if ($shouldIgnore) {
        continue;
    }
    
    // Check file extension
    $ext = pathinfo($filePath, PATHINFO_EXTENSION);
    if (in_array(strtolower($ext), $ignoredExtensions, true)) {
        continue;
    }
    
    if ($fileInfo->isDir()) {
        $zip->addEmptyDir($relativePath);
    } else {
        if ($zip->addFile($filePath, $relativePath)) {
            $addedCount++;
        }
    }
}

$zip->close();

echo "ZIP file built successfully!\n";
echo "Output: $outputPath\n";
echo "Total files packed: $addedCount\n";
