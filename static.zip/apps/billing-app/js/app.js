/******************************************************************************
 * Project        : Ujomorco Billing Admin Plane
 * Module         : Centralized JavaScript Control Logic
 * File           : app.js
 * Version        : 3.0.0
 * Author         : Ignatus Chika Ujomor
 * Organization   : Ujomor Organization
 * Created Date   : 2026-05-17
 * Last Modified  : 2026-05-23
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Architecture Controlled
 * - Security Reviewed
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Copyright (c) 2026 Ujomor Organization
 * All Rights Reserved.
 ******************************************************************************/

document.addEventListener('DOMContentLoaded', () => {
    // 1. Ecosystem Switcher Logic
    window.openSwitcher = (e) => {
        if (e) e.preventDefault();
        const modal = document.getElementById('switch-modal');
        if (modal) modal.style.display = 'flex';
    };

    window.closeSwitcher = () => {
        const modal = document.getElementById('switch-modal');
        if (modal) modal.style.display = 'none';
    };

    // 2. Mobile Responsive Sidebar Drawer Logic
    const menuToggleBtn = document.getElementById('menu-toggle-btn');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.getElementById('sidebar-overlay-backdrop');

    if (menuToggleBtn && sidebar) {
        menuToggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    }

    if (overlay && sidebar) {
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
        });
    }

    // 3. Global Keydown Event Listeners
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeSwitcher();
            if (sidebar) sidebar.classList.remove('active');
        }
    });

    // 4. Auto-hide error messages after 5 seconds
    const errorAlerts = document.querySelectorAll('.error-alert');
    errorAlerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});
