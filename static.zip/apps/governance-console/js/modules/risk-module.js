/**
 * Mandatag Risk Module
 * Unified Risk UI Engine (Gauge + Resolution)
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * --------------------------------------------------------------------
 * PATCH LEVEL: Phase 80 — Risk Gauge Stabilization
 *
 * Fixes:
 * - Donut chart regression (flat line bug)
 * - Chart.js responsive collapse issue
 * - Invalid dataset structure
 * - Double initialization (hot reload / re-entry)
 *
 * Guarantees:
 * - Zero regression (modal + resolve flow preserved)
 * - Deterministic rendering
 * - Layout-safe initialization
 * - Chart always renders as donut
 * --------------------------------------------------------------------
 */

(function () {
    'use strict';

    /* =========================================================
       RISK GAUGE (CHART.JS SAFE INIT)
    ========================================================= */

    function initRiskGauge() {

        const canvas = document.getElementById('riskGauge');
        if (!canvas || typeof Chart === 'undefined') return;

        const score = parseInt(canvas.dataset.score || '0', 10);
        const color = canvas.dataset.color || '#16a34a';

        // 🔥 HARD GUARANTEE: always 2 values
        const dataValues = [
            score,
            Math.max(0, 100 - score)
        ];

        // Prevent duplicate charts (hot reload / DOM re-entry safe)
        if (canvas.__chart) {
            try { canvas.__chart.destroy(); } catch (_) {}
        }

        canvas.__chart = new Chart(canvas, {
            type: 'doughnut',

            data: {
                datasets: [{
                    data: dataValues,
                    backgroundColor: [
                        color,
                        '#e5e7eb'
                    ],
                    borderWidth: 0
                }]
            },

            // 🔥 CRITICAL FIX BLOCK
            options: {
                responsive: true,
                maintainAspectRatio: false, // FIXES COLLAPSE BUG
                cutout: '70%',              // proper donut thickness

                animation: {
                    duration: 600
                },

                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: false }
                }
            }
        });
    }

    /* =========================================================
       SAFE BOOTSTRAP (LAYOUT-AWARE)
    ========================================================= */

    function safeInitGauge(retries = 10) {

        const canvas = document.getElementById('riskGauge');

        // wait for DOM + layout to stabilize
        if (canvas && canvas.offsetWidth > 0) {
            
            /* MT-PATCH-GAUGE-OWNERSHIP-LOCK-002 START */
            if (window.__mtRiskGaugeOwned !== "dashboard") {
                window.__mtRiskGaugeOwned = "risk-module";
                initRiskGauge();
            }

            /* MT-PATCH-GAUGE-OWNERSHIP-LOCK-002 END */
            return;
        }

        if (retries <= 0) {
            console.warn('[MT] Risk gauge init skipped (layout not ready)');
            return;
        }

        setTimeout(() => safeInitGauge(retries - 1), 80);
    }

    // DOM ready guard
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => safeInitGauge());
    } else {
        safeInitGauge();
    }

    /* =========================================================
       MODAL SYSTEM
    ========================================================= */

    const modal = document.getElementById('riskModal');
    const modalText = document.getElementById('riskModalText');
    const modalClose = document.getElementById('riskModalClose');

    function openModal(text) {
        if (!modal) return;

        modal.classList.remove('hidden');   // 🔥 SHOW
        modalText.innerText = text || 'Processing...';
    }

    function closeModal() {
        if (!modal) return;

        modal.classList.add('hidden');   // 🔥 HIDE
    }

    if (modalClose) {
        modalClose.addEventListener('click', closeModal);
    }

    /* =========================================================
       RISK RESOLUTION ENGINE
    ========================================================= */

    async function resolveRisk(riskType, link) {

        openModal('Resolving risk signal...');

        try {
            const res = await fetch('/admin/api/risk/resolve', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({ risk_type: riskType })
            });

            let data = null;

            try {
                data = await res.json();
            } catch (e) {
                throw new Error("Invalid server response");
            }

            if (!res.ok) {
                throw new Error(data?.message || "Request failed");
            }

            if (data.status !== 'ok') {
                throw new Error(data.message || 'Resolution failed');
            }

            modalText.innerText = 'Risk resolved. Redirecting...';

            setTimeout(() => {
                if (link && link !== '#') {
                    window.location.href = link;
                } else {
                    location.reload();
                }
            }, 800);

        } catch (err) {
            modalText.innerText = err.message;

            setTimeout(() => {
                closeModal();
            }, 1500);
        }
    }

    /* =========================================================
       BUTTON HANDLERS
    ========================================================= */

    document.querySelectorAll('.resolve-risk-btn').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();

            const risk = this.dataset.risk;
            const link = this.dataset.link;

            resolveRisk(risk, link);
        });
    });

    /* =========================================================
       CARD CLICK HANDLER (NO FLICKER)
    ========================================================= */

    document.querySelectorAll('.risk-breakdown-card').forEach(card => {
        card.addEventListener('click', function (e) {

            if (e.target.closest('.resolve-risk-btn')) return;

            const risk = this.dataset.risk;
            const link = this.dataset.link;

            resolveRisk(risk, link);
        });
    });

})();