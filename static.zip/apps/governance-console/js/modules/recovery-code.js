/**
 * Mandatag
 * Segmented Recovery Code Input (FINAL STABLE)
 */

(function () {
    'use strict';

    function sanitize(value) {
        return value
            .toUpperCase()
            .replace(/[^A-HJ-NP-Z2-9]/g, '');
    }

    function init() {

        let autoSubmitTimer = null;
        let hasSubmitted = false;
        
        const group = document.querySelector('[data-recovery-group]');
        if (!group) return;

        const inputs = Array.from(group.querySelectorAll('[data-code]'));
        const hidden = document.getElementById('recovery_code');

        if (!inputs.length || !hidden) return;

        function updateHidden() {

            const combined = inputs.map(i => i.value).join('').substring(0, 8);
            hidden.value = combined;

            const submitBtn = document.querySelector('[data-recovery-submit]');
            if (!submitBtn) return;

            const isComplete = combined.length === 8;

            submitBtn.disabled = !isComplete;
            submitBtn.style.opacity = isComplete ? '1' : '0.5';
            submitBtn.style.cursor = isComplete ? 'pointer' : 'not-allowed';

            // 🧠 AUTO-SUBMIT ENGINE
            if (autoSubmitTimer) {
                clearTimeout(autoSubmitTimer);
                autoSubmitTimer = null;
            }

            if (isComplete && !hasSubmitted) {

                autoSubmitTimer = setTimeout(() => {

                    // double-check before submit
                    if (hidden.value.length === 8 && !hasSubmitted) {

                        hasSubmitted = true;

                        const form = hidden.closest('form');
                        if (!form) return;

                        // UX feedback
                        submitBtn.innerText = 'Verifying...';
                        submitBtn.disabled = true;
                        submitBtn.style.opacity = '0.7';

                        form.submit();
                    }

                }, 250); // 🔥 SAFE DELAY (UX polish)
            }
        }

        function focusNext(i) {
            if (inputs[i + 1]) {
                inputs[i + 1].focus();
                inputs[i + 1].select();
            }
        }

        function applyValidationState(input, value, hadInvalid) {

            input.classList.remove('valid', 'invalid');

            if (hadInvalid) {
                input.classList.add('invalid');
                return;
            }

            if (value.length === 2) {
                input.classList.add('valid');
            }
        }

        function focusPrev(i) {
            if (inputs[i - 1]) {
                inputs[i - 1].focus();
                inputs[i - 1].select();
            }
        }

        function distribute(value) {
            let cursor = 0;

            inputs.forEach((box) => {

                const segment = value.substring(cursor, cursor + 2);
                box.value = segment;

                applyValidationState(box, segment, false);

                cursor += 2;
            });

            updateHidden();

            let nextIndex = Math.floor(value.length / 2);

            if (nextIndex >= inputs.length) {
                nextIndex = inputs.length - 1;
            }

            inputs[nextIndex].focus();
            inputs[nextIndex].select();
        }

        inputs.forEach((input, index) => {

            input.addEventListener('input', function () {

                hasSubmitted = false;

                const raw = input.value.toUpperCase();
                const clean = sanitize(raw);

                const hadInvalid = raw !== clean;

                // 🔴 HARD REJECT FEEDBACK
                if (hadInvalid) {
                    input.classList.add('input-error');

                    setTimeout(() => {
                        input.classList.remove('input-error');
                    }, 300);
                } else {
                    input.classList.remove('input-error');
                }

                // Handle paste / overflow into single box
                if (clean.length > 2) {
                    distribute(clean);
                    return;
                }

                input.value = clean;

                // 🧠 APPLY VALIDATION STATE
                applyValidationState(input, clean, hadInvalid);

                // ✅ AUTO JUMP
                if (clean.length === 2) {
                    focusNext(index);
                }

                updateHidden();
            });

            input.addEventListener('keydown', function (e) {

                hasSubmitted = false;

                if (e.key === 'Backspace') {

                    if (input.value.length === 0) {
                        focusPrev(index);
                        return;
                    }

                    // delete last char manually
                    input.value = input.value.slice(0, -1);
                    updateHidden();
                    e.preventDefault();
                }

                if (e.key === 'ArrowLeft') {
                    focusPrev(index);
                }

                if (e.key === 'ArrowRight') {
                    focusNext(index);
                }
            });

            input.addEventListener('paste', function (e) {

                hasSubmitted = false;

                const pasted = sanitize(
                    (e.clipboardData || window.clipboardData).getData('text')
                );

                if (!pasted) return;

                e.preventDefault();
                distribute(pasted);
            });

        });

        const form = group.closest('form');

        if (form) {
            form.addEventListener('submit', function (e) {
                if (hidden.value.length !== 8) {
                    e.preventDefault();
                }
            });
        }

        // focus first box
        inputs[0].focus();
        updateHidden(); // 🔥 ensure button starts disabled

        console.debug('[MT] Recovery input FINAL initialized');
    }

    if (window.MT) {
        if (!Object.isFrozen(window.MT)) {
            window.MT.recoveryCodeInit = init;
        } else {
            console.warn("[MT] Cannot register recoveryCodeInit: window.MT is frozen");
        }
    } else {
        window.MT = { recoveryCodeInit: init };
    }

    // 🔥 RUN IMMEDIATELY (since loaded via script tag)
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();