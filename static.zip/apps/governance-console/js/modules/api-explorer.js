/**
 * =========================================================
 * MT-PATCH-API-EXPLORER-JS-018 (HARDENED)
 * Injection-safe, deterministic, enterprise-grade
 * =========================================================
 */

(function(){

"use strict";

/* =========================================================
   SINGLETON GUARD
========================================================= */

if (window.__MT_API_EXPLORER__) return;
window.__MT_API_EXPLORER__ = true;

/* =========================================================
   CONSTANTS
========================================================= */

const HISTORY_KEY = "mt_api_history";
const HEATMAP_KEY = "mt_api_heatmap";
const SCENARIO_PREFIX = "mt_scenario_";

/* =========================================================
   SAFE HELPERS
========================================================= */

function safeJSONParse(value, fallback){
    try {
        return JSON.parse(value);
    } catch {
        return fallback;
    }
}

function sanitizeText(str){
    if (typeof str !== "string") return "";
    return str.replace(/[<>&"'`]/g, "");
}

function isValidUrl(url){
    try {
        new URL(url, window.location.origin);
        return true;
    } catch {
        return false;
    }
}

/* =========================================================
   DOM GETTERS (SAFE)
========================================================= */

function el(id){
    return document.getElementById(id);
}

/* =========================================================
   SWAGGER INIT
========================================================= */

function initSwagger(){

    if (typeof SwaggerUIBundle === "undefined") {
        console.warn("[MT] Swagger not available");
        return;
    }

    const token = window.MT_AUTH_TOKEN || "";

    const ui = SwaggerUIBundle({
        url: "/admin/docs/openapi/openapi.mandatag.v1.yaml",
        dom_id: "#swagger-ui",

        deepLinking: true,
        docExpansion: "none",
        defaultModelsExpandDepth: -1,
        displayRequestDuration: true,
        persistAuthorization: true,

        presets: [
            SwaggerUIBundle.presets.apis,
            SwaggerUIStandalonePreset
        ],

        layout: "BaseLayout",

        requestInterceptor: (req) => {
            if (token) {
                req.headers["Authorization"] = "Bearer " + token;
            }
            return req;
        },

        onComplete: function(){
            if (token && ui.authActions) {
                ui.authActions.authorize({
                    adminAuth: {
                        name: "adminAuth",
                        schema: {
                            type: "http",
                            scheme: "bearer"
                        },
                        value: token
                    }
                });
            }
        }
    });
}

/* =========================================================
   HISTORY (SAFE RENDER — NO innerHTML)
========================================================= */

function pushHistory(entry){

    const history = safeJSONParse(localStorage.getItem(HISTORY_KEY), []);

    history.unshift({
        url: sanitizeText(entry.url),
        method: sanitizeText(entry.method)
    });

    if (history.length > 20) history.pop();

    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));

    renderHistory();
}

function renderHistory(){

    const list = el("requestHistory");
    if (!list) return;

    const history = safeJSONParse(localStorage.getItem(HISTORY_KEY), []);

    list.innerHTML = "";

    history.forEach(item => {

        const li = document.createElement("li");

        li.textContent = item.method + " " + item.url;

        li.dataset.url = item.url;
        li.dataset.method = item.method;

        li.addEventListener("click", () => {

            if (el("endpointUrl")) el("endpointUrl").value = item.url;
            if (el("httpMethod")) el("httpMethod").value = item.method;

        });

        list.appendChild(li);

    });
}

/* =========================================================
   HEATMAP
========================================================= */

function updateHeatmap(url, success){

    const heat = safeJSONParse(localStorage.getItem(HEATMAP_KEY), {});

    if (!heat[url]) {
        heat[url] = { ok: 0, fail: 0 };
    }

    if (success) {
        heat[url].ok++;
    } else {
        heat[url].fail++;
    }

    localStorage.setItem(HEATMAP_KEY, JSON.stringify(heat));

    renderHeatmap();
}

function renderHeatmap(){

    const box = el("heatmapBox");
    if (!box) return;

    const data = safeJSONParse(localStorage.getItem(HEATMAP_KEY), {});

    box.textContent = JSON.stringify(data, null, 2);
}

/* =========================================================
   SCENARIOS
========================================================= */

function saveScenario(){

    const name = prompt("Scenario name?");
    if (!name) return;

    const url    = sanitizeText(el("endpointUrl")?.value || "");
    const method = sanitizeText(el("httpMethod")?.value || "");
    const body   = el("requestBody")?.value || "";

    const data = { url, method, body };

    localStorage.setItem(SCENARIO_PREFIX + name, JSON.stringify(data));

    alert("Scenario saved");
}

window.MT_SAVE_SCENARIO = saveScenario;

const saveBtn = document.getElementById("saveScenarioBtn");
if (saveBtn) {
    saveBtn.addEventListener("click", saveScenario);
}

/* =========================================================
   API CONSOLE (SECURE)
========================================================= */

function initConsole(){

    const btn = el("sendRequestBtn");
    if (!btn) return;

    btn.addEventListener("click", async function(){

        const url    = el("endpointUrl")?.value || "";
        const method = el("httpMethod")?.value || "GET";
        const body   = el("requestBody")?.value || "";

        const output = el("responseOutput");

        if (!url || !output) return;

        if (!isValidUrl(url)) {
            output.textContent = "Invalid URL";
            return;
        }

        output.textContent = "Sending...";

        try {

            const res = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + (window.MT_AUTH_TOKEN || "")
                },
                body: method === "GET" ? null : body
            });

            const text = await res.text();

            output.textContent = text;

            pushHistory({ url, method });
            updateHeatmap(url, res.ok);

        } catch(e){

            output.textContent = "Request failed: " + sanitizeText(e.message);

            updateHeatmap(url, false);

        }

    });

}

/* =========================================================
   BOOTSTRAP
========================================================= */

document.addEventListener("DOMContentLoaded", function(){

    initSwagger();
    initConsole();

    renderHistory();
    renderHeatmap();

});

})();