/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: sidebar-integrity.js
 * Location: /public_htmlhttps://static.airroofers.eu/apps/governance-console/js/modules/
 * Purpose:
 *   Sidebar Integrity Engine (UI Health + Structural Validation)
 *
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 72 — Sidebar Integrity Isolation & Stabilization
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - No UI mutation outside safe scope
 * - Mobile-first safe execution
 * - Idempotent (safe re-entry)
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD (PREVENT DUPLICATE EXECUTION)
========================================================= */

if (window.__MT_SIDEBAR_INTEGRITY_INIT__) return;

Object.defineProperty(window, "__MT_SIDEBAR_INTEGRITY_INIT__", {
    value: true,
    writable: false,
    configurable: false
});

/* =========================================================
   CONFIGURATION
========================================================= */

const SIDEBAR_ID = "sidebar";
const STATE_ATTR = "data-mt-state";

/* =========================================================
   SAFE ELEMENT RESOLUTION
========================================================= */

function getSidebar(){
    return document.getElementById(SIDEBAR_ID);
}

/* =========================================================
   CORE VALIDATION ENGINE
========================================================= */

function validateSidebar(){

    const sidebar = getSidebar();

    // 🔒 HARD EXIT: sidebar not present (valid scenario)
    if (!sidebar) {
        console.debug("[MT SIDEBAR] Not present → skipped");
        return;
    }

    try {

        /*
        |--------------------------------------------------------------------------
        | STRUCTURE VALIDATION
        |--------------------------------------------------------------------------
        */

        const hasMenuItems =
            sidebar.querySelectorAll('.menu-group, .submenu').length > 0;

        /*
        |--------------------------------------------------------------------------
        | INTEGRITY FLAG (BACKWARD COMPATIBLE)
        |--------------------------------------------------------------------------
        */

        const integrityOk = window.__MT_INTEGRITY_OK__ === true;

        /*
        |--------------------------------------------------------------------------
        | DEBUG / NON-ENFORCED MODE
        |--------------------------------------------------------------------------
        */

        if (!integrityOk) {

            console.warn("[MT SIDEBAR] Integrity bypassed (debug mode)");

            // Do NOT mutate UI in debug mode
            sidebar.setAttribute(STATE_ATTR, "debug");

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | ERROR STATE
        |--------------------------------------------------------------------------
        */

        if (!hasMenuItems) {

            console.error("[MT SIDEBAR] Menu missing while integrity OK");

            sidebar.setAttribute(STATE_ATTR, "error");

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | SUCCESS STATE
        |--------------------------------------------------------------------------
        */

        sidebar.setAttribute(STATE_ATTR, "ok");

    } catch (e) {

        console.error("[MT SIDEBAR ERROR]", e);

        // Fail-safe (never crash UI)
        try {
            sidebar.setAttribute(STATE_ATTR, "error");
        } catch (_) {}

    }
}

/* =========================================================
   MOBILE-SAFE OBSERVER (NON-INTRUSIVE)
========================================================= */

function observeSidebar(){

    const sidebar = getSidebar();
    if (!sidebar) return;

    // Prevent duplicate observer
    if (sidebar.__mtObserved === true) return;

    Object.defineProperty(sidebar, "__mtObserved", {
        value: true,
        writable: false
    });

    try {

        const observer = new MutationObserver(() => {
            validateSidebar();
        });

        observer.observe(sidebar, {
            childList: true,
            subtree: true
        });

    } catch (e) {

        console.warn("[MT SIDEBAR] Observer not available → skipped safely");

    }
}

/* =========================================================
   BOOTSTRAP (SAFE + DETERMINISTIC)
========================================================= */

function boot(){

    validateSidebar();
    observeSidebar();
}

/*
|--------------------------------------------------------------------------
| DOM READY HANDLING (NON-BLOCKING)
|--------------------------------------------------------------------------
*/

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
} else {
    boot();
}

})();