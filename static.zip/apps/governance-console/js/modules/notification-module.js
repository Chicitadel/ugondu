/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 * File: notification-module.js
 * Location: /public_html/Assets/modules/
 *
 * Purpose:
 *   Live realtime notification runtime
 *
 * Guarantees:
 * - Zero reload updates
 * - XSS-safe rendering
 * - Deterministic websocket lifecycle
 * - Cross-tab synchronization
 * - Stable unread counter
 * - Duplicate suppression
 * - Bounded memory usage
 * - Hardened payload validation
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__MT_NOTIFICATION_RUNTIME__) {
    return;
}

window.__MT_NOTIFICATION_RUNTIME__ = true;

/* =========================================================
   CONFIG
========================================================= */

const CONFIG = Object.freeze({

    wsUrl: String(
        window.__MT_WS_URL__
        || ""
    ),

    maxItems: 50,

    reconnectDelay: 3000
});

/* =========================================================
   STATE
========================================================= */

const state = {

    socket: null,

    connected: false,

    reconnectTimer: null,

    notifications: [],

    activeFilter: "all",

    unread: 0,

    dedupe: new Set()
};

/* =========================================================
   SAFE READY
========================================================= */

function ready(fn){

    if (document.readyState === "loading") {

        document.addEventListener(
            "DOMContentLoaded",
            fn,
            { once: true }
        );

        return;
    }

    fn();
}

/* =========================================================
   SAFE DOM HELPERS
========================================================= */

function byId(id){

    return document.getElementById(id);
}

function safeText(value){

    return String(value || "").trim();
}

/* =========================================================
   ROUTE VALIDATION
========================================================= */

function isSafeRoute(route){

    if (
        typeof route !== "string"
        || route === ""
    ) {
        return false;
    }

    /*
    |--------------------------------------------------------------------------
    | Prevent:
    | - javascript:
    | - protocol-relative
    | - external redirects
    |--------------------------------------------------------------------------
    */

    if (
        route.includes("javascript:")
        || route.includes("//")
    ) {
        return false;
    }

    /*
    |--------------------------------------------------------------------------
    | Admin-only internal navigation
    |--------------------------------------------------------------------------
    */

    return route.startsWith("/admin/");
}

/* =========================================================
   STORAGE
========================================================= */

const STORAGE_KEY = "mt.notifications.v1";

function persistState(){

    try {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify({
                notifications: state.notifications,
                unread: state.unread
            })
        );

    } catch(e){}
}

function restoreState(){

    try {

        const raw = localStorage.getItem(STORAGE_KEY);

        if (!raw) return;

        const parsed = JSON.parse(raw);

        if (
            parsed
            && Array.isArray(parsed.notifications)
        ) {

            state.notifications =
                parsed.notifications.slice(0, CONFIG.maxItems);

            recalculateUnread();
        }

    } catch(e){}
}

/* =========================================================
   COUNT RENDER
========================================================= */

function renderCount(){

    const node = byId("notifCount");

    if (!node) return;

    node.textContent = String(state.unread);

    node.style.display =
        state.unread > 0
            ? "flex"
            : "none";
}

function recalculateUnread(){

    state.unread =
        state.notifications.filter(
            item => !item.read
        ).length;
}

/* =========================================================
   PANEL RENDER
========================================================= */
function renderNotifications(){

    const list = byId("notifList");

    if (!list) return;

    list.innerHTML = "";

    let items = [...state.notifications];

    if (state.activeFilter === "unread") {

        items = items.filter(
            item => !item.read
        );
    }

    if (state.activeFilter === "read") {

        items = items.filter(
            item => item.read
        );
    }

    if (!items.length) {

        const empty = document.createElement("div");

        empty.className = "notif-empty";

        empty.textContent =
            state.unread > 0
                ? (
                    state.unread
                    + " unread notifications unavailable in local cache"
                )
                : "You're all caught up";

        list.appendChild(empty);

        return;
    }

    items.forEach(item => {

        const row =
            document.createElement("div");

        row.setAttribute(
            "role",
            "menuitem"
        );

        row.className =
            "notif-item notif-"
            + normalizeSeverity(item.severity);

        if (!item.read) {
            row.classList.add("unread");
        }

        if (isSafeRoute(item.route)) {

            window.location.href =
                item.route;
        }

        /*
        |--------------------------------------------------------------------------
        | HEADER
        |--------------------------------------------------------------------------
        */

        const header =
            document.createElement("div");

        header.className =
            "notif-row-header";

        const type =
            document.createElement("div");

        type.className =
            "notif-type";

        type.textContent =
            item.type;

        const time =
            document.createElement("div");

        time.className =
            "notif-time";

        time.textContent =
            formatTimestamp(item.timestamp);

        header.appendChild(type);
        header.appendChild(time);

        /*
        |--------------------------------------------------------------------------
        | MESSAGE
        |--------------------------------------------------------------------------
        */

        const message =
            document.createElement("div");

        message.className =
            "notif-message";

        message.textContent =
            item.message;

        row.appendChild(header);
        row.appendChild(message);

        /*
        |--------------------------------------------------------------------------
        | READ STATE
        |--------------------------------------------------------------------------
        */

        row.addEventListener(
            "click",
            function(){

                item.read = true;

                recalculateUnread();

                persistState();

                renderCount();

                renderNotifications();
            }
        );

        list.appendChild(row);
    });

    /*
    |--------------------------------------------------------------------------
    | DOM FLOOD PROTECTION
    |--------------------------------------------------------------------------
    */

    while (
        list.children.length
        > CONFIG.maxItems
    ) {
        list.removeChild(
            list.lastChild
        );
    }

}

/* =========================================================
   SEVERITY
========================================================= */

function normalizeSeverity(value){

    const allowed = [
        "success",
        "info",
        "warning",
        "error"
    ];

    return allowed.includes(value)
        ? value
        : "info";
}

/* =========================================================
   TIMESTAMP
========================================================= */

function formatTimestamp(ts){

    if (!ts) return "";

    try {

        const normalizedTs =
            ts > 9999999999
                ? ts
                : ts * 1000;

        return new Date(normalizedTs)
            .toLocaleString(
                undefined,
                {
                    dateStyle: "medium",
                    timeStyle: "short"
                }
            );

    } catch(e){

        return "";
    }
}

/* =========================================================
   PAYLOAD VALIDATION
========================================================= */

function validatePayload(payload){

    if (!payload || typeof payload !== "object") {
        return false;
    }

    if (safeText(payload.message) === "") {
        return false;
    }

    if (safeText(payload.event) === "") {
        return false;
    }

    return true;
}

/* =========================================================
   ADD NOTIFICATION
========================================================= */

function addNotification(payload){

    if (!validatePayload(payload)) {
        return;
    }

    const traceId = safeText(
        payload.trace_id
        || (
            safeText(payload.event)
            + "|"
            + safeText(payload.message)
            + "|"
            + String(payload.timestamp || 0)
        )
    );

    if (traceId && state.dedupe.has(traceId)) {
        return;
    }

    if (traceId) {

        state.dedupe.add(traceId);

        if (state.dedupe.size > 500) {

            state.dedupe =
                new Set(
                    Array.from(state.dedupe).slice(-250)
                );
        }
    }

    state.notifications.unshift({

        id:
            safeText(payload.trace_id)
            || (
                window.crypto
                && typeof window.crypto.randomUUID === "function"
                    ? window.crypto.randomUUID()
                    : (
                        "mt-"
                        + Date.now()
                        + "-"
                        + Math.random()
                            .toString(36)
                            .slice(2, 10)
                    )
            ),

        event:
            safeText(payload.event),

        type:
            safeText(payload.event)
                .replace(/\./g, " ")
                .toUpperCase(),

        message:
            safeText(payload.message),

        route:
            safeText(payload.route),

        severity:
            normalizeSeverity(payload.severity),

        timestamp:
            Number(payload.timestamp || 0),

        read: false
    });

    state.notifications =
        state.notifications.slice(0, CONFIG.maxItems);

    state.unread++;

    persistState();

    renderCount();

    renderNotifications();

    pulseBell();
}

window.mtNotificationRuntime = {

    add: addNotification
};

/* =========================================================
   BELL PULSE
========================================================= */

function pulseBell(){

    const bell = byId("notificationBell");

    if (!bell) return;

    bell.classList.remove("mt-bell-pulse");

    requestAnimationFrame(() => {

        bell.classList.add("mt-bell-pulse");
    });
}

/* =========================================================
   PANEL INTERACTION
========================================================= */
function bindPanel(){

    const bell =
        byId("notificationBell");

    const panel =
        byId("notificationPanel");

    if (!bell || !panel) {
        return;
    }

    /*
    |--------------------------------------------------------------------------
    | SINGLE BIND GUARD
    |--------------------------------------------------------------------------
    */

    if (panel.dataset.mtBound === "1") {
        return;
    }

    panel.dataset.mtBound = "1";

    /*
    |--------------------------------------------------------------------------
    | INITIAL STATE
    |--------------------------------------------------------------------------
    */

    let isOpen = false;

    panel.style.display = "none";

    /*
    |--------------------------------------------------------------------------
    | SAFE OPEN
    |--------------------------------------------------------------------------
    */

    function openPanel(){

        panel.style.display = "block";

        bell.setAttribute(
            "aria-expanded",
            "true"
        );

        panel.setAttribute(
            "aria-hidden",
            "false"
        );

        isOpen = true;
    }

    /*
    |--------------------------------------------------------------------------
    | SAFE CLOSE
    |--------------------------------------------------------------------------
    */

    function closePanel(){

        panel.style.display = "none";

        bell.setAttribute(
            "aria-expanded",
            "false"
        );

        panel.setAttribute(
            "aria-hidden",
            "true"
        );

        isOpen = false;
    }

    /*
    |--------------------------------------------------------------------------
    | BELL TOGGLE
    |--------------------------------------------------------------------------
    */

    bell.addEventListener(
        "click",
        function(e){

            e.preventDefault();

            e.stopPropagation();

            if (isOpen) {
                closePanel();
            } else {
                openPanel();
            }
        }
    );

    /*
    |--------------------------------------------------------------------------
    | PANEL CLICK ISOLATION
    |--------------------------------------------------------------------------
    */

    panel.addEventListener(
        "click",
        function(e){
            e.stopPropagation();
        }
    );

    /*
    |--------------------------------------------------------------------------
    | OUTSIDE CLICK
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        "click",
        function(e){

            if (!isOpen) {
                return;
            }

            if (
                bell.contains(e.target)
                || panel.contains(e.target)
            ) {
                return;
            }

            closePanel();
        }
    );

    /*
    |--------------------------------------------------------------------------
    | FILTER TABS
    |--------------------------------------------------------------------------
    */

    document.querySelectorAll(
        ".notif-tab"
    ).forEach(btn => {

        btn.addEventListener(
            "click",
            function(e){

                e.stopPropagation();

                document
                    .querySelectorAll(".notif-tab")
                    .forEach(tab => {
                        tab.classList.remove(
                            "active"
                        );
                    });

                btn.classList.add(
                    "active"
                );

                state.activeFilter =
                    btn.dataset.filter;

                renderNotifications();
            }
        );
    });

    /*
    |--------------------------------------------------------------------------
    | MARK ALL READ
    |--------------------------------------------------------------------------
    */

    const markAll =
        byId("notifMarkAllRead");

    if (markAll) {

        markAll.addEventListener(
            "click",
            async function(e){

                e.stopPropagation();

                const unread = state.notifications.filter(n => !n.read);
                if (!unread.length) return;

                const ids = unread.map(n => n.id);

                try {
                    const res = await fetch("/v1/notifications/mark-read", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ ids })
                    });

                    if (res.ok) {
                        const json = await res.json();
                        state.notifications.forEach(n => n.read = true);
                        recalculateUnread();
                        renderCount();
                        renderNotifications();
                        persistState();
                    }
                } catch (err) {
                    console.error("[MT Notifications] Persist failed", err);
                    state.notifications.forEach(n => n.read = true);
                    recalculateUnread();
                    renderCount();
                    renderNotifications();
                    persistState();
                }
            }
        );
    }
}

/* =========================================================
   WEBSOCKET
========================================================= */

function connect(){

    if (!CONFIG.wsUrl) {

        console.warn(
            "[MT] websocket url missing"
        );

        return;
    }

    try {

        state.socket =
            new WebSocket(CONFIG.wsUrl);

    } catch(e){

        scheduleReconnect();

        return;
    }

    state.socket.addEventListener(
        "open",
        onOpen
    );

    state.socket.addEventListener(
        "message",
        onMessage
    );

    state.socket.addEventListener(
        "close",
        onClose
    );

    state.socket.addEventListener(
        "error",
        onError
    );
}

function onOpen(){

    state.connected = true;

    updateLiveBadge(true);

    console.debug(
        "[MT] notification websocket connected"
    );
}

function onClose(){

    state.connected = false;

    updateLiveBadge(false);

    scheduleReconnect();
}

function onError(){

    state.connected = false;

    updateLiveBadge(false);
}

function scheduleReconnect(){

    if (state.reconnectTimer) {
        return;
    }

    state.reconnectTimer =
        setTimeout(() => {

            state.reconnectTimer = null;

            connect();

        }, CONFIG.reconnectDelay);
}

function onMessage(event){

    try {

        const payload =
            JSON.parse(event.data);

        if (
            !payload
            || payload.event !== "notification"
        ) {
            return;
        }

        addNotification(payload.data);

    } catch(e){

        console.warn(
            "[MT] notification parse failure"
        );
    }
}

/* =========================================================
   LIVE BADGE
========================================================= */

function updateLiveBadge(online){

    const badge = byId("sseStatus");

    if (!badge) return;

    badge.textContent =
        online
            ? "LIVE"
            : "OFFLINE";

    badge.classList.remove(
        "badge-danger"
    );

    if (!online) {
        badge.classList.add(
            "badge-danger"
        );
    }
}

/* =========================================================
   CROSS TAB SYNC
========================================================= */

window.addEventListener(
    "storage",
    function(e){

        if (e.key !== STORAGE_KEY) {
            return;
        }

        restoreState();

        renderCount();

        renderNotifications();
    }
);

/* =========================================================
   SERVER HYDRATION
========================================================= */

async function hydrateFromServer(){

    try {

        const response = await fetch(
            "/v1/notifications/list",
            {
                method: "GET",
                credentials: "same-origin",
                headers: {
                    "Accept": "application/json"
                }
            }
        );

        if (!response.ok) {
            return;
        }

        const payload =
            await response.json();

        if (
            !payload
            || !Array.isArray(payload.notifications)
        ) {
            return;
        }

        const serverItems = payload.notifications
            .filter(validatePayload)
            .map(item => ({
                id: safeText(item.id),
                event: safeText(item.event),
                type: safeText(item.event).replace(/\./g, " ").toUpperCase(),
                message: safeText(item.message),
                severity: normalizeSeverity(item.severity),
                timestamp: Number(item.timestamp || 0),
                read: Boolean(item.read)
            }));

        // Merge: keep local 'read' state if it exists
        state.notifications = serverItems.map(serverItem => {
            const localItem = state.notifications.find(l => l.id === serverItem.id);
            if (localItem && localItem.read) {
                return { ...serverItem, read: true };
            }
            return serverItem;
        }).slice(0, CONFIG.maxItems);

        recalculateUnread();

        persistState();

        renderCount();

        renderNotifications();

    } catch(e){

        console.warn(
            "[MT] notification hydration failed"
        );
    }
}

ready(function(){

    try {

        restoreState();

        /*
        |--------------------------------------------------------------------------
        | MT-PATCH-NOTIFICATION-HYDRATION-001
        |--------------------------------------------------------------------------
        | Server unread count hydration
        |--------------------------------------------------------------------------
        */

        (function hydrateInitialUnread(){

            const badge = byId("notifCount");

            if (!badge) {
                return;
            }

            const serverCount =
                Number(
                    badge.dataset.initialCount || 0
                );

            if (
                Number.isInteger(serverCount)
                && serverCount > state.unread
            ) {

                /*
                |--------------------------------------------------------------------------
                | SERVER COUNT ONLY AFFECTS BADGE
                | NEVER SYNTHESIZE FAKE NOTIFICATIONS
                |--------------------------------------------------------------------------
                */

                state.unread = Math.min(
                    serverCount,
                    CONFIG.maxItems
                );
            }

        })();

        renderCount();

        renderNotifications();

        hydrateFromServer();

    } catch(e){

        console.error(
            "[MT] notification bootstrap failure",
            e
        );
    }

    /*
    |--------------------------------------------------------------------------
    | CRITICAL:
    | ALWAYS BIND PANEL EVEN IF RUNTIME PARTIALLY FAILS
    |--------------------------------------------------------------------------
    */

    try {

        bindPanel();

    } catch(e){

        console.error(
            "[MT] notification panel bind failure",
            e
        );
    }

    /*
    |--------------------------------------------------------------------------
    | MT-PATCH-SSE-NOTIFICATION-BRIDGE-002
    |--------------------------------------------------------------------------
    */

    try {

        (function initSseNotificationBridge(){

            const streamUrl = "/v1/telemetry/stream";

            let source = null;

            function connectSSE(){

                try {

                    source = new EventSource(streamUrl);

                    window.addEventListener(
                        "beforeunload",
                        function(){

                            try {

                                if (source) {
                                    source.close();
                                }

                            } catch(e){}
                        },
                        { once:true }
                    );

                } catch(e){

                    updateLiveBadge(false);

                    console.error(
                        "[MT] SSE connection failed"
                    );

                    return;
                }

                source.addEventListener("open", function(){

                    updateLiveBadge(true);

                    console.debug(
                        "[MT] notification SSE connected"
                    );
                });

                source.addEventListener(
                    "notification",
                    function(event){

                        try {

                            const parsed =
                                JSON.parse(event.data);

                            const payload =
                                parsed.payload || parsed;

                            addNotification({

                                event:
                                    safeText(payload.event),

                                message:
                                    safeText(payload.message),

                                severity:
                                    normalizeSeverity(
                                        payload.severity
                                    ),

                                timestamp:
                                    Number(
                                        payload.timestamp || 0
                                    ),

                                trace_id:
                                    safeText(payload.trace_id)
                            });

                        } catch(e){

                            console.warn(
                                "[MT] notification SSE parse failure"
                            );
                        }
                    }
                );

                source.addEventListener(
                    "heartbeat",
                    function(){
                        updateLiveBadge(true);
                    }
                );

                source.onerror = function(){

                    updateLiveBadge(false);

                    console.warn(
                        "[MT] notification SSE disconnected"
                    );
                };
            }

            connectSSE();

        })();

    } catch(e){

        console.error(
            "[MT] SSE bridge bootstrap failure",
            e
        );
    }
});
})();