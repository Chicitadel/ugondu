/**
 * Mandatag Unified MFA Input Formatter
 *
 * Supports:
 * - TOTP (6 digits → 3-3)
 * - Recovery Code (8 chars → 4-4)
 *
 * Zero regression
 * Deterministic behavior
 */

(function () {

    function format(input, config) {

        /*
        |--------------------------------------------------------------------------
        | Preserve raw cursor position BEFORE mutation
        |--------------------------------------------------------------------------
        */

        const originalPosition =
            input.selectionStart ?? 0;

        /*
        |--------------------------------------------------------------------------
        | Normalize input safely
        |--------------------------------------------------------------------------
        */

        const raw = String(input.value || '');

        let value = raw
            .toUpperCase()
            .replace(config.pattern, '')
            .substring(0, config.maxLength);

        /*
        |--------------------------------------------------------------------------
        | Build formatted value
        |--------------------------------------------------------------------------
        */

        let formatted = value;

        if (value.length > config.split) {

            formatted =
                value.substring(0, config.split) +
                ' ' +
                value.substring(config.split);
        }

        /*
        |--------------------------------------------------------------------------
        | Detect formatter expansion delta
        |--------------------------------------------------------------------------
        |
        | Example:
        | raw       = 1234
        | formatted = 123 4
        |
        | cursor must advance by +1
        |--------------------------------------------------------------------------
        */

        const lengthDelta =
            formatted.length - raw.length;

        /*
        |--------------------------------------------------------------------------
        | Apply formatted value
        |--------------------------------------------------------------------------
        */

        input.value = formatted;

        /*
        |--------------------------------------------------------------------------
        | Sync hidden input if configured
        |--------------------------------------------------------------------------
        */

        if (config.hidden) {

            const hidden =
                document.getElementById(config.hidden);

            if (hidden) {
                hidden.value = value;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | Stable cursor restoration
        |--------------------------------------------------------------------------
        */

        let nextPosition =
            originalPosition + lengthDelta;

        /*
        |--------------------------------------------------------------------------
        | Clamp safely
        |--------------------------------------------------------------------------
        */

        nextPosition =
            Math.max(
                0,
                Math.min(
                    nextPosition,
                    formatted.length
                )
            );

        /*
        |--------------------------------------------------------------------------
        | Restore cursor without jump
        |--------------------------------------------------------------------------
        */

        requestAnimationFrame(() => {

            try {

                input.setSelectionRange(
                    nextPosition,
                    nextPosition
                );

            } catch (e) {
                /* no-op */
            }

        });
    }

    document.addEventListener('DOMContentLoaded', function () {

        /*
        |--------------------------------------------------------------------------
        | TOTP (6 digits)
        |--------------------------------------------------------------------------
        */
        const otp = document.getElementById('mfa_code');

        if (otp) {
            otp.addEventListener('input', function () {
                format(otp, {
                    maxLength: 6,
                    split: 3,
                    pattern: /\D/g
                });
            });
        }

        /*
        |--------------------------------------------------------------------------
        | RECOVERY CODE (8 chars)
        |--------------------------------------------------------------------------
        */
        const recovery = document.getElementById('recovery_code_display');

        if (recovery) {

            recovery.addEventListener('input', function () {
                format(recovery, {
                    maxLength: 8,
                    split: 4,
                    pattern: /[^A-Z2-9]/g,
                    hidden: 'recovery_code'
                });
            });

            recovery.addEventListener('paste', function (e) {

                e.preventDefault();

                let paste = (e.clipboardData || window.clipboardData)
                    .getData('text');

                paste = paste.toUpperCase().replace(/[^A-Z2-9]/g, '');

                recovery.value = paste;
                recovery.dispatchEvent(new Event('input'));
            });
        }

    });

})();