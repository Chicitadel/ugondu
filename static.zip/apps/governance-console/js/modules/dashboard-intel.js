/**
 * Mandatag Dashboard Intelligence Module
 * - Handles executive risk timeline visualization
 * - Manages dashboard-specific state and flags
 */
(function() {
    'use strict';

    function init() {
        const container = document.querySelector('.mt-dashboard-container');
        if (!container) return;

        // Handle transport disable flag
        if (container.dataset.mtDisableTransport === 'true') {
            window.__MT_DISABLE_TRANSPORT__ = true;
        }

        initRiskTimeline(container);
    }

    function initRiskTimeline(container) {
        const canvas = document.getElementById('executiveRiskTimeline');
        if (!canvas || !window.Chart) return;

        try {
            const labels = JSON.parse(container.dataset.riskLabels || '[]');
            const scores = JSON.parse(container.dataset.riskScores || '[]');

            if (labels.length === 0) return;

            new Chart(canvas.getContext('2d'), {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'System Risk Score',
                        data: scores,
                        borderColor: '#dc2626',
                        backgroundColor: 'rgba(220, 38, 38, 0.1)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 2,
                        pointRadius: 3,
                        pointBackgroundColor: '#dc2626'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100,
                            grid: { color: 'rgba(0,0,0,0.05)' }
                        },
                        x: {
                            grid: { display: false }
                        }
                    }
                }
            });
        } catch (e) {
            console.warn('[MT] Risk timeline init failed:', e.message);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
