/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Organization: Air Roofers SAS
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: search.js
 * Location: /public_html/Assets/modules/
 *
 * Purpose:
 *   Unified Search Layer
 *
 *   - Global topbar intelligence search (API-driven)
 *   - Sidebar menu filter (DOM-based)
 *   - Debounced input handling
 *   - Safe rendering pipeline
 *
 * Responsibilities:
 *   - Bind UI inputs
 *   - Call GlobalSearchController
 *   - Render structured suggestions
 *   - Filter sidebar navigation
 *
 * Guarantees:
 * - No duplicate bindings
 * - No runtime drift
 * - No blocking operations
 * - Injection-safe rendering
 * - Production hardened
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 80 — Unified Search Consolidation
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   SINGLETON GUARD
========================================================= */

if (window.__MT_SEARCH_INITIALIZED__) return;

Object.defineProperty(window, '__MT_SEARCH_INITIALIZED__', {
    value: true,
    writable: false,
    configurable: false
});

/* =========================================================
   UTIL: SAFE TEXT
========================================================= */

function escapeHtml(str){
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

/* =========================================================
   🔐 MT-PATCH-SAFE-FILTER-001
   Prevent leakage of internal/system fields
========================================================= */

function isSafe(item){

    const unsafePatterns = [
        'capabilities.',
        'permission.',
        'internal_',
        'debug_',
        '.view'
    ];

    try {
        const text = JSON.stringify(item).toLowerCase();
        return !unsafePatterns.some(p => text.includes(p));
    } catch {
        return false;
    }
}

/* =========================================================
   GLOBAL SEARCH (TOP BAR)
========================================================= */

(function(){

    const input = document.getElementById('globalSearch');
    const box   = document.getElementById('globalSearchSuggestions');

    if (!input || !box) return;

    let timer = null;

    input.addEventListener('input', function(){

        const q = input.value.trim();

        if (q.length < 2) {
            box.style.display = 'none';
            box.innerHTML = '';
            return;
        }

        clearTimeout(timer);

        timer = setTimeout(async () => {

            try {

                const res = await fetch(
                    `/admin/api/global-search?q=${encodeURIComponent(q)}&mode=extended`,
                    {
                        credentials: 'same-origin',
                        headers: {
                            'Accept': 'application/json'
                        }
                    }
                );

                if (!res.ok) return;

                const data = await res.json();
                const results = data.results || {};

                let html = '';

                /* =========================================================
                   🔐 MT-PATCH-ORDER-CONTROL-001
                   Enforce deterministic bucket priority
                ========================================================= */

                const bucketOrder = ['licenses','products','users','documentation'];

                bucketOrder.forEach(bucket => {

                    const items = results[bucket];
                    if (!Array.isArray(items) || items.length === 0) return;

                    html += `
                        <div style="
                            padding:8px 12px;
                            font-weight:600;
                            color:#64748b;
                            text-transform:capitalize;
                        ">
                            ${escapeHtml(bucket)}
                        </div>
                    `;

                    items.forEach(item => {

                        /* 🔐 FILTER UNSAFE DATA */
                        if (!isSafe(item)) return;

                        const label =
                            item.label ||
                            item.title ||
                            item.name ||
                            item.email ||
                            item.id ||
                            'item';

                        const url = resolveUrl(item, bucket);

                        /* 🔐 BLOCK INVALID NAV TARGET */
                        if (!url || url === '#') {
                            console.warn('[MT SEARCH] Invalid navigation target', item);
                            return;
                        }

                        html += `
                            <div 
                                class="mt-search-item"
                                data-url="${escapeHtml(url)}"
                                style="
                                    padding:8px 12px;
                                    cursor:pointer;
                                    border-top:1px solid #f1f5f9;
                                "
                            >
                                ${escapeHtml(label)}
                            </div>
                        `;
                    });

                });

                box.innerHTML = html || `
                    <div style="padding:10px;color:#64748b;">
                        No results
                    </div>
                `;

                box.style.display = 'block';

            } catch (e) {
                console.error('[MT SEARCH] global search failed', e);
            }

        }, 250);

    });

    /* -----------------------------------------
       CLICK NAVIGATION (SAFE DELEGATION)
    ----------------------------------------- */

    box.addEventListener('click', function(e){

        const target = e.target.closest('.mt-search-item');
        if (!target) return;

        const url = target.getAttribute('data-url');

        if (!url || url === '#') {
            console.warn('[MT SEARCH] Blocked invalid navigation');
            return;
        }

        window.location.href = url;
    });

    /* -----------------------------------------
       OUTSIDE CLICK CLOSE
    ----------------------------------------- */

    document.addEventListener('click', (e)=>{
        if (!box.contains(e.target) && e.target !== input) {
            box.style.display = 'none';
        }
    });

})();

/* =========================================================
   🔐 MT-PATCH-ROUTING-NORMALIZATION-001
   Enforce correct navigation targets
========================================================= */

function resolveUrl(item, bucket){

    // 🔒 Documentation mapping (STRICT)
    /* =========================================================
       🔐 MT-PATCH-DOC-SLUG-RECOVERY-002
    ========================================================= */

    if (bucket === 'documentation') {

        let slug = '';

        if (item.path && item.path.endsWith('.md')) {
            slug = item.path.replace('.md', '');
        } else if (item.title && item.title.endsWith('.md')) {
            slug = item.title.replace('.md', '');
        } else if (item.label) {
            slug = item.label.toLowerCase().replace(/\s+/g, '_');
        }

        if (slug) {
            return `/admin/documentation?doc=${encodeURIComponent(slug.toLowerCase())}`;
        }

        return '/admin/documentation';
    }

    switch(bucket){

        case 'licenses':
            return item.id
                ? `/admin/licenses?search=${encodeURIComponent(item.id)}`
                : '#';

        case 'products': {

            const searchValue =
                item.name ||
                item.code ||
                item.label ||
                item.id;

            return searchValue
                ? `/admin/products?search=${encodeURIComponent(searchValue)}`
                : '/admin/products';
        }

        case 'users':
            return (item.email || item.id)
                ? `/admin/user-management?search=${encodeURIComponent(item.email || item.id)}`
                : '/admin/user-management';

        case 'documentation':
            return '/admin/documentation';

        default:
            return '#';
    }
}

/* =========================================================
   🔐 MT-PATCH-SIDEBAR-DEEP-FILTER-002
   Works with nested Mandatag menu structure
========================================================= */

(function(){

    const input = document.getElementById('sidebarSearch');
    const sidebar = document.getElementById('sidebar');

    if (!input || !sidebar) return;

    /* =========================================================
       MT-PATCH-SIDEBAR-CONTRACT-FILTER-003
       Server-owned sidebar compatible selectors
    ========================================================= */

    const items = sidebar.querySelectorAll(`
        .menu-group,
        .menu-node,
        .submenu,
        .submenu-children
    `);

    input.addEventListener('input', function(){

        const q = input.value.toLowerCase().trim();

        if (!q) {
            items.forEach(li => li.style.display = '');
            return;
        }

        items.forEach(node => {

            const text = (node.textContent || '').toLowerCase();

            const match = text.includes(q);

            node.style.display = match ? '' : 'none';

            /* 🔒 Preserve parent visibility */
            if (match) {

                let parent = node.parentElement;

                while (parent && parent !== sidebar) {

                    if (
                        parent.classList?.contains('menu-group') ||
                        parent.classList?.contains('menu-node') ||
                        parent.classList?.contains('submenu-children')
                    ) {
                        parent.style.display = '';
                    }

                    parent = parent.parentElement;
                }
            }

        });

    });

})();

})();