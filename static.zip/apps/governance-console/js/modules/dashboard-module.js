/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: dashboard-module.js
 * Location: /public_html/Assets/modules/
 * Purpose:
 *   Dashboard UI Orchestration Module
 *   - Risk gauge rendering
 *   - Latency heatmap
 *   - Activity feed
 *   - Risk interaction bindings
 *
 * PATCH LEVEL: Phase 67 — Dashboard UI Extraction & Stabilization
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic execution
 * - Safe API handling (no JSON crash)
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtDashboardInitialized) return;
window.__mtDashboardInitialized = true;

/* =========================================================
   SAFE READY
========================================================= */

function ready(fn){
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", fn);
    } else {
        fn();
    }
}

/* =========================================================
   SAFE JSON FETCH (CRITICAL FIX)
========================================================= */

async function safeJsonFetch(url, options = {}) {

    const res = await fetch(url, {
        credentials: "same-origin",
        headers: {
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json"
        },
        ...options
    });

    const text = await res.text();

    /* 🔒 HARD VALIDATION */
    if (!text || text.trim().startsWith("<")) {
        throw new Error("Invalid JSON response (HTML detected)");
    }

    try {
        return JSON.parse(text);
    } catch (e) {
        throw new Error("JSON parse failed");
    }
}

/* =========================================================
   INIT
========================================================= */

ready(function(){

    /* MT-PATCH-GAUGE-OWNERSHIP-LOCK-001 START */

    initMetricCounts();

    /* 🔒 Prevent double gauge ownership */
    if (!window.__mtRiskGaugeOwned) {
        window.__mtRiskGaugeOwned = "dashboard";
        initRiskGauge();
    }

    initRecompute();
    initLatencyHeatmap();
    initActivityFeed();
    bindRiskBreakdown();

    /* MT-PATCH-GAUGE-OWNERSHIP-LOCK-001 END */

});

/* =========================================================
   RISK GAUGE (SAFE SINGLE INSTANCE)
========================================================= */

function initRiskGauge(){

    const canvas = document.getElementById("riskGauge");
    if (!canvas || !window.Chart) return;

    /* 🔒 MT-PATCH-CHART-DUPLICATE-GUARD-001 */
    if (canvas.__mtChartInstance) {
        try {
            canvas.__mtChartInstance.destroy();
        } catch(e){}
        canvas.__mtChartInstance = null;
    }

    const ctx = canvas.getContext("2d");

    const targetScore = parseInt(canvas.dataset.score || "0", 10);
    const color = canvas.dataset.color || "#16a34a";

    let animatedScore = 0;

    const chart = new Chart(ctx, {
        type: "doughnut",
        data: {
            datasets: [{
                data: [0, 100],
                backgroundColor: [color, "#e5e7eb"],
                borderWidth: 0
            }]
        },
        options: {
            cutout: "80%",
            animation: false,
            plugins: {
                tooltip: { enabled: false },
                legend: { display: false }
            }
        }
    });

    /* 🔒 store instance */
    canvas.__mtChartInstance = chart;

    const interval = setInterval(() => {

        if (animatedScore >= targetScore) {
            clearInterval(interval);
            return;
        }

        animatedScore++;
        chart.data.datasets[0].data = [animatedScore, 100 - animatedScore];
        chart.update();

    }, 10);

    const needle = document.getElementById("riskNeedle");

    if (needle) {
        const angle = (targetScore / 100) * 180 - 90;
        setTimeout(() => {
            needle.style.transform =
                `translateX(-50%) translateY(-100%) rotate(${angle}deg)`;
        }, 300);
    }
}

/* =========================================================
   METRIC COUNT FALLBACK (SAFE)
   Ensures numbers render even if UI engine fails
========================================================= */

function initMetricCounts(){

    const nodes = document.querySelectorAll(".metric-count");

    if (!nodes.length) return;

    nodes.forEach(el => {

        const target = parseInt(el.dataset.target || "0", 10);

        if (!isNaN(target)) {
            el.textContent = target.toLocaleString();
        }

    });
}

/* =========================================================
   RECOMPUTE RISK
========================================================= */

function initRecompute(){

    const btn = document.getElementById("recomputeRiskBtn");
    if (!btn) return;

    btn.addEventListener("click", async function(){

        btn.disabled = true;
        btn.innerText = "Recomputing...";

        try {

            const endpoint = String(btn.dataset.endpoint || "");

            if (!endpoint.startsWith("/admin/api/")) {
                throw new Error("Invalid endpoint");
            }

            const res = await fetch(endpoint, {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "X-Requested-With": "XMLHttpRequest",
                    "Accept": "application/json"
                }
            });

            if (!res.ok) throw new Error();

            location.reload();

        } catch (e){

            alert("Risk recompute failed.");
            btn.disabled = false;
            btn.innerText = "Recompute Risk";
        }
    });
}

/* =========================================================
   LATENCY HEATMAP
========================================================= */

function initLatencyHeatmap(){

    const canvas = document.getElementById("latencyHeatmap");
    if (!canvas || !window.Chart) return;

    safeJsonFetch(canvas.dataset.endpoint)
    .then(data => {

        const labels = data.map(r => r.hour);
        const values = data.map(r => parseFloat(r.avg_score));

        new Chart(canvas.getContext("2d"), {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    data: values,
                    backgroundColor: values.map(v => {
                        if (v > 75) return "#dc2626";
                        if (v > 40) return "#f59e0b";
                        return "#16a34a";
                    })
                }]
            },
            options: {
                plugins: { legend: { display: false } }
            }
        });

    }).catch(e => {
        console.warn("[MT] Heatmap load skipped:", e.message);
    });
}

/* =========================================================
   ACTIVITY FEED (FIXED)
========================================================= */

/* ===== MT-PATCH-RECENT-ACTIVITY-HARDEN-002 START ===== */
function initActivityFeed(){

    const feed   = document.getElementById("activity-feed");
    const filter = document.getElementById("activityFilter");
    const loadBtn = document.getElementById("loadMoreActivity");

    if (!feed || !filter || !loadBtn) {
        console.warn("[MT] Activity feed DOM missing");
        return;
    }

    let page = 1;
    let loading = false;
    let autoRefreshTimer = null;

    async function loadActivity(reset = false){

        if (loading) return;
        loading = true;

        if (reset){
            page = 1;
            feed.innerHTML = "";
        }

        try {

            const type = filter.value || "";
            const endpoint = String(feed.dataset.endpoint || "");

            if (!endpoint.startsWith("/admin/api/")) {
                throw new Error("Invalid endpoint");
            }

            const url = `${endpoint}?page=${page}&limit=20&type=${encodeURIComponent(type)}`;

            const json = await safeJsonFetch(url);

            if (!Array.isArray(json.data)) {
                throw new Error("Invalid payload");
            }

            if (json.data.length === 0 && page === 1) {
                feed.innerHTML = '<div class="text-muted">No activity found</div>';
                return;
            }

            json.data.forEach(event => {

                const container = document.createElement("div");

                const safeSeverity = ["info","warning","error","success"].includes(event.severity)
                    ? event.severity
                    : "info";

                container.className = "activity-item " + safeSeverity;

                const msgWrap = document.createElement("div");
                const strong = document.createElement("strong");
                strong.textContent = String(event.message || "");
                msgWrap.appendChild(strong);

                const meta = document.createElement("div");

                const actor = String(event.actor || "");
                const time  = String(event.time || "");
                const ip    = String(event.ip || "");

                meta.textContent =
                    actor + " – " + time + (ip ? " – " + ip : "");

                container.appendChild(msgWrap);
                container.appendChild(meta);

                feed.appendChild(container);
            });

            page++;

        } catch (err){
            console.error("[MT] Activity Load Error:", err.message);

            if (page === 1) {
                feed.innerHTML =
                    '<div class="text-muted">Failed to load activity</div>';
            }
        }

        loading = false;
    }

    /* Manual controls */
    loadBtn.addEventListener("click", () => loadActivity());
    filter.addEventListener("change", () => loadActivity(true));

    /* 🔥 AUTO POLLING (CRITICAL RESTORE) */
    function startAutoRefresh(){
        if (autoRefreshTimer) clearInterval(autoRefreshTimer);

        autoRefreshTimer = setInterval(() => {
            loadActivity(true);
        }, 15000); // 15s safe polling
    }

    loadActivity(true);
    startAutoRefresh();
}
/* ===== MT-PATCH-RECENT-ACTIVITY-HARDEN-002 END ===== */

/* =========================================================
   RISK BREAKDOWN INTERACTION
========================================================= */

function bindRiskBreakdown(){

    const cards = document.querySelectorAll(".risk-breakdown-card");
    const filter = document.getElementById("activityFilter");

    if (!cards.length || !filter) return;

    cards.forEach(card => {

        card.addEventListener("click", function(){

            const factor = (this.dataset.factor || "").toLowerCase();

            if (factor.includes("behavior")) {
                filter.value = "login";
            }
            else if (factor.includes("network")) {
                filter.value = "maintenance";
            }
            else {
                filter.value = "";
            }

            filter.dispatchEvent(new Event("change"));

        });

    });
}

})();