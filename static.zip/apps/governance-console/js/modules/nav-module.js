/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: nav-module.js
 * Location: /public_html/Assets/
 * Purpose: Deferred Navigation Intelligence Module Bridge
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 54 — Reactive Module Initialization
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

/* =========================================================
   GLOBAL NAV EXECUTION GUARD (TOP-LEVEL SAFE)
========================================================= */

if (window.__MT_NAV_ALREADY_RENDERED__) {

    console.warn('[Mandatag] Nav render blocked (already initialized)');

} else {

    Object.defineProperty(window, "__MT_NAV_ALREADY_RENDERED__", {
        value: true,
        writable: false,
        configurable: false
    });

(function(){

"use strict";

/* =========================================================
   INIT GUARD (NO DUPLICATE EXECUTION)
========================================================= */

if (window.__mtNavModuleInitialized) return;

Object.defineProperty(window, "__mtNavModuleInitialized", {
    value: true,
    writable: false
});

/* =========================================================
   CONFIG
========================================================= */

const MAX_RETRIES = 20;
const RETRY_DELAY = 150;

/* =========================================================
   SAFE INIT WITH RETRY
========================================================= */

function initWithRetry(retries = 0){

    if (typeof window.mtInitNavigationIntel === "function") {

        try {

            window.mtInitNavigationIntel();

            console.debug("[MT] Navigation Intelligence initialized");

            /* -----------------------------------------
               REGISTER AS PLUGIN (PHASE 55 READY)
            ----------------------------------------- */

            if (window.MT_PLUGINS?.register && !window.__mtNavPluginRegistered) {

                window.__mtNavPluginRegistered = true;

                window.MT_PLUGINS.register({
                    name: "navigationIntel",
                    init: window.mtInitNavigationIntel
                });

            }

        } catch(e){

            console.error("[MT NAV INIT ERROR]", e);

        }

        return;
    }

    if (retries >= MAX_RETRIES){

        console.warn("[MT] Navigation Intelligence not available");

        return;
    }

    const timer = setTimeout(() => {

        if (!document.documentElement) return; // safety guard

        initWithRetry(retries + 1);

    }, RETRY_DELAY);
}

/* =========================================================
   DEFERRED START (NO DOMContentLoaded)
========================================================= */

initWithRetry();

/* =========================================================
   PHASE 43 — ADAPTIVE NAVIGATION LAYER (NON-INTRUSIVE)
========================================================= */

(function(){
// removed the inner use strict to maintain only the outer single

/* -----------------------------------------
   SAFE EXECUTION (WAIT FOR DOM + UI READY)
----------------------------------------- */

function initAdaptiveNav(){

    const wrapper = document.querySelector('.dev-tabs-wrapper');
    if (!wrapper) return;

    /* =========================================================
       IDP GUARD — PREVENT MULTI-RENDER (CRITICAL FIX)
    ========================================================= */

    if (wrapper.__mtAdaptiveInitialized === true) {
        return;
    }

    Object.defineProperty(wrapper, "__mtAdaptiveInitialized", {
        value: true,
        writable: false
    });

    const tabs = wrapper.querySelectorAll('.dev-tab');
    if (!tabs.length) return;

    let dropdown = wrapper.querySelector('.dev-tabs-dropdown');

    if (!dropdown) {
        dropdown = document.createElement("select");
        dropdown.className = "dev-tabs-dropdown";
        wrapper.insertBefore(dropdown, wrapper.firstChild);
    }

    // Prevent duplicate rebuild
    if (dropdown.__mtBuilt === true) {
        return;
    }

    dropdown.__mtBuilt = true;

    dropdown.innerHTML = "";

    tabs.forEach(tab => {

        if (!(tab instanceof HTMLAnchorElement)) return;

        const option = document.createElement("option");

        option.value = tab.href;
        option.textContent = tab.textContent.trim();

        if (tab.classList.contains("active")) {
            option.selected = true;
        }

        dropdown.appendChild(option);
    });

    dropdown.onchange = null;

    dropdown.addEventListener("change", function(){
        if (this.value) {
            window.location.href = this.value;
        }
    });

    const active = wrapper.querySelector('.dev-tab.active');

    if (active && !wrapper.__mtCentered) {

        wrapper.__mtCentered = true;

        setTimeout(() => {
            active.scrollIntoView({
                behavior: "smooth",
                inline: "center",
                block: "nearest"
            });
        }, 120);
    }
}

/* -----------------------------------------
   HYBRID INIT STRATEGY (MANDATAG SAFE)
----------------------------------------- */

function bootstrapAdaptiveNav(){

    /* =========================================================
       🚫 PHASE 74 — NAV MODULE SIDEBAR LOCK
       Prevents ANY sidebar-related execution
    ========================================================= */

    if (window.__MT_NAV_CLIENT_DISABLED__) {
        console.debug('[MT NAV] Adaptive nav skipped (server-owned sidebar)');
        return;
    }

    if (document.body.__mtNavLock) return;
    document.body.__mtNavLock = true;

    setTimeout(() => {
        document.body.__mtNavLock = false;
    }, 300);

    // Try immediately
    initAdaptiveNav();

    // Retry (UI may be rendered async)
    let retries = 0;
    const max = 10;

    const interval = setInterval(() => {

        if (document.querySelector('.dev-tabs-wrapper')) {
            initAdaptiveNav();
            clearInterval(interval);
            return;
        }

        if (++retries >= max) {
            clearInterval(interval);
        }

    }, 200);
}

/* -----------------------------------------
   DOM READY + FALLBACK
----------------------------------------- */

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootstrapAdaptiveNav);
} else {
    bootstrapAdaptiveNav();
}

/* =========================================================
   MT-PATCH-NAV-HOOK-DEDUP-001
========================================================= */

if (window.MT_HOOKS?.on && !window.__mtNavHookBound) {

    window.__mtNavHookBound = true;

    window.MT_HOOKS.on("ui:rendered", () => {

        /* 🔒 GLOBAL NAV LOCK */
        if (window.__MT_NAV_RENDER_LOCK__) {
            return;
        }

        window.__MT_NAV_RENDER_LOCK__ = true;

        const wrapper = document.querySelector('.dev-tabs-wrapper');

        if (!wrapper || wrapper.__mtAdaptiveInitialized) {

            setTimeout(() => {
                window.__MT_NAV_RENDER_LOCK__ = false;
            }, 200);

            return;
        }

        bootstrapAdaptiveNav();

        setTimeout(() => {
            window.__MT_NAV_RENDER_LOCK__ = false;
        }, 500);

    });
}

})(); // closes inner IIFE

})(); // 🔥 closes outer IIFE (REQUIRED)
}