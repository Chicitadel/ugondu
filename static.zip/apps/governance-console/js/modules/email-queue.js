/**
 * Mandatag
 * Email Queue Intelligence Runtime
 *
 * Location:
 * /public_html/Assets/modules/email-queue.js
 *
 * PATCH:
 * MT-PATCH-EMAIL-QUEUE-LIVE-TELEMETRY-002
 *
 * Guarantees:
 * - Zero inline JS
 * - Secure DOM rendering
 * - No unsafe HTML injection
 * - Stable polling
 * - Live telemetry hydration
 * - Retry lifecycle support
 * - Refresh without page reload
 */

(function () {

"use strict";

/* =========================================================
 * INIT GUARD
 * ======================================================= */

if (window.__mtEmailQueueInitialized) {
    return;
}

Object.defineProperty(window, "__mtEmailQueueInitialized", {
    value: true,
    writable: false
});

/* =========================================================
 * CONFIG
 * ======================================================= */

const ENDPOINT = "/admin/api/email-queue";
const RETRY_ENDPOINT = "/admin/api/email-queue/retry";

const POLL_INTERVAL = 5000;

/*
|--------------------------------------------------------------------------
| TELEMETRY STATE CACHE
|--------------------------------------------------------------------------
|
| Prevents transient API null fields from wiping
| previously known telemetry values.
|
*/

/*
|--------------------------------------------------------------------------
| TELEMETRY STATE CACHE
|--------------------------------------------------------------------------
|
| Stabilizes transient API polling payloads.
|
| Some polling responses arrive partially hydrated
| while async delivery processing is still ongoing.
|
| We therefore preserve the last authoritative
| non-empty telemetry state for each row.
|
*/

const telemetryCache = new Map();

function normalizeTelemetryRow(row) {

    if (!row || typeof row !== "object") {
        return row;
    }

    const cacheKey =
        String(row.id || "").trim();

    if (cacheKey === "") {
        return row;
    }

    const previous =
        telemetryCache.get(cacheKey) || {};

    /*
    |--------------------------------------------------------------------------
    | Lifecycle-aware telemetry reset
    |--------------------------------------------------------------------------
    |
    | Pending rows must never inherit finalized
    | delivery telemetry from previous states.
    |
    */

    const normalizedStatus =
        String(row.status || "")
            .trim()
            .toLowerCase();

    const previousState =
        normalizedStatus === "pending"
            ? {
                ...previous,
                sent_at: undefined,
                delivery_latency_seconds: undefined,
                message_id: undefined
            }
            : previous;

    /*
    |--------------------------------------------------------------------------
    | Build normalized telemetry state
    |--------------------------------------------------------------------------
    |
    | Reconcile transient polling payloads with
    | previously known authoritative telemetry.
    |
    */

    const normalized = {

        ...row,

        message_id:
            firstStableValue(
                row.message_id,
                row.postmark_message_id,
                row.provider_message_id,
                row.message,
                previousState.message_id
            ),

        queue_latency_seconds:
            firstStableValue(
                row.queue_latency_seconds,
                previousState.queue_latency_seconds
            ),

        delivery_latency_seconds:
            firstStableValue(
                row.delivery_latency_seconds,
                previousState.delivery_latency_seconds
            ),

        emitted_at:
            firstStableValue(
                row.emitted_at,
                previousState.emitted_at
            ),

        sent_at:
            firstStableValue(
                row.sent_at,
                previousState.sent_at
            ),

        next_attempt_at:
            firstStableValue(
                row.next_attempt_at,
                previousState.next_attempt_at
            )
    };

    /*
    |--------------------------------------------------------------------------
    | Persist ONLY authoritative telemetry values
    |--------------------------------------------------------------------------
    |
    | Never allow transient empty polling payloads
    | to overwrite previously known telemetry.
    |
    */

    const nextCacheState = {
        ...previous
    };

    function persistIfStable(key, value) {

        /*
        |--------------------------------------------------------------------------
        | Preserve valid zero values
        |--------------------------------------------------------------------------
        */

        if (value === 0 || value === "0") {
            nextCacheState[key] = value;
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Ignore transient empty states
        |--------------------------------------------------------------------------
        */

        if (
            value === undefined ||
            value === null
        ) {
            return;
        }

        if (
            typeof value === "string" &&
            value.trim() === ""
        ) {
            return;
        }

        nextCacheState[key] = value;
    }

    persistIfStable(
        "message_id",
        normalized.message_id
    );

    persistIfStable(
        "queue_latency_seconds",
        normalized.queue_latency_seconds
    );

    persistIfStable(
        "delivery_latency_seconds",
        normalized.delivery_latency_seconds
    );

    persistIfStable(
        "emitted_at",
        normalized.emitted_at
    );

    persistIfStable(
        "sent_at",
        normalized.sent_at
    );

    persistIfStable(
        "next_attempt_at",
        normalized.next_attempt_at
    );

    telemetryCache.set(
        cacheKey,
        nextCacheState
    );

    return normalized;
}

function firstStableValue() {

    for (const value of arguments) {

        /*
        |--------------------------------------------------------------------------
        | Preserve valid numeric zero telemetry
        |--------------------------------------------------------------------------
        */

        if (value === 0 || value === "0") {
            return value;
        }

        /*
        |--------------------------------------------------------------------------
        | Reject nullish states
        |--------------------------------------------------------------------------
        */

        if (
            value === undefined ||
            value === null
        ) {
            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | Normalize strings
        |--------------------------------------------------------------------------
        */

        if (typeof value === "string") {

            const normalized =
                value.trim();

            /*
            |--------------------------------------------------------------------------
            | Reject transient placeholder states
            |--------------------------------------------------------------------------
            */

            if (
                normalized === "" ||
                normalized === "-" ||
                normalized.toLowerCase() === "null" ||
                normalized.toLowerCase() === "undefined"
            ) {
                continue;
            }

            return normalized;
        }

        /*
        |--------------------------------------------------------------------------
        | Accept stable non-string values
        |--------------------------------------------------------------------------
        */

        return value;
    }

    return undefined;
}

/* =========================================================
 * DOM HELPERS
 * ======================================================= */

function getTableBody() {
    return document.getElementById("emailQueueTableBody");
}

function getRefreshButton() {
    return document.getElementById("emailQueueRefreshBtn");
}

function createElement(tag, className, text) {

    const el = document.createElement(tag);

    if (className) {
        el.className = className;
    }

    if (text !== undefined && text !== null) {
        el.textContent = String(text);
    }

    return el;
}

function createBadge(status) {

    const normalized = String(status || "").toLowerCase();

    let badgeClass = "";

    switch (normalized) {

        case "sent":
            badgeClass = "badge-active";
            break;

        case "failed":
            badgeClass = "badge-revoked";
            break;

        case "pending":
            badgeClass = "badge-suspended";
            break;
    }

    const span = createElement(
        "span",
        `badge ${badgeClass}`,
        normalized.toUpperCase()
    );

    return span;
}

/* =========================================================
 * KPI LIVE HYDRATION
 * ======================================================= */

function updateMetricCard(title, value) {

    const cards = document.querySelectorAll(".metric-card");

    cards.forEach(function(card){

        const heading =
            card.querySelector("h4");

        const valueNode =
            card.querySelector(".value");

        if (!heading || !valueNode) {
            return;
        }

        const normalized =
            heading.textContent
                .trim()
                .toLowerCase();

        if (
            normalized ===
            title.trim().toLowerCase()
        ) {
            valueNode.textContent =
                String(value);
        }
    });
}

function updateKpiCards(payload) {

    if (!payload || typeof payload !== "object") {
        return;
    }

    /*
    |--------------------------------------------------------------------------
    | Preferred authoritative counters
    |--------------------------------------------------------------------------
    */

    if (payload.metrics) {

        updateMetricCard(
            "Pending",
            payload.metrics.pending ?? 0
        );

        updateMetricCard(
            "Sent",
            payload.metrics.sent ?? 0
        );

        updateMetricCard(
            "Failed",
            payload.metrics.failed ?? 0
        );

        updateMetricCard(
            "Avg Queue Latency",
            String(
                payload.metrics.avg_latency ?? 0
            ) + "s"
        );

        updateMetricCard(
            "Max Queue Latency",
            String(
                payload.metrics.max_latency ?? 0
            ) + "s"
        );

        updateMetricCard(
            "Stuck Jobs",
            payload.metrics.stuck_jobs ?? 0
        );

        return;
    }

    /*
    |--------------------------------------------------------------------------
    | Fallback reconstruction
    |--------------------------------------------------------------------------
    */

    if (!Array.isArray(payload.data)) {
        return;
    }

    let pending = 0;
    let sent = 0;
    let failed = 0;

    payload.data.forEach(function(r){

        const status =
            String(r.status || "")
                .toLowerCase();

        switch (status) {

            case "pending":
                pending++;
                break;

            case "sent":
                sent++;
                break;

            case "failed":
                failed++;
                break;
        }
    });

    updateMetricCard("Pending", pending);
    updateMetricCard("Sent", sent);
    updateMetricCard("Failed", failed);
}

function clearNode(node) {

    while (node.firstChild) {
        node.removeChild(node.firstChild);
    }
}

/* =========================================================
 * TABLE RENDERER
 * ======================================================= */

function renderRows(rows) {

    const tbody = getTableBody();

    if (!tbody) {
        return;
    }

    clearNode(tbody);

    if (!Array.isArray(rows) || rows.length === 0) {

        const tr = document.createElement("tr");

        const td = createElement(
            "td",
            "mt-empty",
            "Queue telemetry unavailable"
        );

        td.colSpan = 8;

        tr.appendChild(td);
        tbody.appendChild(tr);

        return;
    }

    rows.forEach(function (r) {

    /*
    |--------------------------------------------------------------------------
    | Normalize transient telemetry payload
    |--------------------------------------------------------------------------
    */

    r = normalizeTelemetryRow(r);

        const tr = document.createElement("tr");

        /*
        |--------------------------------------------------------------------------
        | ID
        |--------------------------------------------------------------------------
        */

        tr.appendChild(
            createElement("td", "", "#" + (r.id ?? "-"))
        );

        /*
        |--------------------------------------------------------------------------
        | TYPE
        |--------------------------------------------------------------------------
        */

        const typeTd = document.createElement("td");

        const code = createElement(
            "code",
            "",
            r.type || "-"
        );

        typeTd.appendChild(code);

        tr.appendChild(typeTd);

        /*
        |--------------------------------------------------------------------------
        | RECIPIENT + SUBJECT
        |--------------------------------------------------------------------------
        */

        const recipientTd = document.createElement("td");

        recipientTd.appendChild(
            createElement(
                "div",
                "email-recipient",
                r.recipient || "-"
            )
        );

        recipientTd.appendChild(
            createElement(
                "div",
                "email-subject",
                r.subject || "-"
            )
        );

        tr.appendChild(recipientTd);

        /*
        |--------------------------------------------------------------------------
        | STATUS
        |--------------------------------------------------------------------------
        */

        const statusTd = document.createElement("td");

        statusTd.appendChild(
            createBadge(r.status)
        );

        tr.appendChild(statusTd);

        /*
        |--------------------------------------------------------------------------
        | ATTEMPTS
        |--------------------------------------------------------------------------
        */

        tr.appendChild(
            createElement(
                "td",
                "",
                r.attempts ?? 0
            )
        );

        /*
        |--------------------------------------------------------------------------
        | QUEUE LATENCY
        |--------------------------------------------------------------------------
        */

        const queueTd = document.createElement("td");

        if (String(r.status).toLowerCase() === "pending") {

            queueTd.appendChild(
                createElement(
                    "span",
                    "email-live-pulse",
                    "LIVE"
                )
            );

        } else {

            const queueLatency =
                r.queue_latency_seconds;

            queueTd.textContent =
                (
                    queueLatency === 0 ||
                    queueLatency === "0"
                )
                    ? "0s"
                    : (
                        queueLatency !== undefined &&
                        queueLatency !== null &&
                        String(queueLatency).trim() !== ""
                    )
                        ? String(queueLatency) + "s"
                        : "-";
        }

        tr.appendChild(queueTd);

        /*
        |--------------------------------------------------------------------------
        | DELIVERY LATENCY
        |--------------------------------------------------------------------------
        */

        tr.appendChild(
            createElement(
                "td",
                "",
                (
                    r.delivery_latency_seconds === 0 ||
                    r.delivery_latency_seconds === "0"
                )
                    ? "0s"
                    : (
                        r.delivery_latency_seconds !== undefined &&
                        r.delivery_latency_seconds !== null &&
                        String(r.delivery_latency_seconds).trim() !== ""
                    )
                        ? String(r.delivery_latency_seconds) + "s"
                        : "-"
            )
        );

        /*
        |--------------------------------------------------------------------------
        | TELEMETRY
        |--------------------------------------------------------------------------
        */

        const telemetryTd = document.createElement("td");

        const telemetryWrap = createElement(
            "div",
            "email-telemetry-meta"
        );

        function appendMeta(label, value) {

            const row = document.createElement("div");

            const strong = createElement(
                "strong",
                "",
                label + ": "
            );

            row.appendChild(strong);

            row.appendChild(
                document.createTextNode(value || "-")
            );

            telemetryWrap.appendChild(row);
        }

        appendMeta("Emitted", r.emitted_at);
        appendMeta("Sent", r.sent_at);
        appendMeta("Retry", r.next_attempt_at);
        /*
        |--------------------------------------------------------------------------
        | Use normalized stable telemetry value only
        |--------------------------------------------------------------------------
        |
        | At this stage r.message_id has already been
        | restored from cache when transient API
        | payloads arrive empty.
        |
        | Re-evaluating raw payload fields here
        | reintroduces flicker/state divergence.
        |
        */

        const resolvedMessageId =
            typeof r.message_id === "string"
                ? r.message_id.trim()
                : "";

        appendMeta(
            "Message",
            resolvedMessageId.trim() !== ""
                ? resolvedMessageId
                : "-"
        );

        if (r.last_error) {

            telemetryWrap.appendChild(
                createElement(
                    "div",
                    "email-error-block",
                    r.last_error
                )
            );
        }

        /*
        |--------------------------------------------------------------------------
        | RETRY BUTTON
        |--------------------------------------------------------------------------
        */

        if (
            String(r.status).toLowerCase() === "failed"
        ) {

            const retryWrap = createElement(
                "div",
                "mt-2"
            );

            const retryBtn = createElement(
                "button",
                "primary-btn retry-btn",
                "Retry"
            );

            retryBtn.type = "button";
            retryBtn.dataset.id = String(r.id);

            retryWrap.appendChild(retryBtn);

            telemetryWrap.appendChild(retryWrap);
        }

        telemetryTd.appendChild(telemetryWrap);

        tr.appendChild(telemetryTd);

        tbody.appendChild(tr);
    });
}

/* =========================================================
 * FETCH ENGINE
 * ======================================================= */

let isFetching = false;

async function fetchQueue() {

    if (isFetching) {
        return;
    }

    isFetching = true;

    try {

        const response = await fetch(ENDPOINT, {
            credentials: "same-origin",
            cache: "no-store"
        });

        if (!response.ok) {
            return;
        }

        const json = await response.json();

        if (
            !json ||
            typeof json !== "object" ||
            !json.success ||
            !Array.isArray(json.data)
        ) {
            return;
        }

        renderRows(json.data);

        updateKpiCards(json);

        /*
        |--------------------------------------------------------------------------
        | Optional telemetry bridge
        |--------------------------------------------------------------------------
        */

        if (
            window.emailQueueFeed &&
            typeof window.emailQueueFeed.update === "function"
        ) {
            window.emailQueueFeed.update(json.data);
        }

    } catch (error) {

        console.warn(
            "[MT EMAIL QUEUE] Fetch failed",
            error
        );

    } finally {

        isFetching = false;
    }
}

/* =========================================================
 * RETRY ACTION
 * ======================================================= */

async function handleRetry(button) {

    if (!button) {
        return;
    }

    const id = button.dataset.id;

    if (!id) {
        return;
    }

    if (
        button.disabled ||
        button.dataset.locked === "1"
    ) {
        return;
    }

    button.dataset.locked = "1";
    button.disabled = true;
    button.textContent = "...";

    try {

        const response = await fetch(
            RETRY_ENDPOINT,
            {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    id: Number(id)
                })
            }
        );

        const json = await response.json();

        if (json && json.success) {

            button.textContent = "Done";

            setTimeout(fetchQueue, 600);

        } else {

            button.textContent = "Error";
        }

    } catch (error) {

        console.warn(
            "[MT EMAIL QUEUE] Retry failed",
            error
        );

        button.textContent = "Error";
    }
}

/* =========================================================
 * EVENT DELEGATION
 * ======================================================= */

document.addEventListener("click", function (event) {

    const retryBtn =
        event.target.closest(".retry-btn");

    if (retryBtn) {

        event.preventDefault();

        handleRetry(retryBtn);

        return;
    }

    const refreshBtn =
        event.target.closest("#emailQueueRefreshBtn");

    if (refreshBtn) {

        event.preventDefault();

        fetchQueue();
    }
});

/* =========================================================
 * POLLING
 * ======================================================= */

function startPolling() {

    if (window.__mtEmailQueuePolling) {
        return;
    }

    window.__mtEmailQueuePolling = true;

    fetchQueue();

    window.setInterval(
        fetchQueue,
        POLL_INTERVAL
    );

    console.debug(
        "[MT] Email queue telemetry polling started"
    );
}

/* =========================================================
 * INIT
 * ======================================================= */

if (
    document.readyState === "complete" ||
    document.readyState === "interactive"
) {

    startPolling();

} else {

    document.addEventListener(
        "DOMContentLoaded",
        startPolling
    );
}

})();