/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: command-module.js
 * Location: /public_html/Assets/
 * Purpose: Deferred Command Palette Module Bridge
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 54 — Reactive Module Initialization
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD (NO DUPLICATE EXECUTION)
========================================================= */

if (window.__mtCommandModuleInitialized) return;

Object.defineProperty(window, "__mtCommandModuleInitialized", {
    value: true,
    writable: false
});

/* =========================================================
   CONFIG
========================================================= */

const MAX_RETRIES = 20;
const RETRY_DELAY = 150;

/* =========================================================
   SAFE INIT WITH RETRY
========================================================= */

function initWithRetry(retries = 0){

    if (typeof window.mtInitCommandPalette === "function") {

        try {

            window.mtInitCommandPalette();

            console.debug("[MT] Command Palette initialized");

            /* -----------------------------------------
               REGISTER AS PLUGIN (PHASE 55 READY)
            ----------------------------------------- */

            if (window.MT_PLUGINS?.register) {

			    window.MT_PLUGINS.register({
			        name: "commandPalette",
			        init: window.mtInitCommandPalette
			    });

			}

        } catch(e){

            console.error("[MT COMMAND INIT ERROR]", e);

        }

        return;
    }

    if (retries >= MAX_RETRIES){

        console.warn("[MT] Command Palette not available");

        return;
    }

    setTimeout(()=>initWithRetry(retries + 1), RETRY_DELAY);
}

/* =========================================================
   DEFERRED START (NO DOMContentLoaded)
========================================================= */

initWithRetry();

})();