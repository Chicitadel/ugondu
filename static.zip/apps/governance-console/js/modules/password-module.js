/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: password-module.js
 * Location: /public_html/Assets/modules/
 * Purpose: Password UX engine (toggle, entropy, validation, match)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 55 — Password UX Restoration Engine
 *
 * Guarantees:
 * - Zero regression
 * - MutationObserver safe
 * - No duplicate bindings
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

if (window.__mtPasswordModule) return;

Object.defineProperty(window, "__mtPasswordModule", {
    value: true,
    writable: false
});

/* =========================================================
   ENTROPY (MATCH BACKEND)
========================================================= */

function calculateEntropy(password){

    const length = password.length;
    if (!length) return 0;

    const freq = {};
    for (let char of password){
        freq[char] = (freq[char] || 0) + 1;
    }

    let entropy = 0;

    for (let char in freq){
        const p = freq[char] / length;
        entropy += -p * Math.log2(p);
    }

    return entropy * length;
}

/* =========================================================
   REQUIREMENTS CHECK
========================================================= */

function checkRequirements(password){

    return {
        length: password.length >= 12,
        upper: /[A-Z]/.test(password),
        lower: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        symbol: /[\W]/.test(password)
    };
}

/* =========================================================
   GLOBAL CLICK (EYE TOGGLE — FIXED)
========================================================= */

document.addEventListener("click", function(e){

    const toggle = e.target.closest(".pw-toggle");
    if (!toggle) return;

    const id = toggle.dataset.target;
    const input = document.getElementById(id);

    if (!input) return;

    const isPassword = input.type === "password";

    input.type = isPassword ? "text" : "password";

    toggle.setAttribute("aria-pressed", isPassword ? "true" : "false");

});

/* =========================================================
   INPUT HANDLER (ENTROPY + UI)
========================================================= */

document.addEventListener("input", function(e){

    if (!e.target.matches('input[type="password"]')) return;

    const password = e.target.value;

    const entropy = calculateEntropy(password);

    const entropyEl = document.getElementById("entropyText");
    if (entropyEl){
        entropyEl.textContent = "Entropy: " + Math.round(entropy) + " bits";
    }

    /* ---------- REQUIREMENTS ---------- */

    const req = checkRequirements(password);

    function set(id, ok){
        const el = document.getElementById(id);
        if (!el) return;
        el.textContent = (ok ? "✔ " : "❌ ") + el.textContent.replace(/^✔ |❌ /, "");
        el.style.color = ok ? "green" : "red";
    }

    set("req-length", req.length);
    set("req-upper", req.upper);
    set("req-lower", req.lower);
    set("req-number", req.number);
    set("req-symbol", req.symbol);

    /* ---------- STRENGTH ---------- */

    const score = Object.values(req).filter(Boolean).length;

    const bar = document.getElementById("strengthBar");
    const text = document.getElementById("strengthText");

    if (bar){
        bar.style.width = (score * 20) + "%";
        bar.style.background =
            score <= 2 ? "#dc2626" :
            score === 3 ? "#f59e0b" :
            "#16a34a";
    }

    if (text){
        text.textContent =
            score <= 2 ? "Weak" :
            score === 3 ? "Moderate" :
            "Strong";
    }

});

/* =========================================================
   MATCH + ADAPTIVE BACKEND VALIDATION (PHASE 56)
========================================================= */

(function(){

let debounceTimer = null;

document.addEventListener("input", function(){

    const p1 = document.getElementById("passwordField");
    const p2 = document.getElementById("confirmField");

    if (!p1) return;

    const password = p1.value;

    /* -----------------------------------------------------
       MATCH CHECK
    ----------------------------------------------------- */

    const matchEl = document.getElementById("matchIndicator");

    if (p2 && matchEl){

        if (!p2.value){
            matchEl.textContent = "";
        } else if (p1.value === p2.value){
            matchEl.textContent = "Passwords match ✔";
            matchEl.style.color = "green";
        } else {
            matchEl.textContent = "Passwords do not match ✖";
            matchEl.style.color = "red";
        }
    }

    /* -----------------------------------------------------
       DEBOUNCED BACKEND VALIDATION
    ----------------------------------------------------- */

    if (debounceTimer) clearTimeout(debounceTimer);

    debounceTimer = setTimeout(async function(){

        try {

            const form = p1.closest("form");
            if (!form) return;

            const csrf = form.querySelector('input[name="_csrf"]')?.value;

            const res = await fetch(window.location.pathname, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: new URLSearchParams({
                    action: "validate_password",
                    password: password,
                    _csrf: csrf || ""
                })
            });

            const data = await res.json();

            /* -------------------------------------------------
               ENTROPY SYNC (BACKEND AUTHORITY)
            ------------------------------------------------- */

            const entropyEl = document.getElementById("entropyText");
            if (entropyEl && data.entropy !== undefined){
                entropyEl.textContent = "Entropy: " + Math.round(data.entropy) + " bits";
            }

            /* -------------------------------------------------
               REJECTION REASONS (CRITICAL UX)
            ------------------------------------------------- */

            const rejectBox = document.getElementById("pwRejectionBox");
            const rejectList = document.getElementById("pwRejectionList");

            if (!rejectBox || !rejectList) return;

            rejectList.innerHTML = "";

            if (!data.valid){

                rejectBox.classList.remove("hidden");

                (data.reasons || []).forEach(reason=>{
                    const li = document.createElement("li");
                    li.textContent = reason;
                    rejectList.appendChild(li);
                });

            } else {
                rejectBox.classList.add("hidden");
            }

            /* -------------------------------------------------
               BREACH WARNING
            ------------------------------------------------- */

            if (data.breach > 0){

                const li = document.createElement("li");
                li.textContent = "⚠ Password found in " + data.breach + " breaches";
                li.style.color = "red";

                rejectBox.classList.remove("hidden");
                rejectList.appendChild(li);
            }

        } catch(e){
            console.warn("[MT ADAPTIVE VALIDATION ERROR]", e);
        }

    }, 400); // balanced debounce

});

})();

/* =========================================================
   POLICY BINDING (CRITICAL FIX — PHASE 55.1)
========================================================= */

(function bindPasswordPolicy(){

    const container = document.getElementById("password-policy");
    if (!container) return;

    // 🔒 prevent duplicate binding
    if (container.dataset.bound === "1") return;

    try {

        const raw = container.dataset.policy;
        if (!raw) return;

        const policy = JSON.parse(raw);

        const riskEl = document.getElementById("riskScore");
        const lenEl  = document.getElementById("minLength");
        const rotEl  = document.getElementById("rotationInfo");

        if (riskEl) {
            riskEl.textContent = policy.riskScore ?? "—";
        }

        if (lenEl) {
            lenEl.textContent = policy.requiredLength ?? "—";
        }

        if (rotEl && policy.daysSinceRotation !== null){
            rotEl.textContent = "Last rotated: " + policy.daysSinceRotation + " days ago";
        }

        container.dataset.bound = "1";

    } catch(e){
        console.warn("[MT PASSWORD POLICY BIND ERROR]", e);
    }

})();

/* =========================================================
   FORM SUBMISSION FEEDBACK (PHASE 56)
========================================================= */

document.addEventListener("submit", function(e){

    const form = e.target;

    if (!form.matches('form[data-mt-form="password-reset"]')) return;

    const btn = form.querySelector("button[type='submit']");
    if (btn){
        btn.disabled = true;
        btn.textContent = "Updating...";
    }

});

/* =========================================================
   EXPORT TO CORE (CRITICAL)
========================================================= */

if (window.MT && Object.isExtensible(window.MT)){

    window.MT.bindPasswordModule = function(){
        // handled globally
    };

}

})();