    /**
     * Mandatag
     * Internal Licensing, Entitlement & Administrative Control System
     *
     * © Air Roofers SAS
     *
     * --------------------------------------------------------------------
     * Author: Ignatus Chika Ujomor
     * Role: Software Architect & Systems Engineer
     * Organization: Air Roofers SAS
     * Profile: https://www.ujomor.com
     *
     * Signature:
     *   "Mandatag — where licensing stops being an afterthought."
     * --------------------------------------------------------------------
     *
     * File: admin.js
     * Location: /public_html/Assets/
     * Purpose:
     *   Minimal Admin UI Bootstrap Entrypoint
     *
     * Responsibilities:
     *   - Single initialization guard
     *   - Safe module loader trigger (delegated to MT_BOOT)
     *   - Non-intrusive global error isolation
     *
     * Non-Responsibilities (strictly enforced):
     *   - UI logic
     *   - DOM manipulation
     *   - State management
     *   - Reactive bindings
     *   - Feature modules
     *
     * --------------------------------------------------------------------
     *
     * PATCH LEVEL: Phase 57 — Deterministic Entry + Idempotent Guarding
     *
     * Guarantees:
     * - Zero duplication
     * - Idempotent execution
     * - Deterministic bootstrap
     * - Safe under partial reload / re-entry
     * - Production hardened
     * --------------------------------------------------------------------
     */

    'use strict';

    /* =========================================================
       INIT GUARD (GLOBAL — HARD LOCK)
    ========================================================= */

    if (window.__mtAdminInitialized === true) {
        console.debug('[MT ADMIN] Already initialized');
    } else {

        Object.defineProperty(window, '__mtAdminInitialized', {
            value: true,
            writable: false,
            configurable: false
        });

        /* =========================================================
           SAFE ERROR ISOLATION (IDEMPOTENT)
           - Attaches once globally
           - Ignores controlled UI handlers
        ========================================================= */

        if (!window.__mtErrorHandlerAttached) {

            Object.defineProperty(window, '__mtErrorHandlerAttached', {
                value: true,
                writable: false,
                configurable: false
            });

            window.addEventListener('error', function (e) {

                // Respect dedicated UI error handler if present
                if (window.MT_ErrorUI) return;

                try {
                    const source  = e?.filename || '';
                    const message = String(e?.message || '');

                    // Isolate known external/plugin noise ONLY
                    if (
                        source.includes('seobar') ||
                        message.includes('Seobar2Plugin')
                    ) {
                        console.warn('[MT] External plugin error isolated');
                    }

                } catch (_) {
                    // silent fail (never break runtime)
                }
            });
        }

        /* =========================================================
           SAFE MODULE BOOTSTRAP TRIGGER (DEFERRED)
           - Waits for MT_BOOT availability
           - Bounded retry (no infinite loops)
           - Does NOT implement logic itself
        ========================================================= */

        (function waitForBoot(retries = 15) {

            if (window.MT_BOOT) {

                // 🔥 ONLY START ONCE
                if (!window.__MT_BOOT_TRIGGERED) {

                    window.__MT_BOOT_TRIGGERED = true;

                    window.MT_BOOT.start({
                        context: 'admin',
                        version: window.__MT_ASSET_VERSION__ || '1.0.0'
                    });

                    /* =========================================================
                       🔥 MT-PATCH-DISPATCHER-STABILITY-002
                    ========================================================= */

                    (function waitForDispatcher(){

                        if (window.__MT_DISPATCHER_READY__) return;

                        setTimeout(waitForDispatcher, 25);

                    })();
                }

                return; // ✅ STOP LOOP COMPLETELY
            }

            if (retries <= 0) {
                console.error('[MT ADMIN] MT_BOOT missing');
                return;
            }

            setTimeout(function () {
                waitForBoot(retries - 1);
            }, 60);

        })();
    }