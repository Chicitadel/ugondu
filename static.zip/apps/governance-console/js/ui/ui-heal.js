/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: ui-heal.js
 * Location: /public_html/Assets/
 * Purpose: Safe UI self-healing + form binding recovery engine
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 54 — Reactive UI Stabilization
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtUiHeal) return;

Object.defineProperty(window, "__mtUiHeal", {
    value: true,
    writable: false
});

/* =========================================================
   SAFE HEAL FUNCTION
========================================================= */

if (typeof window.mtHealUI !== "function" || window.mtHealUI.name === "noop") {
    window.mtHealUI = function(){

        if (typeof window.mtBindForm !== "function") return;

        const forms = document.querySelectorAll("form[data-mt-form]");

        forms.forEach(form => {

            // ✅ STRICT BIND GUARD
            if (form.dataset.mtBound === "1") return;

            try {
                window.mtBindForm(form);

                // 🔒 mark as bound
                form.dataset.mtBound = "1";

            } catch(e){
                console.warn("[MT HEAL ERROR]", e);
            }

        });

    };
}

/* =========================================================
   DEBOUNCED OBSERVER (CRITICAL FIX)
========================================================= */

(function(){

    // 🔒 disable in controlled environments if needed
    if (window.__MT_DISABLE_HEAL__) return;

    // clean previous observer
    if (window.__mtObserver) {
        try { window.__mtObserver.disconnect(); } catch(e){}
    }

    let timer = null;

    const observer = new MutationObserver((mutations)=>{

        if (timer) return;

        timer = setTimeout(()=>{
            timer = null;

            // 🔒 ONLY heal forms — NOT full UI
            document.querySelectorAll("form[data-mt-form]")
                .forEach(form=>{
                    if (form.dataset.mtBound === "1") return;

                    try {
                        window.mtBindForm(form);
                        form.dataset.mtBound = "1";
                    } catch {}
                });

        }, 300);

    });

    if (typeof observer !== "undefined" && observer instanceof MutationObserver) {

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

    } else {

        console.warn("[MT] observer not available — skipped safely");

    }

    window.__mtObserver = observer;

})();

/* =========================================================
   INITIAL RUN (SAFE)
========================================================= */

try {
    window.mtHealUI();
} catch(e){
    console.warn("[MT INITIAL HEAL ERROR]", e);
}

})();