/******************************************************************************
 * Project        : Mandatag
 * Module         : Governance Console Assets
 * File           : devtools-runner.js
 * Version        : Phase 91.0.0
 * Author         : Ignatus Chika Ujomor
 * Organization   : Air Roofers SAS
 * Created Date   : 2026-05-22
 * Last Modified  : 2026-05-23
 * Classification : ENTERPRISE | INTERNAL
 *
 * Governance:
 * - Security Reviewed & Sanitized
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority: Ignatus Chika Ujomor
 * - Security Authority    : Ignatus Chika Ujomor
 * - Governance Authority  : Ignatus Chika Ujomor
 * - Deployment Authority  : Ignatus Chika Ujomor
 *
 * Copyright (c) 2026 Air Roofers SAS
 * All Rights Reserved.
 ******************************************************************************/

(function(){

"use strict";

/* ============================================================
   SINGLE INIT GUARD
   ============================================================ */

if (window.__MT_DEVTOOLS_RUNNER__) return;
window.__MT_DEVTOOLS_RUNNER__ = true;

// 🔒 MT-PATCH-CLI-GLOBAL-LOCK-02
let __mtDevtoolsBusy = false;

/* ============================================================
   CSRF HELPER
   ============================================================ */

function getCSRF() {
    const input = document.querySelector('input[name="_csrf"]');
    if (input && input.value) return input.value;

    if (window.__csrf) return window.__csrf;

    console.warn("[Mandatag] CSRF token not found");
    return '';
}

/* ============================================================
   ESCAPE HTML UTILITY
   ============================================================ */

function escapeHtml(str) {
    if (typeof str !== 'string') {
        str = String(str);
    }
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function colorizePlainText(text) {
    const escaped = escapeHtml(text);
    return escaped
        .replace(/\b(SUCCESS|OK|PASSED|APPLIED)\b/gi, '<span class="mt-t-bool-true">$1</span>')
        .replace(/\b(FAILED|ERROR|CRITICAL|FAILURE|EXCEPTION)\b/gi, '<span class="mt-t-bool-false">$1</span>')
        .replace(/(\[app\]|\[system\]|\bWARNING\b)/gi, '<span class="mt-t-path">$1</span>');
}

/* ============================================================
   RECURSIVE TOKENIZER UTILITIES
   ============================================================ */

function isHash(val) {
    if (typeof val !== 'string') return false;
    const len = val.length;
    return (len === 32 || len === 40 || len === 64 || /^[a-fA-F0-9]{16,128}$/.test(val)) && /^[a-fA-F0-9]+$/.test(val);
}

function isFilePath(val) {
    if (typeof val !== 'string') return false;
    return val.indexOf('/') !== -1 || val.indexOf('\\') !== -1 || val.indexOf('.php') !== -1 || val.indexOf('[app]') !== -1;
}

/**
 * Tokenizes arbitrary primitive values, arrays, and objects into safe highlighted HTML.
 */
function tokenize(val, indent) {
    const baseIndent = "  ".repeat(indent);
    const nextIndent = "  ".repeat(indent + 1);

    if (val === null) {
        return '<span class="mt-t-null">null</span>';
    }
    if (typeof val === 'boolean') {
        return val 
            ? '<span class="mt-t-bool-true">true</span>' 
            : '<span class="mt-t-bool-false">false</span>';
    }
    if (typeof val === 'number') {
        return `<span class="mt-t-number">${val}</span>`;
    }
    if (typeof val === 'string') {
        const escaped = escapeHtml(val);
        if (isHash(val)) {
            return `<span class="mt-t-hash">"${escaped}"</span>`;
        } else if (isFilePath(val)) {
            return `<span class="mt-t-path">"${escaped}"</span>`;
        } else {
            return `<span class="mt-t-string">"${escaped}"</span>`;
        }
    }
    if (Array.isArray(val)) {
        if (val.length === 0) {
            return '<span class="mt-t-brace">[</span><span class="mt-t-brace">]</span>';
        }
        let html = '<span class="mt-t-brace">[</span>';
        html += '<span class="mt-t-collapsible-wrapper">';
        html += '<span class="mt-t-toggle" onclick="window.MT_TERMINAL?.toggle(this)">▼</span>';
        html += '<span class="mt-t-ellipsis">...</span>';
        html += '<span class="mt-t-collapsible-block">';
        
        const items = [];
        for (let i = 0; i < val.length; i++) {
            items.push(nextIndent + tokenize(val[i], indent + 1));
        }
        html += items.join('<span class="mt-t-comma">,</span>\n') + '\n';
        
        html += '</span>'; // end block
        html += '</span>'; // end wrapper
        html += baseIndent + '<span class="mt-t-brace">]</span>';
        return html;
    }
    if (typeof val === 'object') {
        const keys = Object.keys(val);
        if (keys.length === 0) {
            return '<span class="mt-t-brace">{</span><span class="mt-t-brace">}</span>';
        }
        let html = '<span class="mt-t-brace">{</span>';
        html += '<span class="mt-t-collapsible-wrapper">';
        html += '<span class="mt-t-toggle" onclick="window.MT_TERMINAL?.toggle(this)">▼</span>';
        html += '<span class="mt-t-ellipsis">...</span>';
        html += '<span class="mt-t-collapsible-block">';
        
        const items = [];
        for (let i = 0; i < keys.length; i++) {
            const key = keys[i];
            const escapedKey = escapeHtml(key);
            items.push(nextIndent + `<span class="mt-t-key">"${escapedKey}"</span>: ` + tokenize(val[key], indent + 1));
        }
        html += items.join('<span class="mt-t-comma">,</span>\n') + '\n';
        
        html += '</span>'; // end block
        html += '</span>'; // end wrapper
        html += baseIndent + '<span class="mt-t-brace">}</span>';
        return html;
    }
    return escapeHtml(String(val));
}

/**
 * Renders a full macOS terminal chrome card structure around highlighted tokenized contents.
 */
function buildTerminalHtml(cmd, payloadText, metaStr, isSuccess, mode) {
    const cmdEsc = escapeHtml(cmd);
    const metaEsc = metaStr ? escapeHtml(metaStr) : ('runtime • ' + new Date().toLocaleTimeString());
    
    let isJson = false;
    let highlighted = "";
    
    try {
        const parsed = JSON.parse(payloadText);
        if (parsed && typeof parsed === 'object') {
            isJson = true;
            highlighted = tokenize(parsed, 0);
            
            // Adjust states dynamically if metadata keys exist
            if (parsed.success !== undefined) {
                isSuccess = !!parsed.success;
            }
            if (parsed._meta && parsed._meta.mode) {
                mode = parsed._meta.mode;
            }
        } else {
            highlighted = colorizePlainText(payloadText);
        }
    } catch(e) {
        highlighted = colorizePlainText(payloadText);
    }
    
    // Status Badge
    let badgeHtml = "";
    if (isSuccess !== null && isSuccess !== undefined) {
        if (isSuccess) {
            if (mode === 'apply') {
                badgeHtml = '<div class="mt-term-badge mt-badge-success-apply"><span class="mt-term-badge-dot"></span>MUTATION APPLIED</div>';
            } else if (mode === 'dry' || mode === 'dry-run') {
                badgeHtml = '<div class="mt-term-badge mt-badge-success-dry"><span class="mt-term-badge-dot"></span>DRY RUN MODE</div>';
            } else {
                badgeHtml = '<div class="mt-term-badge mt-badge-success"><span class="mt-term-badge-dot"></span>EXECUTION SUCCESSFUL</div>';
            }
        } else {
            badgeHtml = '<div class="mt-term-badge mt-badge-failed"><span class="mt-term-badge-dot"></span>EXECUTION FAILED</div>';
        }
    }
    
    // Split highlighted content into lines to render line numbers
    const lines = highlighted.split("\n");
    const lineCount = lines.length;
    let lineNumbersHtml = "";
    for (let i = 1; i <= lineCount; i++) {
        lineNumbersHtml += `<span>${i}</span>`;
    }
    const finalOutput = lines.join("\n");
    
    let html = `<div class="mt-terminal-card" data-cmd="${cmdEsc}">`;
    
    // Terminal Window Chrome (macOS dots + Toolbar)
    html += `  <div class="mt-terminal-chrome">
    <div class="mt-terminal-dots">
      <span class="mt-term-dot mt-term-dot-red"></span>
      <span class="mt-term-dot mt-term-dot-yellow"></span>
      <span class="mt-term-dot mt-term-dot-green"></span>
    </div>
    <div class="mt-terminal-title">${cmdEsc}</div>
    <div class="mt-terminal-actions">
      <button class="mt-term-action-btn mt-term-copy-btn" onclick="window.MT_TERMINAL?.copy(this)" title="Copy payload to clipboard">
        <span class="mt-term-btn-icon">📋</span> Copy
      </button>`;
      if (isJson) {
          html += `      <button class="mt-term-action-btn mt-term-export-btn" onclick="window.MT_TERMINAL?.export(this)" title="Export as JSON file">
        <span class="mt-term-btn-icon">📥</span> Export
      </button>`;
      }
    html += `    </div>
  </div>`;
  
    // Terminal Prompt Command Line
    html += `  <div class="mt-terminal-prompt">
    <span class="mt-term-prompt-arrow">&gt;</span> <span class="mt-term-prompt-cmd">${cmdEsc}</span>
  </div>`;
  
    // Terminal Main Body (Line numbers + scrolling content)
    html += `  <div class="mt-terminal-body">
    <div class="mt-terminal-line-numbers">${lineNumbersHtml}</div>
    <div class="mt-terminal-content-wrapper">
      <pre class="mt-terminal-code-block">${finalOutput}</pre>
      <textarea class="mt-terminal-raw-payload" style="display:none;" aria-hidden="true">${escapeHtml(payloadText)}</textarea>
    </div>
  </div>`;
  
    // Terminal Telemetry Footer
    html += `  <div class="mt-terminal-footer">
    <div class="mt-terminal-meta">${metaEsc}</div>
    <div class="mt-terminal-status">${badgeHtml}</div>
  </div>`;
  
    html += `</div>`;
    return html;
}

/* ============================================================
   GLOBAL TERMINAL ACTIONS REGISTRY
   ============================================================ */

window.MT_TERMINAL = {
    toggle(toggleSpan) {
        const wrapper = toggleSpan.closest('.mt-t-collapsible-wrapper');
        if (wrapper) {
            wrapper.classList.toggle('mt-collapsed');
        }
    },
    
    copy(btn) {
        const card = btn.closest('.mt-terminal-card');
        if (!card) return;
        const textarea = card.querySelector('.mt-terminal-raw-payload');
        if (!textarea) return;
        
        navigator.clipboard.writeText(textarea.value).then(() => {
            const originalText = btn.innerHTML;
            btn.innerHTML = '<span class="mt-term-btn-icon">✓</span> Copied!';
            btn.style.borderColor = '#10b981';
            btn.style.color = '#10b981';
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.style.borderColor = '';
                btn.style.color = '';
            }, 1500);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
        });
    },
    
    export(btn) {
        const card = btn.closest('.mt-terminal-card');
        if (!card) return;
        const textarea = card.querySelector('.mt-terminal-raw-payload');
        if (!textarea) return;
        
        let cmd = card.dataset.cmd || 'export';
        cmd = cmd.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-');
        
        const blob = new Blob([textarea.value], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `mandatag-${cmd}-${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
};

/* ============================================================
   BUTTON HANDLER
   ============================================================ */

document.addEventListener('click', function(e){

    const btn = e.target.closest('[data-action="devtools-cli"]');
    if (!btn) return;

    // 🔒 MT-PATCH-CLI-ENTRY-HARDENING-01
    e.preventDefault();
    e.stopPropagation();

    if (__mtDevtoolsBusy || btn.disabled || btn.dataset.loading === "1") {
        return;
    }

    const actionRaw = btn.dataset.devAction || btn.dataset.cli || "";
    const action = actionRaw.trim().toLowerCase().replace(/_/g, "-");
    const apply  = btn.dataset.apply === "1";

    if (!action) {
        console.error("[Mandatag] Action missing from button");
        return;
    }

    const runAction = async () => {

        const actionNormalized = action.replace(/_/g, "-");

        function resolveEl(prefix) {
            return (
                document.getElementById(prefix + actionNormalized) ||
                document.getElementById(prefix + actionRaw)
            );
        }

        const spinner = resolveEl("spinner-");
        const resultBox = resolveEl("cli-result-");
        const badge = resolveEl("badge-");

        if (spinner) spinner.style.display = "inline";
        if (badge) badge.style.display = "none";

        btn.disabled = true;
        btn.dataset.loading = "1";
        __mtDevtoolsBusy = true;

        try {
            const csrf = getCSRF();
            if (!csrf) throw new Error("CSRF token missing. Reload page.");

            const form = new URLSearchParams();
            form.append("command", action);
            form.append("apply", apply ? "1" : "0");
            form.append("confirm", "1"); // Explicitly confirm
            form.append("_csrf", csrf);

            const res = await fetch("/admin/cli/run", {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept": "application/json"
                },
                body: form.toString()
            });

            if (!res.ok) {
                const text = await res.text();
                throw new Error(`HTTP ${res.status}: ${text.substring(0, 100)}`);
            }

            const json = await res.json();

            if (resultBox) {
                resultBox.style.display = "block";
                const isError = json.success === false || json.error || (json.data && json.data.error);
                const payloadText = JSON.stringify(json, null, 2);
                resultBox.innerHTML = buildTerminalHtml(
                    `ui-cli --action=${action}`,
                    payloadText,
                    `runtime • ${new Date().toLocaleTimeString()}`,
                    !isError,
                    apply ? 'apply' : 'dry'
                );
            }

            if (badge) {
                const isError = json.success === false || json.error || (json.data && json.data.error);
                badge.textContent = isError ? "FAILED" : "SUCCESS";
                badge.style.background = isError ? "#dc2626" : "#16a34a";
                badge.style.display = "inline-block";
                badge.style.color = "#fff";
            }

        } catch (err) {
            console.error("[Mandatag] Execution failed", err);
            if (resultBox) {
                resultBox.style.display = "block";
                resultBox.innerHTML = buildTerminalHtml(
                    `ui-cli --action=${action}`,
                    "CRITICAL FAILURE: " + err.message,
                    `error • ${new Date().toLocaleTimeString()}`,
                    false,
                    apply ? 'apply' : 'dry'
                );
            }
            if (badge) {
                badge.textContent = "FAILED";
                badge.style.background = "#dc2626";
                badge.style.display = "inline-block";
                badge.style.color = "#fff";
            }
        } finally {
            if (spinner) spinner.style.display = "none";
            btn.disabled = false;
            btn.dataset.loading = "";
            __mtDevtoolsBusy = false;
        }
    };

    if (apply) {
        if (window.mtConfirm) {
            window.mtConfirm(`This will APPLY permanent changes to the ${action} domain. Proceed?`, runAction);
        } else if (confirm("This will APPLY changes to the system.\n\nProceed?")) {
            runAction();
        }
    } else {
        runAction();
    }
});

/* ============================================================
   PHASE 38 — LIVE RESULT STREAM BINDING
   ============================================================ */

window.addEventListener("mt:devtools", function(e){

    const data = e.detail;

    if (!data || !data.action) return;

    const action = data.action;

    // 🔒 MT-PATCH-CLI-DOM-RESOLVE-01
    function resolveEl(prefix, actionRaw, actionNormalized) {
        return (
            document.getElementById(prefix + actionNormalized) ||
            document.getElementById(prefix + actionRaw)
        );
    }

    // 🔒 MT-PATCH-CLI-STREAM-ACTION-FIX-01
    const rawAction = action;
    const actionNormalized = rawAction
        .trim()
        .toLowerCase()
        .replace(/_/g, "-");

    const spinner = resolveEl("spinner-", rawAction, actionNormalized);
    const resultBox = resolveEl("result-", rawAction, actionNormalized);
    const badge = resolveEl("badge-", rawAction, actionNormalized);

    if (spinner) spinner.style.display = "none";

    if (resultBox) {
        resultBox.style.display = "block";
        const payloadText = typeof data.result === 'string' ? data.result : JSON.stringify(data.result, null, 2);
        resultBox.innerHTML = buildTerminalHtml(
            `ui-cli --action=${action}`,
            payloadText,
            `telemetry • ${new Date(data.time * 1000).toLocaleTimeString()}`,
            data.status === "success",
            data.mode === "apply" ? "apply" : "dry"
        );
    }

    if (badge) {
        badge.style.display = "inline-block";
        badge.textContent = data.status === "success" ? "SUCCESS" : "FAILED";
        badge.style.background = data.status === "success" ? "#16a34a" : "#dc2626";
        badge.style.color = "#fff";
    }

});

})();