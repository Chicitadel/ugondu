/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: error-ui.js
 * Location: /public_html/Assets/ui/
 * Purpose: Hardened Global Error Handling Engine (UI + API Bridge)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 46 – Security Hardened Error UI
 *
 * Guarantees:
 * - XSS resistant
 * - No unsafe HTML injection
 * - Fetch interception safe
 * - Event flood protection
 * - Backward compatible
 * - Deterministic behavior
 */

(function(){

    "use strict";

    if (window.__MT_ERROR_UI_LOADED__) return;
    window.__MT_ERROR_UI_LOADED__ = true;

    let activeToast = null;
    let lastErrorTs = 0;

    const MAX_MSG_LENGTH = 300;
    const ERROR_THROTTLE_MS = 500;

    /*
    |--------------------------------------------------------------------------
    | SANITIZATION
    |--------------------------------------------------------------------------
    */

    function sanitizeMessage(input){

        if (typeof input !== "string") {
            return "Unexpected error";
        }

        let msg = input.trim();

        if (msg.length > MAX_MSG_LENGTH) {
            msg = msg.slice(0, MAX_MSG_LENGTH) + "...";
        }

        return msg;
    }

    function normalizePayload(payload){

        if (!payload || typeof payload !== "object") {
            return {
                message: "Unexpected error",
                correlation_id: null
            };
        }

        return {
            message: sanitizeMessage(payload.error || payload.message || "Unexpected error"),
            correlation_id: typeof payload.correlation_id === "string"
                ? payload.correlation_id
                : null
        };
    }

    /*
    |--------------------------------------------------------------------------
    | TOAST
    |--------------------------------------------------------------------------
    */

    function showToast(message, isSuccess = false){

        message = sanitizeMessage(message);

        if(activeToast){
            activeToast.remove();
        }

        const toast = document.createElement("div");
        toast.className = "mt-toast";
        toast.textContent = message;

        Object.assign(toast.style, {
            position: "fixed",
            bottom: "20px",
            left: "50%",
            transform: "translateX(-50%)",
            background: isSuccess ? "#16a34a" : "#dc2626",
            color: "#fff",
            padding: "10px 16px",
            borderRadius: "6px",
            zIndex: "9999",
            fontSize: "14px"
        });

        document.body.appendChild(toast);
        activeToast = toast;

        setTimeout(()=>{
            if (toast.parentNode) toast.remove();
            if (activeToast === toast) activeToast = null;
        }, 3500);
    }

    /*
    |--------------------------------------------------------------------------
    | INLINE ERROR
    |--------------------------------------------------------------------------
    */

    /* ===== MT_PATCH_REJECTION_BOX_DETERMINISTIC_V2 ===== */
    function showInlineError(message, correlationId){

        const box = document.getElementById("rejectionBox");
        const list = document.getElementById("rejectionList");

        if(!box || !list){
            showToast(message);
            return;
        }

        list.textContent = "";

        const li = document.createElement("li");
        li.textContent = message;
        list.appendChild(li);

        if(correlationId){
            const ref = document.createElement("li");
            ref.style.opacity = "0.6";
            ref.style.fontSize = "11px";
            ref.textContent = "Ref: " + correlationId;
            list.appendChild(ref);
        }

        const valid =
            typeof message === "string" &&
            message.trim().length > 0 &&
            message !== "Unexpected error";

        if (valid) {
            box.classList.remove("hidden");

            // 🔒 HARD DISPLAY CONTROL (IMMUNE TO CSS / MUTATION)
            box.style.display = "block";

        } else {
            box.classList.add("hidden");
            box.style.display = "none";
        }
    }

    /* ===== MT_PATCH_REJECTION_BOX_CLEAR_V2 ===== */
    function clearInlineError(){

        const box = document.getElementById("rejectionBox");
        const list = document.getElementById("rejectionList");

        if(box && list){
            list.textContent = "";

            box.classList.add("hidden");

            // 🔒 HARD RESET (PREVENT STALE STATE)
            box.style.display = "none";
        }
    }

    /*
    |--------------------------------------------------------------------------
    | ERROR DISPATCH (THROTTLED)
    |--------------------------------------------------------------------------
    */

    function dispatchError(payload){

        if (!payload || typeof payload !== "object") {
            console.debug("[MT ERROR UI] Ignored invalid payload", payload);
            return;
        }

        // 🔒 HARD BLOCK: ignore generic noise
        const rawMsg = payload.error || payload.message;
        if (!rawMsg || rawMsg === "Unexpected error") {
            console.debug("[MT ERROR UI] Ignored generic error", payload);
            return;
        }

        const now = Date.now();
        if (now - lastErrorTs < ERROR_THROTTLE_MS) return;
        lastErrorTs = now;

        const data = normalizePayload(payload);

        showInlineError(data.message, data.correlation_id);
        showToast(data.message, false);
    }

    /*
    |--------------------------------------------------------------------------
    | SAFE RESPONSE HANDLER
    |--------------------------------------------------------------------------
    */

    /* ===== MT_PATCH_ERROR_UI_SUCCESS_CLEAR_V2 ===== */

    async function handleResponse(response){

        if(response.ok){

            // ✅ CLEAR ANY STALE ERROR UI
            clearInlineError();

            return response;
        }

        const contentType = response.headers.get("content-type") || "";

        if(contentType.includes("application/json")){
            const data = await response.json();
            dispatchError(data);
            throw data;
        }

        window.location.href = "/error?code=" + response.status;

        throw new Error("Non-JSON error response");
    }

    /*
    |--------------------------------------------------------------------------
    | FETCH INTERCEPT (SAFE)
    |--------------------------------------------------------------------------
    */

    if (!window.__MT_FETCH_PATCHED__) {

        const originalFetch = window.fetch;

        window.fetch = async function(...args){

            try{
                const response = await originalFetch(...args);

                if(!response.ok){
                    return await handleResponse(response);
                }

                return response;

            }catch(err){

                dispatchError({ error: err.message });

                throw err;
            }
        };

        window.__MT_FETCH_PATCHED__ = true;
    }

    /*
    |--------------------------------------------------------------------------
    | FORM HOOK
    |--------------------------------------------------------------------------
    */

    document.addEventListener("submit", function(e){
        if (e.target && e.target.tagName === "FORM") {
            clearInlineError();
        }
    });

    /* ===== MT_PATCH_ERROR_UI_RESET_ON_LOAD_V1 ===== */

    document.addEventListener("DOMContentLoaded", function(){
        clearInlineError();
    });

    /*
    |--------------------------------------------------------------------------
    | GLOBAL ERROR EVENTS (SAFE)
    |--------------------------------------------------------------------------
    */

    /* ===== MT_PATCH_ERROR_UI_SINGLE_SOURCE_V5 ===== */

    if (!window.__MT_ADMIN_ERROR_HOOK__) {

        window.__MT_ADMIN_ERROR_HOOK__ = true;

        function isRealApiError(payload){

            if (!payload || typeof payload !== "object") return false;

            const msg = payload.error || payload.message;

            if (typeof msg !== "string" || msg.length === 0) return false;

            // 🔒 HARD FILTER — BLOCK SYSTEM / DISPATCHER NOISE
            const blocked = new Set([
                "Unexpected error",
                "invalid_response",
                "blocked_route",
                "Promise error",
                "invalid_contract"
            ]);

            if (blocked.has(msg)) return false;

            return true;
        }

        /* =====================================================
           🔒 GLOBAL JS ERROR → LOG ONLY (NO UI)
        ===================================================== */
        window.addEventListener("error", function(e){
            console.warn("[MT ERROR IGNORED]", e.message);
        });

        /* =====================================================
           🔒 SINGLE AUTHORITATIVE REJECTION HANDLER
        ===================================================== */
        window.addEventListener("unhandledrejection", function(e){

            const reason = e.reason;

            // ❌ Ignore native runtime errors
            if (reason instanceof Error) {
                console.debug("[MT ERROR UI] Ignored JS error:", reason.message);
                return;
            }

            // ❌ Ignore anything not from backend contract
            if (!isRealApiError(reason)) {
                console.debug("[MT ERROR UI] Ignored non-API rejection", reason);
                return;
            }

            dispatchError(reason);
        });
    }

})();