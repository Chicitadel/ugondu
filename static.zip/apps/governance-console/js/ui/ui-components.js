/**
 * Mandatag
 * Internal Licensing, Entitlement & Administrative Control System
 *
 * © Air Roofers SAS
 *
 * --------------------------------------------------------------------
 * Author: Ignatus Chika Ujomor
 * Role: Software Architect & Systems Engineer
 * Profile: https://www.ujomor.com
 *
 * Signature:
 *   "Mandatag — where licensing stops being an afterthought."
 * --------------------------------------------------------------------
 *
 * File: ui-components.js
 * Location: /public_html/Assets/
 * Purpose: Reactive UI Component System (safe, deterministic, no HTML injection)
 * --------------------------------------------------------------------
 *
 * PATCH LEVEL: Phase 54 — Reactive UI Engine
 *
 * Guarantees:
 * - Zero regression
 * - Backward compatible
 * - Deterministic behavior
 * - Production safe
 * --------------------------------------------------------------------
 */

(function(){

"use strict";

/* =========================================================
   INIT GUARD
========================================================= */

if (window.__mtUiComponents) return;

Object.defineProperty(window, "__mtUiComponents", {
    value: true,
    writable: false
});

/* =========================================================
   SAFE ELEMENT CREATOR
========================================================= */

function el(tag, options = {}){

    const node = document.createElement(tag);

    if (options.className) node.className = options.className;
    if (options.id) node.id = options.id;

    if (options.text !== undefined){
        node.textContent = String(options.text);
    }

    if (options.attrs){
        Object.entries(options.attrs).forEach(([k,v])=>{

            if (typeof v !== "string") v = String(v ?? "");

            /* BLOCK JS EVENT ATTRIBUTES */
            if (/^on/i.test(k)) {
                console.warn("[MT_UI] Blocked unsafe attribute:", k);
                return;
            }

            node.setAttribute(k, v);

        });
    }

    if (options.style){
        Object.assign(node.style, options.style);
    }

    return node;
}

/* =========================================================
   SAFE JSON STRING (TRUNCATED)
========================================================= */

function safeString(obj){

    try{
        const str = JSON.stringify(obj, null, 2);
        return str.length > 10000
            ? str.slice(0,10000) + "\n...truncated"
            : str;
    }catch(e){
        return "[unserializable]";
    }
}

/* =========================================================
   DRAWER COMPONENT
========================================================= */

function createDrawer(){

    let drawer = document.getElementById("mt-drawer");

    if (drawer) return drawer;

    drawer = el("div", {
        id: "mt-drawer",
        style: {
            position: "fixed",
            right: "0",
            top: "0",
            width: "420px",
            height: "100%",
            background: "#fff",
            boxShadow: "-3px 0 8px rgba(0,0,0,0.1)",
            overflow: "auto",
            padding: "20px",
            zIndex: "9999"
        }
    });

    document.body.appendChild(drawer);

    return drawer;
}

function renderDrawer(titleText, sections){

    const drawer = createDrawer();

    // clear safely
    drawer.textContent = "";

    const header = el("div", {
        style: {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "12px"
        }
    });

    const title = el("div", {
        text: titleText,
        style: {
            fontSize: "18px",
            fontWeight: "bold"
        }
    });

    const closeBtn = el("button", {
        text: "✕",
        style: {
            border: "none",
            background: "transparent",
            fontSize: "18px",
            cursor: "pointer"
        }
    });

    closeBtn.onclick = () => drawer.remove();

    header.appendChild(title);
    header.appendChild(closeBtn);

    drawer.appendChild(header);

    sections.forEach(sec => {

        const wrapper = el("div", {
            style: { marginBottom: "16px" }
        });

        const h = el("div", {
            text: sec.title,
            style: {
                fontWeight: "bold",
                marginBottom: "4px"
            }
        });

        let contentNode;

        /* =====================================================
           SAFE CONTENT RESOLUTION (NO HTML PARSING)
        ===================================================== */

        if (sec.content instanceof Node) {

            contentNode = sec.content;

        } else {

            contentNode = el("pre", {
                text: String(sec.content ?? ""),
                style: {
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-word"
                }
            });

        }

        wrapper.appendChild(h);
        wrapper.appendChild(contentNode);

        drawer.appendChild(wrapper);

    });

}

/* =========================================================
   MODAL COMPONENT
========================================================= */

function showModal(titleText, contentText){

    let modal = document.getElementById("mt-modal");

    if (!modal){

        modal = el("div", {
            id: "mt-modal",
            style: {
                position: "fixed",
                top: "0",
                left: "0",
                width: "100%",
                height: "100%",
                background: "rgba(0,0,0,0.4)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: "10000"
            }
        });

        const box = el("div", {
            id: "mt-modal-box",
            style: {
                background: "#fff",
                padding: "20px",
                borderRadius: "8px",
                maxWidth: "500px",
                width: "100%"
            }
        });

        modal.appendChild(box);
        document.body.appendChild(modal);

        modal.addEventListener("click", e=>{
            if (e.target === modal){
                modal.style.display = "none";
            }
        });

    }

    const box = document.getElementById("mt-modal-box");
    box.textContent = "";

    box.appendChild(el("div", {
        text: titleText,
        style: { fontWeight: "bold", marginBottom: "10px" }
    }));

    box.appendChild(el("div", {
        text: contentText
    }));

    modal.style.display = "flex";
}

/* =========================================================
   TOAST SYSTEM (SAFE)
========================================================= */

function showToast(message, success=true){

    let container = document.getElementById("mt-toast-container");

    if (!container){

        container = el("div", {
            id: "mt-toast-container",
            style: {
                position: "fixed",
                bottom: "20px",
                right: "20px",
                zIndex: "10001"
            }
        });

        document.body.appendChild(container);
    }

    const toast = el("div", {
        text: message,
        style: {
            background: success ? "#16a34a" : "#dc2626",
            color: "#fff",
            padding: "10px 14px",
            marginTop: "8px",
            borderRadius: "6px",
            fontSize: "14px"
        }
    });

    container.appendChild(toast);

    setTimeout(()=>{
        toast.remove();
    }, 3000);
}

/* =========================================================
   PUBLIC API (GLOBAL SAFE EXPORT)
========================================================= */

window.MT_UI = Object.freeze({

    el,
    safeString,

    drawer: renderDrawer,
    modal: showModal,
    toast: showToast,

    riskBadge(score){
        const span = document.createElement("span");
        span.textContent = String(score ?? 0);

        Object.assign(span.style, {
            padding: "4px 8px",
            borderRadius: "6px",
            fontSize: "12px",
            fontWeight: "600",
            color: "#fff",
            background:
                score >= 80 ? "#dc2626" :
                score >= 50 ? "#f59e0b" :
                "#16a34a"
        });

        return span;
    }

});

/* =========================================================
   PHASE 58 — UI INTERACTION LAYER
========================================================= */

function toggleSidebarInternal(){

    const body = document.body;
    const sidebar = document.getElementById('sidebar');

    if (!sidebar) {
        console.warn("[MT UI] Sidebar not found");
        return;
    }

    /* =====================================================
       MOBILE / PRIMARY CONTROL
       (THIS IS YOUR REAL CSS DRIVER)
    ===================================================== */

    sidebar.classList.toggle('open');

    /* =====================================================
       OVERLAY CONTROL (MOBILE)
    ===================================================== */

    body.classList.toggle('sidebar-open');

    /* =====================================================
       DESKTOP COLLAPSE MODE (OPTIONAL)
    ===================================================== */

    body.classList.toggle('sidebar-collapsed');

    /* =====================================================
       DEBUG TRACE
    ===================================================== */

    console.debug("[MT UI] Sidebar state:", {
        open: sidebar.classList.contains('open'),
        overlay: body.classList.contains('sidebar-open'),
        collapsed: body.classList.contains('sidebar-collapsed')
    });
}

function toggleThemeInternal(){
    const body = document.body;
    if (!body) return;

    const current = body.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';

    body.setAttribute('data-theme', next);

    try { localStorage.setItem('mt-theme', next); } catch(e){}
}

(function(){
    try {
        const saved = localStorage.getItem('mt-theme');
        if (saved) document.body.setAttribute('data-theme', saved);
    } catch(e){}
})();

function initNotifications(){

    const bell = document.getElementById('notificationBell');
    const panel = document.getElementById('notificationPanel');

    if (!bell || !panel) return;

    bell.addEventListener('click', function(e){
        e.stopPropagation();
        panel.classList.toggle('hidden');
    });

    document.addEventListener('click', function(){
        panel.classList.add('hidden');
    });
}

/* =========================================================
   GLOBAL BRIDGE (EARLY + HARDENED)
========================================================= */

/*
|--------------------------------------------------------------------------
| MUST be globally available immediately for inline onclick
|--------------------------------------------------------------------------
*/

if (typeof window.toggleSidebar !== "function") {
    window.toggleSidebar = function(){
        try {
            toggleSidebarInternal();
        } catch(e){
            console.error("[MT UI] toggleSidebar failed", e);
        }
    };
}

if (typeof window.toggleTheme !== "function") {
    window.toggleTheme = function(){
        try {
            toggleThemeInternal();
        } catch(e){
            console.error("[MT UI] toggleTheme failed", e);
        }
    };
}

function __mtUiInit(){
    initNotifications();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", __mtUiInit);
} else {
    __mtUiInit();
}

if (window.MT_HOOKS?.on) {
    window.MT_HOOKS.on("ui:rendered", __mtUiInit);
}

/* =========================================================
   FAILSAFE REBIND (SELF-HEAL)
========================================================= */

setTimeout(()=>{
    if (typeof window.toggleSidebar !== "function") {
        window.toggleSidebar = toggleSidebarInternal;
    }
    if (typeof window.toggleTheme !== "function") {
        window.toggleTheme = toggleThemeInternal;
    }
}, 500);

})();  // ✅ ONLY ONE CLOSING