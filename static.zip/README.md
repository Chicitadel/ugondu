<!--
/******************************************************************************
 * Project        : Mandatag CDN Static Assets
 * Module         : CDN Packaging & Distribution Engine
 * File           : README.md
 * Version        : 2.0.0
 * Author         : Ignatus Chika Ujomor
 * Organization   : Chicitadel / Air Roofers SASU
 * Created Date   : 2026-06-21
 * Last Modified  : 2026-06-21
 * Classification : ENTERPRISE
 *
 * Governance:
 * - Enterprise Governed
 * - Security Reviewed
 * - Architecture Controlled
 * - Protocol Frozen
 * - Modularization Enforced
 *
 * Standards:
 * - ISO 27001
 * - SOC 2
 * - OWASP ASVS
 * - NIST
 *
 * Signatures:
 * - Architecture Authority
 * - Security Authority
 * - Governance Authority
 * - Deployment Authority
 *
 * Copyright (c) 2026 Chicitadel / Air Roofers SASU
 * All Rights Reserved.
 ******************************************************************************/
-->

# Mandatag CDN 2.0 Static Assets

## 1. Project Vision & Purpose

This repository houses the **Mandatag CDN 2.0 Static Asset release packaging engine**, a centralized distribution hub for all static resources (CSS, JS, Icons, Images, and Web Fonts) across the Chicitadel and Air Roofers SASU ecosystems. Its purpose is to guarantee high availability, strict cache optimization, and unified asset delivery for various platform applications such as `billing-app` and `governance-console`. 

It acts as the single source of truth for front-end global static assets, employing versioned ZIP packaging to ensure immutable, deterministic deployments to edge nodes while firmly supporting our enterprise zero-trust model.

## 2. Architecture & Tech Stack (Inferred)

### Maturity Level: LEVEL:4_DISTRIBUTED_PLATFORM

*   **Core Technology:** Pure Static Assets (HTML/CSS/JS/SVG) + PHP CLI tool (`build_zip_static.php`) for deterministic build packaging.
*   **Web Server Configuration:** Apache HTTP Server. Hardened via `.htaccess` with robust security headers, CORS directives, and advanced caching policies.
*   **Bounded Contexts:** Assets are strictly modularized into namespaces:
    *   `/apps`: Application-specific assets (`billing-app`, `governance-console`).
    *   `/brands`: Brand identities, logos, and UI guidelines.
    *   `/global`: Shared utility libraries, core CSS, icons, and JS runtimes.
    *   `/manifests`: PWA and platform configuration manifests.
*   **Asset Pipeline:** The `build_zip_static.php` engine iterates across permitted directories, excludes sensitive `.git` or IDE metadata, and generates immutable artifact archives (`static_XX.zip`) for edge propagation.
*   **Backward Compatibility:** Legacy asset path mappings are strictly preserved via `.htaccess` 301 redirects, ensuring that protocol compatibility remains unbroken during the V2 transition.

## 3. Setup & Local Development Instructions

### Prerequisites
*   Local web server (Apache with `mod_headers`, `mod_expires`, `mod_rewrite`, and `mod_authz_core` enabled).
*   PHP 8.x+ (CLI) for running the build packaging engine.

### Local Initialization
1. Clone the repository into your local server's document root or mount it via virtual host.
2. If using Apache, ensure the `AllowOverride All` directive is set to fully process the local `.htaccess` overrides.
3. Validate functionality by accessing `/global/js/auth-runtime.js` or testing the legacy endpoints (e.g., `/favicon.ico` which should automatically redirect to `/brands/mandatag/favicon.ico`).

### Artifact Packaging Execution
To generate a deterministic edge-deployment payload, execute the release packaging script:

```bash
php build_zip_static.php
```

The script will:
* Traverse the directory omitting `.git`, `.idea`, and configuration remnants.
* Package valid static resources.
* Output an immutable deployment package (e.g., `static_08.zip`) for CI/CD staging.

## 4. Governance & Security Policies

*   **Immutable Architectures:** The directory structure is frozen. New applications must be strictly scoped under the `/apps` boundary to prevent cross-domain leakage.
*   **Security Header Baselines:** Strict-Transport-Security (HSTS), X-Content-Type-Options (nosniff), X-Frame-Options (SAMEORIGIN), and Content-Security-Policy (CSP) are enforced on the Edge via `.htaccess`.
*   **Hotlink Protection:** Stringent referrer validations block unauthorized domain syndication of core assets. Authorized domains are explicitly whitelisted (`*.airroofers.eu`, `*.ujomor.com`).
*   **DDoS and Scraping Deterrence:** Prohibited User-Agents (e.g., wget, python-urllib, common scanners) are actively denied (`403 Forbidden`) at the edge level.
*   **Cache Determinism:** High availability caching strategies are imposed (1 month to 1 year max-age depending on MIME types) to minimize origin round-trips while guaranteeing swift updates via versioned file names.

---
*Maintained under strict Corporate Engineering Governance Standards.*
